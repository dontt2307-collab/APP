import 'dotenv/config';
import express from 'express';
import type { Request, Response } from 'express';
import fs from 'node:fs';
import http from 'node:http';
import https from 'node:https';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const BROWSER_UA =
  'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36';

function cleanServerImgbbKey(raw: unknown): string {
  if (typeof raw !== 'string' || !raw) return '';
  let text = raw.trim().replace(/^["'`]+|["'`]+$/g, '').trim();

  const urlKeyMatch = text.match(/[?&]key=([a-zA-Z0-9_-]{8,128})/);
  if (urlKeyMatch?.[1]) {
    return urlKeyMatch[1];
  }

  const hex32Match = text.match(/(?:^|[^a-zA-Z0-9])([a-fA-F0-9]{32})(?:$|[^a-zA-Z0-9])/);
  if (hex32Match?.[1]) {
    return hex32Match[1];
  }

  const kvMatch = text.match(/^(?:api\s*)?key\s*[:=]\s*([a-zA-Z0-9_-]{8,128})$/i);
  if (kvMatch?.[1]) {
    return kvMatch[1];
  }

  text = text.replace(/\s+/g, '');
  if (/^https?:\/\//i.test(text)) {
    return '';
  }
  if (
    text.length < 8 ||
    text.length > 128 ||
    text === 'YOUR_IMGBB_API_KEY_HERE' ||
    text.startsWith('YOUR_') ||
    !/^[a-zA-Z0-9_-]+$/.test(text)
  ) {
    return '';
  }
  return text;
}

function stripDataUrlPrefix(rawImage: string): string {
  const trimmed = rawImage.trim();
  const commaIdx = trimmed.indexOf(',');
  if (trimmed.startsWith('data:image/') && commaIdx >= 0) {
    return trimmed.slice(commaIdx + 1).trim();
  }
  return trimmed;
}

interface ImgbbUpstreamResult {
  ok: boolean;
  kind?: 'API_ERROR' | 'NETWORK_ERROR';
  url?: string;
  statusCode?: number;
  errorMessage?: string;
}

function postToImgbbOnce(
  apiKey: string,
  base64Image: string,
  expirationSec?: number
): Promise<ImgbbUpstreamResult> {
  return new Promise((resolve) => {
    const params = new URLSearchParams();
    params.append('key', apiKey);
    params.append('image', base64Image);
    if (expirationSec && expirationSec >= 60 && expirationSec <= 15552000) {
      params.append('expiration', String(Math.floor(expirationSec)));
    }
    const bodyStr = params.toString();

    const req = https.request(
      'https://api.imgbb.com/1/upload',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(bodyStr),
          Accept: 'application/json',
          'User-Agent': BROWSER_UA,
        },
        timeout: 14000,
      },
      (res) => {
        const chunks: Buffer[] = [];
        res.on('data', (chunk: Buffer) => chunks.push(chunk));
        res.on('end', () => {
          const rawText = Buffer.concat(chunks).toString('utf8');
          const statusCode = res.statusCode || 500;
          try {
            const parsed = JSON.parse(rawText) as {
              success?: boolean;
              data?: {
                display_url?: string;
                url?: string;
                image?: { url?: string };
              };
              error?: { message?: string; code?: number };
              status_txt?: string;
            };

            const hostedUrl =
              parsed?.data?.image?.url ||
              parsed?.data?.display_url ||
              parsed?.data?.url ||
              '';

            if (statusCode >= 200 && statusCode < 300 && parsed?.success && hostedUrl.startsWith('https://')) {
              resolve({ ok: true, url: hostedUrl, statusCode });
              return;
            }

            const apiMsg =
              parsed?.error?.message ||
              parsed?.status_txt ||
              `ImgBB HTTP ${statusCode}`;
            const isDatacenterIpBlock =
              parsed?.error?.code === 103 ||
              statusCode === 403 ||
              apiMsg.toLowerCase().includes('forbidden');
            resolve({
              ok: false,
              kind: statusCode >= 500 || isDatacenterIpBlock ? 'NETWORK_ERROR' : 'API_ERROR',
              statusCode,
              errorMessage: apiMsg,
            });
          } catch {
            resolve({
              ok: false,
              kind: statusCode >= 400 && statusCode < 500 ? 'API_ERROR' : 'NETWORK_ERROR',
              statusCode,
              errorMessage: `Unexpected response from ImgBB (HTTP ${statusCode})`,
            });
          }
        });
      }
    );

    req.on('timeout', () => {
      req.destroy(new Error('ETIMEDOUT'));
    });

    req.on('error', () => {
      resolve({
        ok: false,
        kind: 'NETWORK_ERROR',
        errorMessage: 'Could not reach ImgBB upload server',
      });
    });

    req.write(bodyStr);
    req.end();
  });
}

async function postToImgbbWithRetry(
  apiKey: string,
  base64Image: string,
  expirationSec?: number
): Promise<ImgbbUpstreamResult> {
  const maxAttempts = 2;
  let lastResult: ImgbbUpstreamResult = {
    ok: false,
    kind: 'NETWORK_ERROR',
    errorMessage: 'ImgBB connection failed',
  };

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    lastResult = await postToImgbbOnce(apiKey, base64Image, expirationSec);
    if (lastResult.ok || lastResult.kind === 'API_ERROR') {
      return lastResult;
    }
    if (attempt < maxAttempts) {
      await new Promise((r) => setTimeout(r, 350));
    }
  }
  return lastResult;
}

function isAllowedProxyImageHost(hostname: string): boolean {
  const lower = hostname.toLowerCase();
  return (
    lower === 'i.ibb.co' ||
    lower.endsWith('.ibb.co') ||
    lower === 'lh3.googleusercontent.com' ||
    lower.endsWith('.googleusercontent.com')
  );
}

async function startServer(): Promise<void> {
  const app = express();
  const httpServer = http.createServer(app);

  app.use(express.json({ limit: '12mb' }));

  // Server-side ImgBB upload proxy:
  // Bypasses mobile ISP DNS/SNI blocks on api.imgbb.com and browser CORS issues.
  // Never logs or echoes any API key.
  app.post('/api/imgbb-upload', async (req: Request, res: Response) => {
    const body = (req.body || {}) as {
      apiKey?: unknown;
      image?: unknown;
      expiration?: unknown;
    };

    const envKey = cleanServerImgbbKey(
      process.env.IMGBB_API_KEY ||
        process.env.IMGBB_KEY ||
        process.env.VITE_IMGBB_KEY ||
        '2b6fd19d7400ea00ad678227895f6727'
    );
    const providedKey = cleanServerImgbbKey(body.apiKey);
    const effectiveKey = providedKey || envKey;

    if (!effectiveKey) {
      res.status(200).json({
        ok: false,
        kind: 'API_ERROR',
        errorMessage: 'Valid ImgBB API key missing.',
      });
      return;
    }

    if (typeof body.image !== 'string' || body.image.trim().length < 16) {
      res.status(400).json({
        ok: false,
        kind: 'API_ERROR',
        errorMessage: 'Invalid image payload.',
      });
      return;
    }

    const base64Payload = stripDataUrlPrefix(body.image);
    const expirationSec =
      typeof body.expiration === 'number' && Number.isFinite(body.expiration)
        ? body.expiration
        : undefined;

    const result = await postToImgbbWithRetry(effectiveKey, base64Payload, expirationSec);
    res.status(200).json(result);
  });

  // Allowlisted read-only image proxy for i.ibb.co so uploaded photos still render
  // on Indian mobile carriers (Jio / Airtel / Vi) if i.ibb.co is blocked by ISP DNS.
  app.get('/api/image-proxy', (req: Request, res: Response) => {
    const rawUrl = typeof req.query.url === 'string' ? req.query.url.trim() : '';
    let parsedUrl: URL;
    try {
      parsedUrl = new URL(rawUrl);
    } catch {
      res.status(400).end('Invalid URL');
      return;
    }

    if (parsedUrl.protocol !== 'https:' || !isAllowedProxyImageHost(parsedUrl.hostname)) {
      res.status(403).end('Forbidden host');
      return;
    }

    const upstreamReq = https.get(
      parsedUrl.toString(),
      {
        headers: {
          'User-Agent': BROWSER_UA,
          Accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
        },
        timeout: 12000,
      },
      (upstreamRes) => {
        const status = upstreamRes.statusCode || 502;
        if (status >= 300 && status < 400 && upstreamRes.headers.location) {
          try {
            const redirected = new URL(upstreamRes.headers.location, parsedUrl);
            if (redirected.protocol === 'https:' && isAllowedProxyImageHost(redirected.hostname)) {
              res.redirect(302, `/api/image-proxy?url=${encodeURIComponent(redirected.toString())}`);
              upstreamRes.resume();
              return;
            }
          } catch {
            // Fall through to error
          }
        }

        if (status < 200 || status >= 300) {
          upstreamRes.resume();
          res.status(status).end();
          return;
        }

        const contentType = String(upstreamRes.headers['content-type'] || 'image/jpeg');
        if (!contentType.toLowerCase().startsWith('image/')) {
          upstreamRes.resume();
          res.status(415).end();
          return;
        }
        res.setHeader('Content-Type', contentType);
        res.setHeader('Cache-Control', 'public, max-age=86400, immutable');
        upstreamRes.pipe(res);
      }
    );

    upstreamReq.on('timeout', () => {
      upstreamReq.destroy();
      if (!res.headersSent) res.status(504).end();
    });

    upstreamReq.on('error', () => {
      if (!res.headersSent) res.status(502).end();
    });
  });

  const isProduction =
    process.env.NODE_ENV === 'production' || process.env.npm_lifecycle_event === 'start';

  if (!isProduction) {
    process.env.DISABLE_HMR = 'true';
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: { server: httpServer },
        hmr: false,
        ws: { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req: Request, res: Response) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

void startServer();
