/**
 * Business Media — Google Apps Script for Name-Only Viewers
 *
 * Setup Instructions:
 * 1. Open Google Sheets (https://sheets.new) and name the spreadsheet "Business Media Viewers".
 * 2. In Row 1 of the active tab, enter headers:
 *      Cell A1: Time
 *      Cell B1: Name
 * 3. Click Extensions > Apps Script.
 * 4. Delete any existing code in Code.gs and paste this entire file.
 * 5. Click Save (Ctrl+S / Cmd+S).
 * 6. Click Deploy > New deployment.
 *    - Select type (gear icon): Web app
 *    - Description: Business Media Viewer Logger
 *    - Execute as: Me
 *    - Who has access: Anyone
 * 7. Click Deploy, authorize access with your Google account, and copy the Web app URL
 *    (ending in /exec) into APPS_SCRIPT_URL inside src/config.ts.
 *
 * Monthly Maintenance:
 * - Download the sheet monthly via File > Download > Comma Separated Values (.csv) or Excel (.xlsx).
 * - Delete ONLY old data rows (Row 2 onwards). NEVER delete Row 1 (headers) or the sheet tab.
 */

function doPost(e) {
  try {
    var rawName = (e && e.parameter && typeof e.parameter.name === 'string')
      ? e.parameter.name
      : '';

    var cleanName = rawName.trim();
    if (!cleanName) {
      return ContentService
        .createTextOutput('invalid_empty_name')
        .setMimeType(ContentService.MimeType.TEXT);
    }

    if (cleanName.length > 50) {
      cleanName = cleanName.substring(0, 50).trim();
    }

    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    sheet.appendRow([new Date(), cleanName]);

    return ContentService
      .createTextOutput('ok')
      .setMimeType(ContentService.MimeType.TEXT);
  } catch (err) {
    return ContentService
      .createTextOutput('error')
      .setMimeType(ContentService.MimeType.TEXT);
  }
}
