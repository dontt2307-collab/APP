import type { QueryDocumentSnapshot, DocumentData, Timestamp } from 'firebase/firestore';

export type TabId = 'home' | 'sarkari' | 'upload' | 'search' | 'profile' | 'admin_dashboard';

export type AdminTabId = 'overview' | 'reports' | 'members' | 'notifications' | 'nameManagement'
  // ===== ADDED: POSTS FEATURE START =====
  | 'postsUsers';
// ===== ADDED: POSTS FEATURE END =====

export interface NameViewerRecord {
  id: string;
  name: string;
  createdAt: any;
  dateKey?: string;
}

export type PostCategory = 'general' | 'sarkari_naukri' | 'business';

export type AuthModalMode = 'login' | 'viewer';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export interface UserProfile {
  uid: string;
  fullName: string;
  userName: string;
  userNameLower: string;
  bio: string;
  dpUrl: string;
  postCount: number;
  warnings?: number; // 0..3
  reminderSentAt?: Timestamp | null;
  createdAt?: Timestamp | null;
  updatedAt?: Timestamp | null;
}

export interface PostItem {
  id: string;
  uid: string;
  userFullName: string;
  userName: string;
  userNameLower: string;
  userDpUrl: string;
  category: PostCategory;
  likedBy: string[];
  caption: string;
  keywords: string[];
  imageUrl: string;
  createdAt: Timestamp | null;
  expireAt?: Timestamp | null;
}

export interface PaginatedPostsResult {
  posts: PostItem[];
  lastDoc: QueryDocumentSnapshot<DocumentData> | null;
  hasMore: boolean;
  limitExceeded?: boolean;
}

export interface SearchCursors {
  prefixLastDoc: QueryDocumentSnapshot<DocumentData> | null;
  keywordLastDoc: QueryDocumentSnapshot<DocumentData> | null;
  prefixHasMore: boolean;
  keywordHasMore: boolean;
}

export interface ReportItem {
  id: string; // postId_reporterUid
  postId: string;
  postOwnerUid: string;
  postOwnerName: string;
  postImageUrl: string;
  postCaption: string;
  reporterUid: string;
  reporterName: string;
  reason: string;
  note?: string;
  createdAt: Timestamp | null;
}

export interface NotificationItem {
  id: string;
  title: string;
  body: string;
  to?: 'all' | string; // 'all' or specific member uid
  createdAt: Timestamp | null;
  editedAt?: Timestamp | null;
}

export interface ViewerItem {
  id: string;
  name: string;
  createdAt: Timestamp | null;
}

export const ADMIN_EMAILS = ['dxobad000@gmail.com'] as const;
export const ADMIN_EMAIL = 'dxobad000@gmail.com';

export function isEmailAdmin(email?: string | null): boolean {
  if (!email) return false;
  const clean = email.trim().toLowerCase();
  return clean === ADMIN_EMAIL;
}
