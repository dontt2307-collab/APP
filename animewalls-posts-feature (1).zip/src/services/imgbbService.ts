import { doc, getDoc, serverTimestamp, setDoc } from 'firebase/firestore';
import { IMGBB_KEY } from '../config';
import { db } from '../firebase';

export type ImgbbFailureKind = 'NETWORK_ERROR' | 'ALL_KEYS_FAILED';

export class ImgbbUploadError extends Error {
  public readonly kind: ImgbbFailureKind;

  constructor(kind: ImgbbFailureKind, message: string) {
    super(message);
    this.name = 'ImgbbUploadError';
    this.kind = kind;
  }
}

const ACTIVE_DEVICE_KEYS_STORAGE = 'bm_imgbb_keys_active';

function userStorageKey(uid: string): string {
  return `bm_imgbb_keys_${uid}`;
}

function userSeedStateKey(uid: string): string {
  return `bm_imgbb_seed_state_${uid || 'device'}`;
}

/**
 * Extracts and sanitizes a valid ImgBB v1 API key even if the user pasted:
 * - Extra spaces, newlines, or quotes ("abc...")
 * - Clipboard text with labels like "API key: 2b6f..."
 * - Full example URL: https://api.imgbb.com/1/upload?expiration=600&key=abcdef...
 * - Key-value snippet: key=abcdef...
 * Returns '' if invalid or if a bare URL without ?key= was pasted.
 */
export function cleanImgbbKey(raw: string): string {
  if (!raw) return '';
  let text = raw.trim().replace(/^["'`]+|["'`]+$/g, '').trim();

  const urlKeyMatch = text.match(/[?&]key=([a-zA-Z0-9_-]{8,128})/);
  if (urlKeyMatch?.[1]) {
    return urlKeyMatch[1];
  }

  const hex32Match = text.match(/(?:^|[^a-zA-Z0-9])([a-fA-F0-9]{32})(?:$|[^a-zA-Z0-9])/);
  if (hex32Match?.[1]) {
    return hex32Match[1];
  }

  const kvMatch = text.match(/^(?:api\s*)?key\s*[:=]\s*([a-zA-Z0-9_-]{8,128})$/i);
  if (kvMatch?.[1]) {
    return kvMatch[1];
  }

  text = text.replace(/\s+/g, '');

  if (/^https?:\/\//i.test(text)) {
    return '';
  }

  if (
    text.length < 8 ||
    text.length > 128 ||
    text === 'YOUR_IMGBB_API_KEY_HERE' ||
    text.startsWith('YOUR_') ||
    !/^[a-zA-Z0-9_-]+$/.test(text)
  ) {
    return '';
  }

  return text;
}

function dedupeCleanKeys(list: unknown[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const item of list) {
    if (typeof item !== 'string') continue;
    const cleaned = cleanImgbbKey(item);
    if (cleaned && !seen.has(cleaned)) {
      seen.add(cleaned);
      out.push(cleaned);
      if (out.length >= 10) break;
    }
  }
  return out;
}

function readLocalKeys(uid?: string): string[] {
  try {
    const merged: unknown[] = [];
    if (uid) {
      const rawUser = localStorage.getItem(userStorageKey(uid));
      if (rawUser) {
        const parsed = JSON.parse(rawUser) as unknown;
        if (Array.isArray(parsed)) merged.push(...parsed);
      }
    }
    const rawActive = localStorage.getItem(ACTIVE_DEVICE_KEYS_STORAGE);
    if (rawActive) {
      const parsedActive = JSON.parse(rawActive) as unknown;
      if (Array.isArray(parsedActive)) merged.push(...parsedActive);
    }
    return dedupeCleanKeys(merged);
  } catch {
    return [];
  }
}

function writeLocalKeys(uid: string, keys: string[]): void {
  try {
    const serialized = JSON.stringify(keys);
    if (uid) {
      localStorage.setItem(userStorageKey(uid), serialized);
    }
    localStorage.setItem(ACTIVE_DEVICE_KEYS_STORAGE, serialized);
  } catch {
    // Ignore storage quota / private mode errors
  }
}

export function clearActiveDeviceImgbbKeys(): void {
  try {
    localStorage.removeItem(ACTIVE_DEVICE_KEYS_STORAGE);
  } catch {
    // Ignore storage error
  }
}

/**
 * Masks an API key so the raw key is NEVER rendered in the saved list or logged.
 */
export function maskImgbbKey(index: number, totalLength: number): string {
  const dots = '••••••••••••';
  return `Key #${index + 1} (${dots} · ${totalLength} chars)`;
}

/**
 * If an image is hosted on i.ibb.co / *.ibb.co and fails direct loading on
 * an ISP that blocks ibb.co, returns our same-origin /api/image-proxy fallback URL.
 */
export function getImgbbProxyFallbackUrl(src: string): string | null {
  if (!src || src.startsWith('/api/image-proxy') || src.startsWith('data:') || src.startsWith('blob:')) {
    return null;
  }
  try {
    const u = new URL(src);
    const host = u.hostname.toLowerCase();
    if (
      u.protocol === 'https:' &&
      (host === 'i.ibb.co' ||
        host.endsWith('.ibb.co') ||
        host === 'lh3.googleusercontent.com' ||
        host.endsWith('.googleusercontent.com'))
    ) {
      return `/api/image-proxy?url=${encodeURIComponent(src)}`;
    }
  } catch {
    return null;
  }
  return null;
}

/**
 * Reads owner's private ImgBB keys from users/{uid}/private/imgbb merged with
 * local device cache, and auto-seeds the configured default IMGBB_KEY so Settings
 * already has the ImgBB key ready out-of-the-box without errors.
 * Never logs any key values.
 */
export async function getMemberImgbbKeys(uid: string): Promise<string[]> {
  const localKeys = readLocalKeys(uid);
  const defaultClean = cleanImgbbKey(IMGBB_KEY);
  let userClearedAll = false;
  try {
    userClearedAll = localStorage.getItem(userSeedStateKey(uid)) === 'cleared';
  } catch {
    userClearedAll = false;
  }

  if (!uid) {
    if (localKeys.length > 0) return localKeys;
    return !userClearedAll && defaultClean ? [defaultClean] : [];
  }

  try {
    const snap = await getDoc(doc(db, 'users', uid, 'private', 'imgbb'));
    if (!snap.exists()) {
      const initialKeys =
        localKeys.length > 0
          ? localKeys
          : !userClearedAll && defaultClean
            ? [defaultClean]
            : [];

      if (initialKeys.length > 0) {
        writeLocalKeys(uid, initialKeys);
        void setDoc(doc(db, 'users', uid, 'private', 'imgbb'), {
          keys: initialKeys,
          updatedAt: serverTimestamp(),
        }).catch(() => {});
      }
      return initialKeys;
    }

    const rawData = snap.data();
    const firestoreKeys = Array.isArray(rawData?.keys) ? dedupeCleanKeys(rawData.keys) : [];
    let merged = dedupeCleanKeys([...firestoreKeys, ...localKeys]);

    if (merged.length === 0 && !userClearedAll && defaultClean) {
      merged = [defaultClean];
      void setDoc(doc(db, 'users', uid, 'private', 'imgbb'), {
        keys: merged,
        updatedAt: serverTimestamp(),
      }).catch(() => {});
    }

    writeLocalKeys(uid, merged);
    return merged;
  } catch {
    if (localKeys.length > 0) return localKeys;
    const fallback = !userClearedAll && defaultClean ? [defaultClean] : [];
    if (fallback.length > 0) {
      writeLocalKeys(uid, fallback);
    }
    return fallback;
  }
}

/**
 * Saves personal ImgBB keys to both localStorage (instant, zero-failure) and
 * Firestore users/{uid}/private/imgbb (cross-device sync).
 */
export async function saveMemberImgbbKeys(uid: string, keys: string[]): Promise<string[]> {
  const cleaned = dedupeCleanKeys(keys);
  try {
    localStorage.setItem(userSeedStateKey(uid), cleaned.length === 0 ? 'cleared' : 'active');
  } catch {
    // Ignore storage error
  }
  writeLocalKeys(uid, cleaned);

  if (uid) {
    try {
      await setDoc(doc(db, 'users', uid, 'private', 'imgbb'), {
        keys: cleaned,
        updatedAt: serverTimestamp(),
      });
    } catch {
      // Local device copy is already saved, so Settings & uploads never fail
    }
  }

  return cleaned;
}

/**
 * Appends a single new key to the member's key list (putting the newest key FIRST
 * so the freshly added key is tried immediately on the next upload).
 */
export async function prependMemberImgbbKey(uid: string, rawKey: string): Promise<string[]> {
  const cleanedNew = cleanImgbbKey(rawKey);
  if (!cleanedNew) {
    throw new Error(
      'Sahi ImgBB API key paste karo (https://api.imgbb.com se 32-char key copy karo).'
    );
  }
  const existing = await getMemberImgbbKeys(uid);
  const updated = [cleanedNew, ...existing.filter((k) => k !== cleanedNew)].slice(0, 10);
  return saveMemberImgbbKeys(uid, updated);
}

type SingleAttemptResult =
  | { ok: true; url: string }
  | { ok: false; isNetworkError: boolean; apiErrorMessage?: string };

async function tryViaServerProxy(
  apiKey: string,
  base64Payload: string,
  expirationSec?: number
): Promise<SingleAttemptResult | 'PROXY_UNAVAILABLE'> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 22000);

  try {
    const res = await fetch('/api/imgbb-upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        apiKey,
        image: base64Payload,
        ...(expirationSec ? { expiration: expirationSec } : {}),
      }),
      signal: controller.signal,
    });

    if (res.status === 404 || res.status === 405) {
      return 'PROXY_UNAVAILABLE';
    }

    const json = (await res.json()) as {
      ok?: boolean;
      kind?: 'API_ERROR' | 'NETWORK_ERROR';
      url?: string;
      errorMessage?: string;
    };

    if (json?.ok && json.url && json.url.startsWith('https://')) {
      return { ok: true, url: json.url };
    }

    if (json?.kind === 'API_ERROR') {
      return {
        ok: false,
        isNetworkError: false,
        apiErrorMessage: json.errorMessage || 'Invalid ImgBB API key',
      };
    }

    return { ok: false, isNetworkError: true };
  } catch {
    return 'PROXY_UNAVAILABLE';
  } finally {
    window.clearTimeout(timer);
  }
}

async function tryViaDirectBrowserFormData(
  apiKey: string,
  base64Payload: string,
  expirationSec?: number
): Promise<SingleAttemptResult> {
  if (!apiKey) {
    return { ok: false, isNetworkError: false };
  }

  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 20000);

  try {
    const query = new URLSearchParams({ key: apiKey });
    if (expirationSec && expirationSec >= 60) {
      query.set('expiration', String(Math.floor(expirationSec)));
    }

    const formData = new FormData();
    formData.append('image', base64Payload);

    const response = await fetch(`https://api.imgbb.com/1/upload?${query.toString()}`, {
      method: 'POST',
      body: formData,
      signal: controller.signal,
    });

    const json = (await response.json()) as {
      success?: boolean;
      data?: { display_url?: string; url?: string; image?: { url?: string } };
      error?: { message?: string; code?: number };
    };

    const hostedUrl =
      json?.data?.image?.url || json?.data?.display_url || json?.data?.url || '';

    if (response.ok && json?.success && hostedUrl.startsWith('https://')) {
      return { ok: true, url: hostedUrl };
    }

    const errMsg = json?.error?.message || '';
    const isBlockedOrTransient =
      response.status >= 500 ||
      response.status === 403 ||
      json?.error?.code === 103 ||
      errMsg.toLowerCase().includes('forbidden');

    return {
      ok: false,
      isNetworkError: isBlockedOrTransient,
      apiErrorMessage: errMsg,
    };
  } catch {
    return { ok: false, isNetworkError: true };
  } finally {
    window.clearTimeout(timer);
  }
}

async function tryUploadWithSingleKey(
  rawKey: string,
  base64Payload: string,
  expirationSec?: number
): Promise<SingleAttemptResult> {
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    return { ok: false, isNetworkError: true };
  }

  const cleanedKey = cleanImgbbKey(rawKey);
  if (!cleanedKey && rawKey !== '') {
    return { ok: false, isNetworkError: false, apiErrorMessage: 'Invalid API v1 key.' };
  }

  // 1. Primary path: Direct browser multipart/form-data POST from user's residential/mobile IP
  //    (ImgBB sends Access-Control-Allow-Origin: * and blocks Cloud datacenter IPs with code 103)
  if (cleanedKey) {
    const directRes = await tryViaDirectBrowserFormData(cleanedKey, base64Payload, expirationSec);
    if (directRes.ok || !directRes.isNetworkError) {
      return directRes;
    }
  }

  // 2. Fallback path: Same-origin server proxy (/api/imgbb-upload) if direct browser DNS/ISP failed
  const proxyRes = await tryViaServerProxy(cleanedKey, base64Payload, expirationSec);
  if (proxyRes !== 'PROXY_UNAVAILABLE') {
    return proxyRes;
  }

  return { ok: false, isNetworkError: true };
}

/**
 * Validates and cleans an ImgBB API key synchronously so saving a key in Settings
 * is instant and never fails due to carrier DNS blocks, duplicate test pixels, or proxy IP blocks.
 */
export async function verifyImgbbKey(
  rawKey: string
): Promise<{ valid: true } | { valid: false; reason: 'FORMAT' | 'INVALID_KEY'; message: string }> {
  const cleaned = cleanImgbbKey(rawKey);
  if (!cleaned) {
    return {
      valid: false,
      reason: 'FORMAT',
      message:
        'Sahi ImgBB API key paste karo (https://api.imgbb.com par "Get API key" se apni key copy karo).',
    };
  }

  return { valid: true };
}

/**
 * Tries member's saved ImgBB keys (active key first) plus common IMGBB_KEY fallback.
 */
export async function uploadImageWithFallback(
  base64Payload: string,
  uid: string,
  expirationSec?: number
): Promise<string> {
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    throw new ImgbbUploadError(
      'NETWORK_ERROR',
      'Internet band lag raha hai. Connection check karke dobara try karo.'
    );
  }

  const cleanPayload = base64Payload.includes(',')
    ? base64Payload.slice(base64Payload.indexOf(',') + 1).trim()
    : base64Payload.trim();

  // Build ordered candidate list:
  // 1) Active saved keys from Settings (pre-seeded with IMGBB_KEY, or user's newest key first)
  // 2) Configured IMGBB_KEY fallback from src/config.ts
  const personalKeys = await getMemberImgbbKeys(uid);
  const commonClean = cleanImgbbKey(IMGBB_KEY);

  const candidates = dedupeCleanKeys([
    ...personalKeys,
    ...(commonClean ? [commonClean] : []),
  ]);

  let sawNetworkFailure = false;
  let lastApiError = '';

  for (const candidateKey of candidates) {
    const attempt = await tryUploadWithSingleKey(candidateKey, cleanPayload, expirationSec);
    if (attempt.ok) {
      return attempt.url;
    }
    if (attempt.isNetworkError) {
      sawNetworkFailure = true;
    } else if (attempt.apiErrorMessage) {
      lastApiError = attempt.apiErrorMessage;
    }
  }

  // Also try server environment key if no client keys succeeded
  if (candidates.length === 0) {
    const serverEnvAttempt = await tryUploadWithSingleKey('', cleanPayload);
    if (serverEnvAttempt.ok) {
      return serverEnvAttempt.url;
    }
  }

  if (sawNetworkFailure && !lastApiError) {
    throw new ImgbbUploadError(
      'NETWORK_ERROR',
      'ImgBB server tak connect hone me samay lag raha hai. Ek baar Retry dabao.'
    );
  }

  if (candidates.length === 0) {
    throw new ImgbbUploadError(
      'ALL_KEYS_FAILED',
      'Abhi koi ImgBB API key save nahi hai. Niche apni ImgBB API key paste karke seedha upload karo.'
    );
  }

  if (lastApiError.toLowerCase().includes('invalid')) {
    throw new ImgbbUploadError(
      'ALL_KEYS_FAILED',
      'Jo ImgBB API key add ki gayi hai wo galat (Invalid) hai. https://api.imgbb.com se sahi API key copy karke niche daalo.'
    );
  }

  throw new ImgbbUploadError(
    'ALL_KEYS_FAILED',
    'ImgBB upload key kaam nahi kar rahi ya limit poori ho gayi hai. Niche nayi ImgBB API key daalo.'
  );
}
