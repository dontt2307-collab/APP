import {
  arrayRemove,
  arrayUnion,
  collection,
  doc,
  DocumentData,
  getDoc,
  getDocs,
  increment,
  limit,
  orderBy,
  query,
  QueryConstraint,
  QueryDocumentSnapshot,
  serverTimestamp,
  setDoc,
  startAfter,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { onlyAdminCanPostJobs, postVisibleDays, viewerPageSize } from '../config';
import { canReadPosts, isLimitExceeded, recordDocumentReads } from './budgetService';
import { auth, db, handleFirestoreError } from '../firebase';
import {
  isEmailAdmin,
  NotificationItem,
  OperationType,
  PaginatedPostsResult,
  PostCategory,
  PostItem,
  SearchCursors,
  UserProfile,
} from '../types';
import { buildKeywords, getISTDateKey } from '../utils/istDate';
import { setCachedUser } from './userCache';
// ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
import { api, ApiPost, isApiConfigured } from './apiService';
// ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====

export const PAGE_SIZE = 20;
export const DAILY_POST_LIMIT = 20;

export function getTwoDaysAgoTimestamp(): Timestamp {
  const ms = Date.now() - postVisibleDays * 24 * 60 * 60 * 1000;
  return Timestamp.fromMillis(ms);
}

export function isPostOverdue(createdAt: Timestamp | null): boolean {
  if (!createdAt) return false;
  const postMs = createdAt.toMillis?.() ?? 0;
  const cutoffMs = Date.now() - postVisibleDays * 24 * 60 * 60 * 1000;
  return postMs < cutoffMs;
}

// Session-level reactive cache for like state
const likedByOverrides = new Map<string, string[]>();
const inFlightLikePostIds = new Set<string>();
const likeListeners = new Set<() => void>();

function notifyLikeListeners(): void {
  for (const listener of likeListeners) {
    listener();
  }
}

export function subscribePostLikes(listener: () => void): () => void {
  likeListeners.add(listener);
  return () => {
    likeListeners.delete(listener);
  };
}

export function getEffectivePostLikes(post: PostItem): string[] {
  return likedByOverrides.get(post.id) ?? post.likedBy ?? [];
}

function normalizeCategory(cat: unknown): PostCategory {
  if (cat === 'sarkari_naukri') return 'sarkari_naukri';
  return 'general';
}

function docToPostItem(docSnap: QueryDocumentSnapshot<DocumentData>): PostItem {
  const d = docSnap.data();
  const rawLikes = Array.isArray(d.likedBy)
    ? Array.from(new Set(d.likedBy.filter((x: unknown): x is string => typeof x === 'string')))
    : [];
  if (!inFlightLikePostIds.has(docSnap.id)) {
    likedByOverrides.set(docSnap.id, rawLikes);
  }
  const effectiveLikes = likedByOverrides.get(docSnap.id) ?? rawLikes;
  const userName = d.userName || 'member';
  return {
    id: docSnap.id,
    uid: d.uid || '',
    userFullName: d.userFullName || userName,
    userName,
    userNameLower: d.userNameLower || userName.toLowerCase(),
    userDpUrl: d.userDpUrl || '',
    category: normalizeCategory(d.category),
    likedBy: effectiveLikes,
    caption: d.caption || '',
    keywords: Array.isArray(d.keywords) ? d.keywords : [],
    imageUrl: d.imageUrl || '',
    createdAt: d.createdAt || null,
    expireAt: d.expireAt || null,
  };
}

function generateSortablePostId(): string {
  const reverseEpoch = String(Math.max(0, 9999999999999 - Date.now())).padStart(13, '0');
  const randomId = doc(collection(db, 'posts')).id.slice(0, 10);
  return `${reverseEpoch}_${randomId}`;
}

// ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
// When VITE_API_BASE is set, feeds / likes / deletes come from the Flask backend
// (no Firestore read limits). Upload itself still goes through Firebase, then is synced.
// Backend post "ref" is used as PostItem.id (= the Firestore post id for synced posts).
type BackendFeedPost = ApiPost & {
  ref: string;
  category: string;
  username: string | null;
  full_name: string | null;
  dp_url: string | null;
  liked_by: string[];
};

// The pages in HomeView/ProfileView/Sarkari keep an opaque "lastDoc" cursor.
// For backend pages we store { __backendId } there (cast, never sent to Firestore).
function makeBackendCursor(id: number): QueryDocumentSnapshot<DocumentData> {
  return { __backendId: id } as unknown as QueryDocumentSnapshot<DocumentData>;
}
function backendCursorId(c: QueryDocumentSnapshot<DocumentData> | null): number | null {
  const id = (c as unknown as { __backendId?: number } | null)?.__backendId;
  return typeof id === 'number' ? id : null;
}

function backendPostToItem(r: BackendFeedPost): PostItem {
  const ref = r.ref || String(r.id);
  const userName = r.username || r.user_name || 'member';
  const rawLikes = Array.isArray(r.liked_by) ? r.liked_by : [];
  if (!inFlightLikePostIds.has(ref)) likedByOverrides.set(ref, rawLikes);
  const ms = Date.parse(String(r.created_at).replace(' ', 'T') + 'Z');
  return {
    id: ref,
    uid: r.uid,
    userFullName: r.full_name || userName,
    userName,
    userNameLower: userName.toLowerCase(),
    userDpUrl: r.dp_url || r.user_photo || '',
    category: normalizeCategory(r.category),
    likedBy: likedByOverrides.get(ref) ?? rawLikes,
    caption: r.caption || '',
    keywords: [],
    imageUrl: r.url,
    createdAt: Number.isNaN(ms) ? null : Timestamp.fromMillis(ms),
    expireAt: null,
  };
}

async function fetchBackendPage(opts: {
  cursor: QueryDocumentSnapshot<DocumentData> | null;
  category?: PostCategory;
  uid?: string;
  days?: number;
}): Promise<PaginatedPostsResult> {
  const qs = new URLSearchParams({ limit: String(PAGE_SIZE) });
  const before = backendCursorId(opts.cursor);
  if (before !== null) qs.set('before_id', String(before));
  if (opts.category) qs.set('category', opts.category);
  if (opts.uid) qs.set('uid', opts.uid);
  if (opts.days) qs.set('days', String(opts.days));
  const rows = await api<BackendFeedPost[]>(`/api/posts?${qs.toString()}`);
  return {
    posts: rows.map(backendPostToItem),
    lastDoc: rows.length > 0 ? makeBackendCursor(rows[rows.length - 1].id) : null,
    hasMore: rows.length === PAGE_SIZE,
  };
}

/** Best-effort: never blocks or breaks the Firebase flow if the backend is down. */
async function backendQuiet(fn: () => Promise<unknown>): Promise<void> {
  if (!isApiConfigured()) return;
  try {
    await fn();
  } catch (e) {
    console.warn('Backend sync failed:', e);
  }
}

/** After upload (Firebase) -> send the post to the Python backend so ALL users see it. */
export async function syncPostToBackend(post: PostItem, member: UserProfile): Promise<void> {
  await backendQuiet(() =>
    api('/api/posts/sync', {
      method: 'POST',
      body: {
        fid: post.id,
        imageUrl: post.imageUrl,
        caption: post.caption,
        category: post.category,
        userName: member.userName,
        fullName: member.fullName,
        dpUrl: member.dpUrl || '',
      },
    })
  );
}

/** Keep name / username / DP in the backend feed up to date. */
export async function syncProfileToBackend(member: UserProfile): Promise<void> {
  await backendQuiet(() =>
    api('/api/me/profile', {
      method: 'POST',
      body: { userName: member.userName, fullName: member.fullName, dpUrl: member.dpUrl || '' },
    })
  );
}

/** Delete from backend by ref (404 = never synced, fine). Throws on 403 etc. */
export async function deleteBackendPost(ref: string): Promise<void> {
  if (!isApiConfigured()) return;
  try {
    await api(`/api/posts/ref/${encodeURIComponent(ref)}`, { method: 'DELETE' });
  } catch (e) {
    if ((e as { status?: number }).status === 404) return;
    throw e;
  }
}

export function isBackendOnlyRef(ref: string): boolean {
  return /^b\d+$/.test(ref);
}

export async function deleteMyOverdueBackendPosts(): Promise<void> {
  await backendQuiet(() => api(`/api/me/posts/overdue?days=${postVisibleDays}`, { method: 'DELETE' }));
}

/** Admin: one-time copy of existing Firestore posts into the backend. */
export async function importFirestorePostsToBackend(): Promise<number> {
  const snap = await getDocs(
    query(collection(db, 'posts'), orderBy('createdAt', 'asc'), limit(500))
  );
  const posts = snap.docs.map((d) => {
    const x = d.data();
    return {
      fid: d.id,
      uid: x.uid,
      imageUrl: x.imageUrl,
      caption: x.caption || '',
      category: normalizeCategory(x.category),
      userName: x.userName || '',
      fullName: x.userFullName || '',
      dpUrl: x.userDpUrl || '',
      likedBy: Array.isArray(x.likedBy) ? x.likedBy : [],
      createdAtMs: x.createdAt?.toMillis?.() ?? Date.now(),
    };
  });
  if (posts.length === 0) return 0;
  const res = await api<{ imported: number }>('/api/admin/import', { method: 'POST', body: { posts } });
  return res.imported;
}
// ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====

/**
 * Home tab: All posts within the last 2 days (postVisibleDays = 2), newest first.
 * For guests and name-only viewers: loads viewerPageSize (10) at a time and checks budget allowance.
 */
export async function fetchPostsPage(
  cursor: QueryDocumentSnapshot<DocumentData> | null,
  isMemberOrAdmin = false
): Promise<PaginatedPostsResult> {
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
  if (isApiConfigured()) {
    return fetchBackendPage({ cursor, days: postVisibleDays });
  }
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====
  if (!isMemberOrAdmin && isLimitExceeded()) {
    return { posts: [], lastDoc: null, hasMore: false, limitExceeded: true };
  }

  try {
    const pageSize = isMemberOrAdmin ? PAGE_SIZE : viewerPageSize;
    const twoDaysAgo = getTwoDaysAgoTimestamp();
    const constraints: QueryConstraint[] = [
      where('createdAt', '>=', twoDaysAgo),
      orderBy('createdAt', 'desc'),
      limit(pageSize),
    ];
    if (cursor) {
      constraints.push(startAfter(cursor));
    }
    const q = query(collection(db, 'posts'), ...constraints);
    const snap = await getDocs(q);

    // Record document reads for guests and viewers
    recordDocumentReads(snap.docs.length, isMemberOrAdmin);

    const posts = snap.docs.map(docToPostItem);
    const lastDoc = snap.docs.length > 0 ? snap.docs[snap.docs.length - 1] : null;
    const hitLimitNow = !isMemberOrAdmin && isLimitExceeded();

    return {
      posts,
      lastDoc,
      hasMore: !hitLimitNow && snap.docs.length === pageSize,
      limitExceeded: hitLimitNow,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'posts');
    return { posts: [], lastDoc: null, hasMore: false };
  }
}

/**
 * Sarkari Naukri tab: ONLY posts with category == 'sarkari_naukri' within the last 2 days.
 */
export async function fetchCategoryPostsPage(
  category: PostCategory,
  cursor: QueryDocumentSnapshot<DocumentData> | null,
  isMemberOrAdmin = false
): Promise<PaginatedPostsResult> {
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
  if (isApiConfigured()) {
    return fetchBackendPage({ cursor, category, days: postVisibleDays });
  }
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====
  if (!isMemberOrAdmin && isLimitExceeded()) {
    return { posts: [], lastDoc: null, hasMore: false, limitExceeded: true };
  }

  try {
    const pageSize = isMemberOrAdmin ? PAGE_SIZE : viewerPageSize;
    const twoDaysAgo = getTwoDaysAgoTimestamp();
    const constraints: QueryConstraint[] = [
      where('category', '==', category),
      where('createdAt', '>=', twoDaysAgo),
      orderBy('createdAt', 'desc'),
      limit(pageSize),
    ];
    if (cursor) {
      constraints.push(startAfter(cursor));
    }
    const q = query(collection(db, 'posts'), ...constraints);
    const snap = await getDocs(q);

    // Record document reads for guests and viewers
    recordDocumentReads(snap.docs.length, isMemberOrAdmin);

    const posts = snap.docs.map(docToPostItem);
    const lastDoc = snap.docs.length > 0 ? snap.docs[snap.docs.length - 1] : null;
    const hitLimitNow = !isMemberOrAdmin && isLimitExceeded();

    return {
      posts,
      lastDoc,
      hasMore: !hitLimitNow && snap.docs.length === pageSize,
      limitExceeded: hitLimitNow,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'posts');
    return { posts: [], lastDoc: null, hasMore: false };
  }
}

/**
 * Member posts:
 * - Owner viewing OWN profile or Admin: sees ALL their posts (including overdue ones), 20 at a time.
 * - Others viewing: sees ONLY posts within the last 2 days.
 */
export async function fetchMemberPostsPage(
  uid: string,
  cursor: QueryDocumentSnapshot<DocumentData> | null,
  isOwnerOrAdmin = false
): Promise<PaginatedPostsResult> {
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
  if (isApiConfigured()) {
    return fetchBackendPage({ cursor, uid, days: isOwnerOrAdmin ? undefined : postVisibleDays });
  }
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====
  if (!isOwnerOrAdmin && isLimitExceeded()) {
    return { posts: [], lastDoc: null, hasMore: false, limitExceeded: true };
  }

  try {
    const pageSize = isOwnerOrAdmin ? PAGE_SIZE : viewerPageSize;
    const constraints: QueryConstraint[] = [where('uid', '==', uid)];

    if (!isOwnerOrAdmin) {
      constraints.push(where('createdAt', '>=', getTwoDaysAgoTimestamp()));
    }

    constraints.push(orderBy('createdAt', 'desc'), limit(pageSize));

    if (cursor) {
      constraints.push(startAfter(cursor));
    }
    const q = query(collection(db, 'posts'), ...constraints);
    const snap = await getDocs(q);

    recordDocumentReads(snap.docs.length, isOwnerOrAdmin);

    const posts = snap.docs.map(docToPostItem);
    const lastDoc = snap.docs.length > 0 ? snap.docs[snap.docs.length - 1] : null;
    const hitLimitNow = !isOwnerOrAdmin && isLimitExceeded();

    return {
      posts,
      lastDoc,
      hasMore: !hitLimitNow && snap.docs.length === pageSize,
      limitExceeded: hitLimitNow,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'posts');
    return { posts: [], lastDoc: null, hasMore: false };
  }
}

/**
 * Search posts: covers all posts within the last 2 days matching prefix or keyword.
 */
export async function searchPostsMerged(
  rawQuery: string,
  prevCursors?: SearchCursors,
  isMemberOrAdmin = false
): Promise<{ posts: PostItem[]; cursors: SearchCursors; hasMore: boolean; limitExceeded?: boolean }> {
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
  if (isApiConfigured()) {
    const term = rawQuery.trim();
    const emptyCursors: SearchCursors = {
      prefixLastDoc: null,
      keywordLastDoc: null,
      prefixHasMore: false,
      keywordHasMore: false,
    };
    if (!term || (prevCursors && !prevCursors.prefixHasMore)) {
      return { posts: [], cursors: emptyCursors, hasMore: false };
    }
    const qs = new URLSearchParams({ q: term, limit: String(PAGE_SIZE), days: String(postVisibleDays) });
    const before = backendCursorId(prevCursors?.prefixLastDoc ?? null);
    if (before !== null) qs.set('before_id', String(before));
    const rows = await api<BackendFeedPost[]>(`/api/search?${qs.toString()}`);
    const more = rows.length === PAGE_SIZE;
    return {
      posts: rows.map(backendPostToItem),
      cursors: {
        ...emptyCursors,
        prefixLastDoc: rows.length ? makeBackendCursor(rows[rows.length - 1].id) : prevCursors?.prefixLastDoc ?? null,
        prefixHasMore: more,
      },
      hasMore: more,
    };
  }
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====
  if (!isMemberOrAdmin && isLimitExceeded()) {
    return {
      posts: [],
      cursors: { prefixLastDoc: null, keywordLastDoc: null, prefixHasMore: false, keywordHasMore: false },
      hasMore: false,
      limitExceeded: true,
    };
  }

  const normalized = rawQuery.trim().toLowerCase();
  if (!normalized) {
    return {
      posts: [],
      cursors: {
        prefixLastDoc: null,
        keywordLastDoc: null,
        prefixHasMore: false,
        keywordHasMore: false,
      },
      hasMore: false,
    };
  }

  const firstWord =
    normalized
      .replace(/[#@.,!?;:()"'`~[\]{}<>/\\|+*=]+/g, ' ')
      .split(/\s+/)
      .filter(Boolean)[0] || normalized;

  const shouldRunPrefix = !prevCursors || prevCursors.prefixHasMore;
  const shouldRunKeyword = !prevCursors || prevCursors.keywordHasMore;
  const pageSize = isMemberOrAdmin ? PAGE_SIZE : viewerPageSize;

  try {
    const tasks: [
      Promise<QueryDocumentSnapshot<DocumentData>[]>,
      Promise<QueryDocumentSnapshot<DocumentData>[]>
    ] = [
      shouldRunPrefix
        ? (async () => {
            const c: QueryConstraint[] = [
              orderBy('userNameLower'),
              where('userNameLower', '>=', normalized),
              where('userNameLower', '<=', normalized + '\uf8ff'),
              limit(pageSize),
            ];
            if (prevCursors?.prefixLastDoc) {
              c.push(startAfter(prevCursors.prefixLastDoc));
            }
            const s = await getDocs(query(collection(db, 'posts'), ...c));
            return s.docs;
          })()
        : Promise.resolve([]),
      shouldRunKeyword
        ? (async () => {
            const c: QueryConstraint[] = [
              where('keywords', 'array-contains', firstWord),
              limit(pageSize),
            ];
            if (prevCursors?.keywordLastDoc) {
              c.push(startAfter(prevCursors.keywordLastDoc));
            }
            const s = await getDocs(query(collection(db, 'posts'), ...c));
            return s.docs;
          })()
        : Promise.resolve([]),
    ];

    const [prefixDocs, keywordDocs] = await Promise.all(tasks);

    // Record document reads
    const totalDocsRead = prefixDocs.length + keywordDocs.length;
    recordDocumentReads(totalDocsRead, isMemberOrAdmin);

    const mergedMap = new Map<string, PostItem>();
    const twoDaysAgo = getTwoDaysAgoTimestamp();
    const cutoffMs = twoDaysAgo.toMillis();

    for (const d of prefixDocs) {
      const p = docToPostItem(d);
      const postMs = p.createdAt?.toMillis?.() ?? 0;
      if (postMs >= cutoffMs) {
        mergedMap.set(d.id, p);
      }
    }
    for (const d of keywordDocs) {
      if (!mergedMap.has(d.id)) {
        const p = docToPostItem(d);
        const postMs = p.createdAt?.toMillis?.() ?? 0;
        if (postMs >= cutoffMs) {
          mergedMap.set(d.id, p);
        }
      }
    }

    const mergedList = Array.from(mergedMap.values()).sort((a, b) => {
      const aMs = a.createdAt?.toMillis?.() ?? 0;
      const bMs = b.createdAt?.toMillis?.() ?? 0;
      return bMs - aMs;
    });

    const nextCursors: SearchCursors = {
      prefixLastDoc:
        prefixDocs.length > 0
          ? prefixDocs[prefixDocs.length - 1]
          : prevCursors?.prefixLastDoc ?? null,
      keywordLastDoc:
        keywordDocs.length > 0
          ? keywordDocs[keywordDocs.length - 1]
          : prevCursors?.keywordLastDoc ?? null,
      prefixHasMore: shouldRunPrefix && prefixDocs.length === PAGE_SIZE,
      keywordHasMore: shouldRunKeyword && keywordDocs.length === PAGE_SIZE,
    };

    return {
      posts: mergedList,
      cursors: nextCursors,
      hasMore: nextCursors.prefixHasMore || nextCursors.keywordHasMore,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'posts');
  }
}

export async function getTodayPostCount(uid: string): Promise<{ count: number; dateKey: string }> {
  const dateKey = getISTDateKey();
  const countId = `${uid}_${dateKey}`;
  try {
    const snap = await getDoc(doc(db, 'postCounts', countId));
    const count = snap.exists() && typeof snap.data().count === 'number' ? snap.data().count : 0;
    return { count, dateKey };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `postCounts/${countId}`);
  }
}

export async function createPostAtomic(params: {
  member: UserProfile;
  category?: PostCategory;
  caption: string;
  imageUrl: string;
  deleteUrl?: string; // ImgBB delete URL
}): Promise<PostItem> {
  const { member, caption, imageUrl, deleteUrl } = params;
  const requestedCategory = params.category || 'general';
  const cleanCaption = caption.trim().slice(0, 500);
  const dateKey = getISTDateKey();
  const countId = `${member.uid}_${dateKey}`;
  const countRef = doc(db, 'postCounts', countId);

  const isAdmin = isEmailAdmin(auth.currentUser?.email);

  if (onlyAdminCanPostJobs && requestedCategory === 'sarkari_naukri' && !isAdmin) {
    throw new Error('ONLY_ADMIN_CAN_POST_JOBS');
  }

  let existingDailyCount = 0;
  let countDocExists = false;
  try {
    const countSnap = await getDoc(countRef);
    countDocExists = countSnap.exists();
    const rawDaily = countSnap.data()?.count;
    existingDailyCount = typeof rawDaily === 'number' ? rawDaily : 0;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `postCounts/${countId}`);
  }

  if (!isAdmin && existingDailyCount >= DAILY_POST_LIMIT) {
    throw new Error('DAILY_LIMIT_REACHED');
  }

  const postId = generateSortablePostId();
  const postRef = doc(db, 'posts', postId);
  const userRef = doc(db, 'users', member.uid);
  const categoryKeywordText =
    requestedCategory === 'sarkari_naukri' ? 'sarkari naukri job' : 'general post';
  const keywords = buildKeywords(
    `${member.fullName} ${member.userName}`,
    `${categoryKeywordText} ${cleanCaption}`
  );

  // Backup auto-delete: expireAt = now + 7 days
  const expireAtTimestamp = Timestamp.fromMillis(Date.now() + 7 * 24 * 60 * 60 * 1000);

  const batch = writeBatch(db);

  batch.set(postRef, {
    uid: member.uid,
    userFullName: member.fullName || member.userName,
    userName: member.userName,
    userNameLower: member.userNameLower,
    userDpUrl: member.dpUrl || '',
    category: requestedCategory,
    likedBy: [],
    caption: cleanCaption,
    keywords,
    imageUrl,
    createdAt: serverTimestamp(),
    expireAt: expireAtTimestamp,
  });

  if (deleteUrl) {
    batch.set(doc(db, 'postPrivate', postId), { deleteUrl });
  }

  if (!countDocExists) {
    batch.set(countRef, {
      uid: member.uid,
      dateKey,
      count: 1,
      lastPostId: postId,
      updatedAt: serverTimestamp(),
    });
  } else {
    batch.update(countRef, {
      count: increment(1),
      lastPostId: postId,
      updatedAt: serverTimestamp(),
    });
  }

  batch.update(userRef, {
    postCount: increment(1),
    updatedAt: serverTimestamp(),
  });

  try {
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `posts/${postId}`);
  }

  const updatedProfile: UserProfile = {
    ...member,
    postCount: member.postCount + 1,
  };
  setCachedUser(updatedProfile);
  likedByOverrides.set(postId, []);

  const createdItem: PostItem = {
    id: postId,
    uid: member.uid,
    userFullName: member.fullName || member.userName,
    userName: member.userName,
    userNameLower: member.userNameLower,
    userDpUrl: member.dpUrl || '',
    category: requestedCategory,
    likedBy: [],
    caption: cleanCaption,
    keywords,
    imageUrl,
    createdAt: null,
    expireAt: expireAtTimestamp,
  };

  // ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
  // Firebase upload is done -> now send the post to the Python backend for all users.
  await syncPostToBackend(createdItem, member);
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====
  return createdItem;
}

export async function togglePostLike(post: PostItem, memberUid: string): Promise<void> {
  if (!memberUid || !auth.currentUser || auth.currentUser.uid !== memberUid) {
    return;
  }
  if (inFlightLikePostIds.has(post.id)) {
    return;
  }

  const previous = getEffectivePostLikes(post);
  const alreadyLiked = previous.includes(memberUid);
  const next = alreadyLiked
    ? previous.filter((id) => id !== memberUid)
    : [...previous, memberUid];

  inFlightLikePostIds.add(post.id);
  likedByOverrides.set(post.id, next);
  notifyLikeListeners();

  try {
    // ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
    if (isApiConfigured()) {
      const res = await api<{ liked_by: string[] }>(
        `/api/posts/ref/${encodeURIComponent(post.id)}/like`,
        { method: 'POST' }
      );
      likedByOverrides.set(post.id, res.liked_by);
      return;
    }
    // ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====
    await updateDoc(doc(db, 'posts', post.id), {
      likedBy: alreadyLiked ? arrayRemove(memberUid) : arrayUnion(memberUid),
    });
  } catch (error) {
    console.error('Failed to persist post like:', error);
    likedByOverrides.set(post.id, previous);
    notifyLikeListeners();
  } finally {
    inFlightLikePostIds.delete(post.id);
  }
}

export async function reportPost(params: {
  post?: PostItem;
  postId?: string;
  postOwnerUid?: string;
  postOwnerName?: string;
  postImageUrl?: string;
  postCaption?: string;
  reporter?: UserProfile;
  reporterUid?: string;
  reporterName?: string;
  reason: string;
  note?: string;
}): Promise<void> {
  const postId = params.postId || params.post?.id || '';
  const reporterUid = params.reporterUid || params.reporter?.uid || auth.currentUser?.uid || '';
  if (!postId || !reporterUid) return;

  const reportId = `${postId}_${reporterUid}`;
  const reportRef = doc(db, 'reports', reportId);

  try {
    const snap = await getDoc(reportRef);
    if (snap.exists()) {
      throw new Error('ALREADY_REPORTED');
    }

    await setDoc(reportRef, {
      postId,
      postOwnerUid: params.postOwnerUid || params.post?.uid || '',
      postOwnerName: params.postOwnerName || params.post?.userFullName || params.post?.userName || 'Member',
      postImageUrl: params.postImageUrl || params.post?.imageUrl || '',
      postCaption: params.postCaption || params.post?.caption || '',
      reporterUid,
      reporterName: params.reporterName || params.reporter?.fullName || params.reporter?.userName || 'Member',
      reason: params.reason,
      note: params.note ? params.note.trim().slice(0, 200) : '',
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    if (error instanceof Error && error.message === 'ALREADY_REPORTED') {
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, `reports/${reportId}`);
  }
}

/**
 * Single post deletion by owner:
 * Decrements postCount and removes post & related private doc.
 */
export async function deletePostAtomic(postId: string, member: UserProfile): Promise<void> {
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
  await deleteBackendPost(postId); // throws if not allowed; 404 (never synced) is ignored
  if (isBackendOnlyRef(postId)) return; // created via Community Posts: not in Firestore
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====
  const batch = writeBatch(db);

  batch.delete(doc(db, 'posts', postId));

  batch.update(doc(db, 'users', member.uid), {
    postCount: increment(-1),
    lastDeletedPostId: postId,
    updatedAt: serverTimestamp(),
  });

  batch.delete(doc(db, 'postPrivate', postId));

  try {
    await batch.commit();
    setCachedUser({
      ...member,
      postCount: Math.max(0, member.postCount - 1),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `posts/${postId}`);
  }
}

/**
 * "Sab purani posts hatao":
 * Deletes all of the member's own posts older than 2 days in batches of up to 400,
 * decreasing postCount accordingly and deleting related postPrivate and report documents.
 */
export async function deleteAllOverduePostsForOwner(
  member: UserProfile
): Promise<{ deletedCount: number }> {
  const twoDaysAgo = getTwoDaysAgoTimestamp();
  let totalDeleted = 0;
  let hasMoreOverdue = true;

  while (hasMoreOverdue) {
    const overdueQuery = query(
      collection(db, 'posts'),
      where('uid', '==', member.uid),
      where('createdAt', '<', twoDaysAgo),
      limit(400)
    );

    const snap = await getDocs(overdueQuery);
    if (snap.empty) {
      break;
    }

    const postIds = snap.docs.map((d) => d.id);
    const batch = writeBatch(db);

    // 1. Delete post documents
    for (const postDoc of snap.docs) {
      batch.delete(postDoc.ref);
      batch.delete(doc(db, 'postPrivate', postDoc.id));
    }

    // 2. Fetch and delete related reports
    for (const pid of postIds.slice(0, 50)) {
      try {
        const repSnap = await getDocs(query(collection(db, 'reports'), where('postId', '==', pid), limit(20)));
        repSnap.docs.forEach((r) => batch.delete(r.ref));
      } catch {
        // Continue even if report read fails
      }
    }

    // 3. Decrement user postCount
    const countToDelete = snap.docs.length;
    batch.update(doc(db, 'users', member.uid), {
      postCount: increment(-countToDelete),
      updatedAt: serverTimestamp(),
    });

    await batch.commit();
    totalDeleted += countToDelete;

    if (snap.docs.length < 400) {
      hasMoreOverdue = false;
    }
  }

  // ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
  await deleteMyOverdueBackendPosts();
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====

  if (totalDeleted > 0) {
    setCachedUser({
      ...member,
      postCount: Math.max(0, member.postCount - totalDeleted),
    });
  }

  return { deletedCount: totalDeleted };
}

/**
 * Fetch member's notifications where to == 'all' or to == member.uid (20 at a time, newest first).
 */
export async function fetchMemberNotifications(
  memberUid: string,
  cursor: QueryDocumentSnapshot<DocumentData> | null = null
): Promise<{ notifications: NotificationItem[]; lastDoc: QueryDocumentSnapshot<DocumentData> | null; hasMore: boolean }> {
  try {
    const constraints: QueryConstraint[] = [
      where('to', 'in', ['all', memberUid]),
      orderBy('createdAt', 'desc'),
      limit(20),
    ];
    if (cursor) {
      constraints.push(startAfter(cursor));
    }
    const q = query(collection(db, 'notifications'), ...constraints);
    const snap = await getDocs(q);

    return {
      notifications: snap.docs.map((d) => ({ id: d.id, ...d.data() } as NotificationItem)),
      lastDoc: snap.docs.length > 0 ? snap.docs[snap.docs.length - 1] : null,
      hasMore: snap.docs.length === 20,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'notifications');
  }
}

/**
 * 1 cheap read: retrieves newest 1 notification for member bell red-dot check.
 */
export async function fetchNewestNotificationForMember(
  memberUid: string
): Promise<NotificationItem | null> {
  try {
    const q = query(
      collection(db, 'notifications'),
      where('to', 'in', ['all', memberUid]),
      orderBy('createdAt', 'desc'),
      limit(1)
    );
    const snap = await getDocs(q);
    if (snap.empty) return null;
    return { id: snap.docs[0].id, ...snap.docs[0].data() } as NotificationItem;
  } catch {
    return null;
  }
}

/**
 * Backward compatibility alias
 */
export async function fetchLatestNotifications(memberUid?: string): Promise<NotificationItem[]> {
  if (memberUid) {
    const res = await fetchMemberNotifications(memberUid);
    return res.notifications;
  }
  try {
    const q = query(collection(db, 'notifications'), orderBy('createdAt', 'desc'), limit(20));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({ id: d.id, ...d.data() } as NotificationItem));
  } catch {
    return [];
  }
}

/**
 * Backward compatibility alias
 */
export async function fetchNewestNotification(memberUid?: string): Promise<NotificationItem | null> {
  if (memberUid) {
    return fetchNewestNotificationForMember(memberUid);
  }
  try {
    const q = query(collection(db, 'notifications'), orderBy('createdAt', 'desc'), limit(1));
    const snap = await getDocs(q);
    if (snap.empty) return null;
    return { id: snap.docs[0].id, ...snap.docs[0].data() } as NotificationItem;
  } catch {
    return null;
  }
}
