import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getCountFromServer,
  getDoc,
  getDocs,
  increment,
  limit,
  orderBy,
  query,
  QueryConstraint,
  QueryDocumentSnapshot,
  serverTimestamp,
  setDoc,
  startAfter,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
  DocumentData,
} from 'firebase/firestore';
import { auth, db, handleFirestoreError } from '../firebase';
import {
  ADMIN_EMAIL,
  isEmailAdmin,
  NameViewerRecord,
  NotificationItem,
  OperationType,
  ReportItem,
  UserProfile,
} from '../types';
import { formatISTTimestamp, getISTDateKey } from '../utils/istDate';
import { deleteBackendPost, getTwoDaysAgoTimestamp, isBackendOnlyRef } from './postService';
// ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
import { api, isApiConfigured } from './apiService';
// ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====

export function checkIsAdmin(userEmail?: string | null): boolean {
  const email = userEmail ?? auth.currentUser?.email;
  return isEmailAdmin(email);
}

export interface AdminOverviewStats {
  memberCount: number;
  totalPosts: number;
  postsToday: number;
  pendingReports: number;
  nameViewersTotal?: number;
  nameViewersToday?: number;
}

export interface MemberOverdueInfo {
  overdueCount: number;
  oldestAgeDays: number;
}

export interface CleanupSummary {
  postsDeleted: number;
  affectedMembersCount: number;
}


/**
 * Overview statistics without querying viewers collection.
 */
export async function fetchOverviewStats(): Promise<AdminOverviewStats> {
  try {
    const todayKey = getISTDateKey();
    const nvCol = collection(db, 'nameViewers');

    const [statsSnap, totalPostsSnap, todayCountsSnap, reportsSnap, nvTotalSnap, nvTodaySnap] = await Promise.all([
      getDoc(doc(db, 'meta', 'stats')).catch(() => null),
      getCountFromServer(collection(db, 'posts')).catch(() => null),
      getCountFromServer(query(collection(db, 'postCounts'), where('dateKey', '==', todayKey))).catch(() => null),
      getCountFromServer(collection(db, 'reports')).catch(() => null),
      getCountFromServer(nvCol).catch(() => null),
      getCountFromServer(query(nvCol, where('dateKey', '==', todayKey))).catch(() => null),
    ]);

    const memberCount =
      statsSnap && statsSnap.exists() && typeof statsSnap.data().userCount === 'number'
        ? statsSnap.data().userCount
        : 0;

    return {
      memberCount,
      totalPosts: totalPostsSnap ? totalPostsSnap.data().count : 0,
      postsToday: todayCountsSnap ? todayCountsSnap.data().count : 0,
      pendingReports: reportsSnap ? reportsSnap.data().count : 0,
      nameViewersTotal: nvTotalSnap ? nvTotalSnap.data().count : 0,
      nameViewersToday: nvTodaySnap ? nvTodaySnap.data().count : 0,
    };
  } catch (error) {
    try {
      handleFirestoreError(error, OperationType.GET, 'meta/stats');
    } catch {}
    return {
      memberCount: 0,
      totalPosts: 0,
      postsToday: 0,
      pendingReports: 0,
      nameViewersTotal: 0,
      nameViewersToday: 0,
    };
  }
}

/**
 * Fetch notifications 20 at a time for admin (newest first).
 */
export async function fetchNotificationsPage(
  cursor: QueryDocumentSnapshot<DocumentData> | null
): Promise<{ notifications: NotificationItem[]; lastDoc: QueryDocumentSnapshot<DocumentData> | null; hasMore: boolean }> {
  try {
    const constraints: QueryConstraint[] = [orderBy('createdAt', 'desc'), limit(20)];
    if (cursor) constraints.push(startAfter(cursor));
    const q = query(collection(db, 'notifications'), ...constraints);
    const snap = await getDocs(q);

    return {
      notifications: snap.docs.map((d) => ({ id: d.id, ...d.data() } as NotificationItem)),
      lastDoc: snap.docs[snap.docs.length - 1] || null,
      hasMore: snap.docs.length === 20,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'notifications');
  }
}

/**
 * Admin creates a targeted or broadcast notification.
 * to: 'all' (broadcast) or member uid.
 */
export async function createNotification(title: string, body: string, to: string = 'all'): Promise<void> {
  try {
    await addDoc(collection(db, 'notifications'), {
      title: title.trim(),
      body: body.trim(),
      to: to.trim() || 'all',
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, 'notifications');
  }
}

/**
 * Admin edits an existing notification.
 */
export async function updateNotification(
  id: string,
  title: string,
  body: string,
  to: string = 'all'
): Promise<void> {
  try {
    await updateDoc(doc(db, 'notifications', id), {
      title: title.trim(),
      body: body.trim(),
      to: to.trim() || 'all',
      editedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `notifications/${id}`);
  }
}

/**
 * Admin deletes a notification.
 */
export async function deleteNotification(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'notifications', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `notifications/${id}`);
  }
}

/**
 * Submit a report on a post by a member.
 */
export async function submitPostReport(params: {
  postId: string;
  postOwnerUid: string;
  postOwnerName: string;
  postImageUrl: string;
  postCaption: string;
  reporterUid: string;
  reporterName: string;
  reason: string;
  note?: string;
}): Promise<{ alreadyReported: boolean }> {
  const {
    postId,
    postOwnerUid,
    postOwnerName,
    postImageUrl,
    postCaption,
    reporterUid,
    reporterName,
    reason,
    note,
  } = params;

  const reportId = `${postId}_${reporterUid}`;
  const reportRef = doc(db, 'reports', reportId);

  try {
    const existingSnap = await getDoc(reportRef);
    if (existingSnap.exists()) {
      return { alreadyReported: true };
    }

    await setDoc(reportRef, {
      postId,
      postOwnerUid,
      postOwnerName,
      postImageUrl,
      postCaption: postCaption || '',
      reporterUid,
      reporterName,
      reason,
      note: note ? note.trim().slice(0, 200) : '',
      createdAt: serverTimestamp(),
    });

    return { alreadyReported: false };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `reports/${reportId}`);
  }
}

/**
 * Fetch reports 20 at a time for admin review.
 */
export async function fetchReportsPage(
  cursor: QueryDocumentSnapshot<DocumentData> | null
): Promise<{ reports: ReportItem[]; lastDoc: QueryDocumentSnapshot<DocumentData> | null; hasMore: boolean }> {
  try {
    const constraints: QueryConstraint[] = [orderBy('createdAt', 'desc'), limit(20)];
    if (cursor) constraints.push(startAfter(cursor));
    const q = query(collection(db, 'reports'), ...constraints);
    const snap = await getDocs(q);

    return {
      reports: snap.docs.map((d) => ({ id: d.id, ...d.data() } as ReportItem)),
      lastDoc: snap.docs[snap.docs.length - 1] || null,
      hasMore: snap.docs.length === 20,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'reports');
  }
}

/**
 * Permanently deletes a post, decrements owner postCount by 1,
 * and deletes all reports of that post and postPrivate doc.
 */
export async function deletePostAndReportsBatch(postId: string, ownerUid: string): Promise<void> {
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
  await deleteBackendPost(postId); // admin delete in backend feed too
  if (isBackendOnlyRef(postId)) return;
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====
  try {
    const reportsQuery = query(collection(db, 'reports'), where('postId', '==', postId), limit(20));
    const reportsSnap = await getDocs(reportsQuery);

    const batch = writeBatch(db);
    batch.delete(doc(db, 'posts', postId));

    if (ownerUid) {
      const ownerRef = doc(db, 'users', ownerUid);
      const ownerSnap = await getDoc(ownerRef);
      if (ownerSnap.exists()) {
        batch.update(ownerRef, {
          postCount: increment(-1),
          updatedAt: serverTimestamp(),
        });
      }
    }

    reportsSnap.docs.forEach((d) => {
      batch.delete(d.ref);
    });

    batch.delete(doc(db, 'postPrivate', postId));

    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `posts/${postId}`);
  }
}

/**
 * Admin action: dismiss reports for a post without deleting the post.
 */
export async function dismissReportsBatch(postId: string): Promise<void> {
  try {
    const reportsQuery = query(collection(db, 'reports'), where('postId', '==', postId), limit(20));
    const reportsSnap = await getDocs(reportsQuery);

    const batch = writeBatch(db);
    reportsSnap.docs.forEach((d) => {
      batch.delete(d.ref);
    });
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, 'reports');
  }
}

export async function deleteAnyPostAtomic(postId: string, ownerUid: string): Promise<void> {
  await deletePostAndReportsBatch(postId, ownerUid);
}

/**
 * Fetch all registered members for admin review.
 */
export async function fetchAllMembersForAdmin(): Promise<UserProfile[]> {
  try {
    const q = query(collection(db, 'users'), limit(50));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({ uid: d.id, ...d.data() } as UserProfile));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'users');
  }
}

/**
 * Lazy fetch of member overdue posts details:
 * Uses aggregate count() and a limit(1) oldest query to save reads.
 */
export async function fetchMemberOverdueDetails(uid: string): Promise<MemberOverdueInfo> {
  const twoDaysAgo = getTwoDaysAgoTimestamp();
  try {
    const overdueQuery = query(
      collection(db, 'posts'),
      where('uid', '==', uid),
      where('createdAt', '<', twoDaysAgo)
    );

    const countSnap = await getCountFromServer(overdueQuery);
    const overdueCount = countSnap.data().count;

    let oldestAgeDays = 0;
    if (overdueCount > 0) {
      // Find the oldest overdue post (orderBy createdAt asc, limit 1)
      const oldestQuery = query(
        collection(db, 'posts'),
        where('uid', '==', uid),
        where('createdAt', '<', twoDaysAgo),
        orderBy('createdAt', 'asc'),
        limit(1)
      );
      const oldestSnap = await getDocs(oldestQuery);
      if (!oldestSnap.empty) {
        const oldestPost = oldestSnap.docs[0].data();
        const createdMs = oldestPost.createdAt?.toMillis?.() ?? 0;
        if (createdMs > 0) {
          const diffMs = Date.now() - createdMs;
          oldestAgeDays = Math.max(2, Math.floor(diffMs / (24 * 60 * 60 * 1000)));
        }
      }
    }

    return { overdueCount, oldestAgeDays };
  } catch {
    return { overdueCount: 0, oldestAgeDays: 0 };
  }
}

/**
 * Reset member warnings and clear reminder timestamp:
 * Sets warnings = 0 and reminderSentAt = null.
 */
export async function resetMemberWarnings(uid: string): Promise<void> {
  try {
    await updateDoc(doc(db, 'users', uid), {
      warnings: 0,
      reminderSentAt: null,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
  }
}

/**
 * Admin "Purani posts saaf karo" button:
 * Deletes all posts older than 2 days across members in batches of up to 400.
 * Decrements affected members' postCounts and deletes related postPrivate and report documents.
 * IMPORTANT: Strictly NO automated warning or reminder notifications are generated or sent.
 */
export async function runAdminCleanup(): Promise<CleanupSummary> {
  const members = await fetchAllMembersForAdmin();
  const twoDaysAgo = getTwoDaysAgoTimestamp();

  let postsDeleted = 0;
  let affectedMembersCount = 0;

  for (const member of members) {
    // Check if member has overdue posts
    const overdueQuery = query(
      collection(db, 'posts'),
      where('uid', '==', member.uid),
      where('createdAt', '<', twoDaysAgo)
    );
    const overdueCountSnap = await getCountFromServer(overdueQuery);
    const overdueCount = overdueCountSnap.data().count;

    if (overdueCount === 0) {
      continue;
    }

    // Delete overdue posts in batches of up to 400
    let memberDeleted = 0;
    let hasMore = true;

    while (hasMore) {
      const postsSnap = await getDocs(
        query(
          collection(db, 'posts'),
          where('uid', '==', member.uid),
          where('createdAt', '<', twoDaysAgo),
          limit(400)
        )
      );

      if (postsSnap.empty) {
        break;
      }

      const batch = writeBatch(db);
      for (const postDoc of postsSnap.docs) {
        batch.delete(postDoc.ref);
        batch.delete(doc(db, 'postPrivate', postDoc.id));
      }

      await batch.commit();
      memberDeleted += postsSnap.docs.length;

      if (postsSnap.docs.length < 400) {
        hasMore = false;
      }
    }

    if (memberDeleted > 0) {
      affectedMembersCount += 1;
      postsDeleted += memberDeleted;

      // Decrement member's postCount
      await updateDoc(doc(db, 'users', member.uid), {
        postCount: Math.max(0, (member.postCount ?? 0) - memberDeleted),
        updatedAt: serverTimestamp(),
      });
    }
  }

  return {
    postsDeleted,
    affectedMembersCount,
  };
}


/**
 * Remove a member atomically:
 * In ONE batch:
 * 1. Delete users/{uid}
 * 2. Delete users/{uid}/private/imgbb
 * 3. Decrement meta/stats.userCount by 1 (frees slot)
 * Optional: delete all member posts in batches of 400.
 */
export async function removeMemberAtomic(uid: string, deletePosts: boolean): Promise<void> {
  const batch = writeBatch(db);

  batch.delete(doc(db, 'users', uid));
  batch.delete(doc(db, 'users', uid, 'private', 'imgbb'));
  batch.update(doc(db, 'meta', 'stats'), {
    userCount: increment(-1),
  });

  try {
    await batch.commit();

    // ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
    if (deletePosts) {
      try {
        if (isApiConfigured()) await api(`/api/admin/users/${encodeURIComponent(uid)}/posts`, { method: 'DELETE' });
      } catch (e) {
        console.warn('Backend post cleanup failed:', e);
      }
    }
    // ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====

    if (deletePosts) {
      let finished = false;
      while (!finished) {
        const postsQuery = query(collection(db, 'posts'), where('uid', '==', uid), limit(400));
        const postsSnap = await getDocs(postsQuery);
        if (postsSnap.empty) {
          finished = true;
          break;
        }
        const postBatch = writeBatch(db);
        postsSnap.docs.forEach((d) => {
          postBatch.delete(d.ref);
          postBatch.delete(doc(db, 'postPrivate', d.id));
        });
        await postBatch.commit();
        if (postsSnap.size < 400) {
          finished = true;
        }
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'users');
  }
}

/**
 * Retrieves ImgBB delete_url from postPrivate collection (admin-only).
 */
export async function getImgbbDeleteUrl(postId: string): Promise<string | null> {
  try {
    const snap = await getDoc(doc(db, 'postPrivate', postId));
    return snap.exists() ? (snap.data().deleteUrl as string) || null : null;
  } catch {
    return null;
  }
}

/**
 * Downloads members list as CSV file.
 */
export function downloadMembersCSV(members: UserProfile[]): void {
  const headers = ['UID', 'Full Name', 'Username', 'Bio', 'Post Count', 'Warnings', 'Reminder Sent At'];
  const rows = members.map((m) => [
    `"${m.uid}"`,
    `"${(m.fullName || '').replace(/"/g, '""')}"`,
    `"${(m.userName || '').replace(/"/g, '""')}"`,
    `"${(m.bio || '').replace(/"/g, '""').replace(/\n/g, ' ')}"`,
    m.postCount ?? 0,
    m.warnings ?? 0,
    m.reminderSentAt?.toDate?.() ? `"${m.reminderSentAt.toDate().toISOString()}"` : '""',
  ]);

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `business_media_members_${new Date().toISOString().slice(0, 10)}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Fetch name viewers analytics list for Name Management tab.
 */
export async function fetchNameViewersData(): Promise<{
  totalCount: number;
  todayCount: number;
  viewers: NameViewerRecord[];
}> {
  try {
    const todayKey = getISTDateKey();
    const nvCol = collection(db, 'nameViewers');

    const [totalSnap, todaySnap, docsSnap] = await Promise.all([
      getCountFromServer(nvCol).catch(() => null),
      getCountFromServer(query(nvCol, where('dateKey', '==', todayKey))).catch(() => null),
      getDocs(query(nvCol, orderBy('createdAt', 'desc'), limit(500))).catch(() => null),
    ]);

    const totalCount = totalSnap ? totalSnap.data().count : 0;
    const todayCount = todaySnap ? todaySnap.data().count : 0;

    const viewers: NameViewerRecord[] = [];
    if (docsSnap && !docsSnap.empty) {
      docsSnap.forEach((d) => {
        const data = d.data();
        viewers.push({
          id: d.id,
          name: data.name || 'Anonymous Viewer',
          createdAt: data.createdAt,
          dateKey: data.dateKey,
        });
      });
    }

    return {
      totalCount,
      todayCount,
      viewers,
    };
  } catch (error) {
    console.error('Error fetching name viewers:', error);
    return {
      totalCount: 0,
      todayCount: 0,
      viewers: [],
    };
  }
}

/**
 * Downloads all name viewers list as CSV file.
 */
export function downloadAllNamesCSV(viewers: NameViewerRecord[]): void {
  if (!viewers || viewers.length === 0) {
    alert('Download karne ke liye koi Name User data nahi hai.');
    return;
  }

  const headers = ['S.No', 'Viewer Name', 'Joined Date / Time (IST)'];
  const rows = viewers.map((v, index) => [
    index + 1,
    `"${(v.name || '').replace(/"/g, '""')}"`,
    `"${formatISTTimestamp(v.createdAt)}"`,
  ]);

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `Name_Users_List_${new Date().toISOString().slice(0, 10)}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
