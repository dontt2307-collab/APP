// ===== ADDED: POSTS FEATURE START =====
// Thin client for the Flask backend (backend/app.py).
// Firebase is used ONLY to get the login token; all post/image/admin data goes through the API.
import { auth } from '../firebase';

export const API_BASE: string = (
  (import.meta.env.VITE_API_BASE as string | undefined) || ''
).replace(/\/+$/, '');

export function isApiConfigured(): boolean {
  return Boolean(API_BASE) && !API_BASE.includes('YOUR-BACKEND-URL');
}

export interface ApiPost {
  id: number;
  uid: string;
  url: string;
  caption: string;
  created_at: string;
  user_name: string | null;
  user_photo: string | null;
}

export interface ApiUser {
  uid: string;
  name: string | null;
  email: string | null;
  photo: string | null;
  banned: number;
  created_at: string;
  last_login: string;
  post_count: number;
}

export class ApiError extends Error {
  readonly status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

interface ApiOptions {
  method?: string;
  body?: unknown;
  form?: FormData;
}

export async function api<T = any>(
  path: string,
  { method = 'GET', body, form }: ApiOptions = {}
): Promise<T> {
  if (!isApiConfigured()) {
    throw new ApiError('Backend URL set nahi hai (VITE_API_BASE).', 0);
  }

  const user = auth.currentUser;
  const headers: Record<string, string> = {};
  if (user) headers['Authorization'] = 'Bearer ' + (await user.getIdToken());

  let payload: BodyInit | undefined;
  if (form) {
    payload = form; // FormData: do NOT set Content-Type
  } else if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
    payload = JSON.stringify(body);
  }

  const doFetch = () => fetch(API_BASE + path, { method, headers, body: payload });

  let res: Response;
  try {
    res = await doFetch();
    if (res.status === 401 && user) {
      headers['Authorization'] = 'Bearer ' + (await user.getIdToken(true));
      res = await doFetch();
    }
  } catch {
    throw new ApiError('Server se connect nahi ho paaya. Internet check karke dobara try karo.', 0);
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ApiError((data as { error?: string }).error || `Request failed (${res.status})`, res.status);
  }
  return data as T;
}

/** SQLite CURRENT_TIMESTAMP is UTC "YYYY-MM-DD HH:MM:SS" -> readable IST string */
export function formatApiDate(s: string | null | undefined): string {
  if (!s) return '';
  const d = new Date(s.replace(' ', 'T') + 'Z');
  if (Number.isNaN(d.getTime())) return s;
  return d.toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata',
    day: 'numeric',
    month: 'short',
    hour: 'numeric',
    minute: '2-digit',
  });
}
// ===== ADDED: POSTS FEATURE END =====
