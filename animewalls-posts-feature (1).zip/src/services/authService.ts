import {
  deleteUser,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  increment,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import { MEMBER_LIMIT } from '../config';
import { auth, db, handleFirestoreError } from '../firebase';
import { OperationType, UserProfile, ADMIN_EMAIL, isEmailAdmin } from '../types';
import { clearActiveDeviceImgbbKeys } from './imgbbService';
import { fetchUserCached, isUserNameTaken, setCachedUser } from './userCache';
import { getBudgetDayKey } from './budgetService';

export async function updateMemberLastActiveAt(uid: string): Promise<void> {
  if (!uid || isEmailAdmin()) return;

  const todayKey = getBudgetDayKey(0);
  const localKey = `bm_last_active_${uid}_${todayKey}`;

  try {
    if (localStorage.getItem(localKey) === 'true') {
      return; // Already recorded today
    }
  } catch {}

  try {
    const userRef = doc(db, 'users', uid);
    await updateDoc(userRef, {
      lastActiveAt: serverTimestamp(),
    });
    try {
      localStorage.setItem(localKey, 'true');
    } catch {}
  } catch (err) {
    console.warn('Could not update member lastActiveAt:', err);
  }
}

export const MEMBER_LIMIT_MESSAGE =
  'Members ki limit poori ho chuki hai. Aap sirf naam daalke aa sakte ho';

export const USERNAME_PATTERN = /^[a-z0-9]{2,30}$/;

export function sanitizeUsernameInput(raw: string): string {
  return raw.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 30);
}

let pendingSignupPromise: Promise<void> | null = null;
let pendingGoogleOnboardingUid: string | null = null;

export async function waitForPendingSignup(): Promise<void> {
  if (pendingSignupPromise) {
    try {
      await pendingSignupPromise;
    } catch {
      // Handled by caller
    }
  }
}

export function isPendingGoogleOnboarding(uid: string): boolean {
  return pendingGoogleOnboardingUid === uid;
}

export function mapAuthErrorToHinglish(err: unknown): string {
  const code = (err as { code?: string })?.code || '';
  const msg = err instanceof Error ? err.message : String(err);

  if (msg === MEMBER_LIMIT_MESSAGE) {
    return MEMBER_LIMIT_MESSAGE;
  }
  switch (code) {
    case 'auth/popup-closed-by-user':
    case 'auth/cancelled-popup-request':
      return 'Google Sign-In popup band ho gaya. Dobara button dabakar sign in karo.';
    case 'auth/popup-blocked':
      return 'Browser ne Google popup block kar diya. Popup allow karke dobara try karo.';
    case 'auth/too-many-requests':
      return 'Bahut saari koshish ho gayi. Thodi der baad try karo.';
    case 'auth/operation-not-allowed':
      return 'Firebase Console > Authentication > Sign-in method me Google provider enable karo.';
    case 'auth/network-request-failed':
      return 'Internet connection check karo aur dobara try karo.';
    case 'auth/email-already-in-use':
      return 'Yeh email pehle se use me hai.';
    default:
      return msg || 'Kuch gadbad ho gayi. Dobara try karo.';
  }
}

export type GoogleAuthOutcome =
  | {
      status: 'EXISTING';
      profile: UserProfile;
    }
  | {
      status: 'NEEDS_PROFILE';
      uid: string;
      email: string;
      suggestedName: string;
      suggestedUsername: string;
      suggestedDpUrl: string;
    };

export async function authenticateWithGoogle(): Promise<GoogleAuthOutcome> {
  let resolveGuard!: () => void;
  pendingSignupPromise = new Promise<void>((res) => {
    resolveGuard = res;
  });

  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    const cred = await signInWithPopup(auth, provider);
    const uid = cred.user.uid;
    const email = cred.user.email || '';

    // 1. Check if this Google account is already a registered member
    const existingProfile = await fetchUserCached(uid, true);
    if (existingProfile) {
      pendingGoogleOnboardingUid = null;
      return {
        status: 'EXISTING',
        profile: existingProfile,
      };
    }

    // 2. If this is the Admin logging in:
    if (isEmailAdmin(email)) {
      pendingGoogleOnboardingUid = null;
      const adminProfile: UserProfile = {
        uid,
        fullName: (cred.user.displayName || 'Admin').trim().slice(0, 50),
        userName: 'admin',
        userNameLower: 'admin',
        bio: 'Business Media Admin',
        dpUrl: cred.user.photoURL || '',
        postCount: 0,
        createdAt: null,
        updatedAt: null,
      };

      try {
        await setDoc(doc(db, 'users', uid), {
          uid,
          fullName: adminProfile.fullName,
          userName: 'admin',
          userNameLower: 'admin',
          bio: 'Business Media Admin',
          dpUrl: adminProfile.dpUrl,
          postCount: 0,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        }, { merge: true });
      } catch (err) {
        console.warn('Auto-create admin doc notice:', err);
      }

      setCachedUser(adminProfile);
      return {
        status: 'EXISTING',
        profile: adminProfile,
      };
    }

    // 3. New member candidate -> enforce 20-member limit
    let currentCount = 0;
    try {
      const statsSnap = await getDoc(doc(db, 'meta', 'stats'));
      const rawCount = statsSnap.data()?.userCount;
      currentCount = typeof rawCount === 'number' ? rawCount : 0;
    } catch (error) {
      await deleteUser(cred.user).catch(() => signOut(auth));
      handleFirestoreError(error, OperationType.GET, 'meta/stats');
    }

    if (currentCount >= MEMBER_LIMIT) {
      pendingGoogleOnboardingUid = null;
      await deleteUser(cred.user).catch(() => signOut(auth));
      throw new Error(MEMBER_LIMIT_MESSAGE);
    }

    pendingGoogleOnboardingUid = uid;

    const suggestedName = (cred.user.displayName || '').trim().slice(0, 50);
    const emailPrefix = email.split('@')[0] || '';
    const suggestedUsername = sanitizeUsernameInput(suggestedName || emailPrefix);
    const suggestedDpUrl =
      cred.user.photoURL && cred.user.photoURL.startsWith('https://')
        ? cred.user.photoURL.slice(0, 1000)
        : '';

    return {
      status: 'NEEDS_PROFILE',
      uid,
      email,
      suggestedName,
      suggestedUsername,
      suggestedDpUrl,
    };
  } finally {
    pendingSignupPromise = null;
    resolveGuard();
  }
}

export async function completeGoogleMemberSetup(params: {
  uid: string;
  fullName: string;
  userName: string;
  dpUrl: string;
  bio?: string;
}): Promise<UserProfile> {
  const fbUser = auth.currentUser;
  if (!fbUser || fbUser.uid !== params.uid) {
    throw new Error('Google session expire ho gaya. Dobara Google se Sign In karo.');
  }

  const cleanFullName = params.fullName.trim();
  const cleanUserName = sanitizeUsernameInput(params.userName.trim());
  const cleanBio = (params.bio || '').trim().slice(0, 160);
  const cleanDpUrl = params.dpUrl.trim().slice(0, 1000);

  if (cleanFullName.length < 2 || cleanFullName.length > 50) {
    throw new Error('Apna naam 2 se 50 characters ke beech likho.');
  }
  if (!USERNAME_PATTERN.test(cleanUserName) || cleanUserName !== params.userName.trim()) {
    throw new Error(
      'Username me sirf small letters (a-z) aur numbers (0-9) allowed hain (2 se 30 chars).'
    );
  }

  const taken = await isUserNameTaken(cleanUserName, fbUser.uid);
  if (taken) {
    throw new Error('Yeh username pehle se liya ja chuka hai. Koi doosra username chuno.');
  }

  let latestExists = false;
  let latestCount = 0;
  try {
    const latestStatsSnap = await getDoc(doc(db, 'meta', 'stats'));
    latestExists = latestStatsSnap.exists();
    const rawCount = latestStatsSnap.data()?.userCount;
    latestCount = typeof rawCount === 'number' ? rawCount : 0;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'meta/stats');
  }

  if (latestCount >= MEMBER_LIMIT) {
    pendingGoogleOnboardingUid = null;
    await deleteUser(fbUser).catch(() => signOut(auth));
    throw new Error(MEMBER_LIMIT_MESSAGE);
  }

  try {
    const batch = writeBatch(db);
    const userRef = doc(db, 'users', fbUser.uid);
    const statsRef = doc(db, 'meta', 'stats');

    batch.set(userRef, {
      uid: fbUser.uid,
      fullName: cleanFullName,
      userName: cleanUserName,
      userNameLower: cleanUserName,
      bio: cleanBio,
      dpUrl: cleanDpUrl,
      postCount: 0,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    if (latestExists) {
      batch.update(statsRef, {
        userCount: increment(1),
      });
    } else {
      batch.set(statsRef, {
        userCount: 1,
      });
    }

    await batch.commit();
    pendingGoogleOnboardingUid = null;

    const createdProfile: UserProfile = {
      uid: fbUser.uid,
      fullName: cleanFullName,
      userName: cleanUserName,
      userNameLower: cleanUserName,
      bio: cleanBio,
      dpUrl: cleanDpUrl,
      postCount: 0,
    };
    setCachedUser(createdProfile);
    return createdProfile;
  } catch (batchErr) {
    const checkStats = await getDoc(doc(db, 'meta', 'stats')).catch(() => null);
    if (checkStats?.exists() && (checkStats.data().userCount ?? 0) >= MEMBER_LIMIT) {
      pendingGoogleOnboardingUid = null;
      await deleteUser(fbUser).catch(() => signOut(auth));
      throw new Error(MEMBER_LIMIT_MESSAGE);
    }
    handleFirestoreError(batchErr, OperationType.WRITE, `users/${fbUser.uid}`);
  }
}

export async function cancelPendingGoogleOnboarding(): Promise<void> {
  pendingGoogleOnboardingUid = null;
  const fbUser = auth.currentUser;
  if (!fbUser) return;
  const existing = await fetchUserCached(fbUser.uid, true).catch(() => null);
  if (!existing) {
    await deleteUser(fbUser).catch(() => signOut(auth));
  }
}

export async function updateMemberProfile(params: {
  current: UserProfile;
  fullName: string;
  userName: string;
  bio: string;
  dpUrl: string;
}): Promise<UserProfile> {
  const cleanFullName = params.fullName.trim();
  const cleanUserName = sanitizeUsernameInput(params.userName.trim());
  const cleanBio = params.bio.trim().slice(0, 160);
  const cleanDpUrl = params.dpUrl.trim().slice(0, 1000);

  if (cleanFullName.length < 2 || cleanFullName.length > 50) {
    throw new Error('Naam 2 se 50 characters ke beech hona chahiye.');
  }

  if (!USERNAME_PATTERN.test(cleanUserName) || cleanUserName !== params.userName.trim()) {
    throw new Error(
      'Username me sirf small letters (a-z) aur numbers (0-9) allowed hain (2 se 30 chars).'
    );
  }

  if (cleanUserName !== params.current.userNameLower) {
    const taken = await isUserNameTaken(cleanUserName, params.current.uid);
    if (taken) {
      throw new Error('Yeh username pehle se liya ja chuka hai. Doosra username chuno.');
    }
  }

  const path = `users/${params.current.uid}`;
  try {
    await updateDoc(doc(db, 'users', params.current.uid), {
      fullName: cleanFullName,
      userName: cleanUserName,
      userNameLower: cleanUserName,
      bio: cleanBio,
      dpUrl: cleanDpUrl,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }

  const updated: UserProfile = {
    ...params.current,
    fullName: cleanFullName,
    userName: cleanUserName,
    userNameLower: cleanUserName,
    bio: cleanBio,
    dpUrl: cleanDpUrl,
  };
  setCachedUser(updated);
  return updated;
}

export async function logoutMember(): Promise<void> {
  pendingGoogleOnboardingUid = null;
  clearActiveDeviceImgbbKeys();
  await signOut(auth);
}
