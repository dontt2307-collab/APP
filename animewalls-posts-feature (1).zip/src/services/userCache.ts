import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  query,
  where,
} from 'firebase/firestore';
import { db, handleFirestoreError } from '../firebase';
import { OperationType, UserProfile } from '../types';

// Session-wide in-memory cache so each member document is read at most once per session
const userSessionCache = new Map<string, UserProfile>();
let membersListLoaded = false;
let cachedMembersList: UserProfile[] = [];

export function getUserFromMemory(uid: string): UserProfile | undefined {
  return userSessionCache.get(uid);
}

export function setCachedUser(profile: UserProfile): void {
  userSessionCache.set(profile.uid, profile);
  const idx = cachedMembersList.findIndex((m) => m.uid === profile.uid);
  if (idx >= 0) {
    cachedMembersList = cachedMembersList.map((m, i) => (i === idx ? profile : m));
  } else if (membersListLoaded && cachedMembersList.length < 20) {
    cachedMembersList = [profile, ...cachedMembersList];
  }
}

export async function fetchUserCached(
  uid: string,
  forceRefresh = false
): Promise<UserProfile | null> {
  if (!forceRefresh && userSessionCache.has(uid)) {
    return userSessionCache.get(uid)!;
  }

  const path = `users/${uid}`;
  try {
    const snap = await getDoc(doc(db, 'users', uid));
    if (!snap.exists()) {
      userSessionCache.delete(uid);
      return null;
    }
    const data = snap.data();
    const userName = data.userName || 'member';
    const profile: UserProfile = {
      uid: data.uid || uid,
      fullName: data.fullName || userName,
      userName,
      userNameLower: data.userNameLower || userName.toLowerCase(),
      bio: data.bio || '',
      dpUrl: data.dpUrl || '',
      postCount: typeof data.postCount === 'number' ? data.postCount : 0,
      createdAt: data.createdAt || null,
      updatedAt: data.updatedAt || null,
    };
    setCachedUser(profile);
    return profile;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

/**
 * Loads up to 20 members ONCE per session for the Home top members strip
 * and populates userSessionCache for zero-read profile lookups.
 */
export async function fetchAllMembersOnce(): Promise<UserProfile[]> {
  if (membersListLoaded) {
    return cachedMembersList;
  }

  try {
    const q = query(collection(db, 'users'), limit(20));
    const snap = await getDocs(q);
    const list: UserProfile[] = [];
    snap.forEach((docSnap) => {
      const data = docSnap.data();
      const userName = data.userName || 'member';
      const profile: UserProfile = {
        uid: data.uid || docSnap.id,
        fullName: data.fullName || userName,
        userName,
        userNameLower: data.userNameLower || userName.toLowerCase(),
        bio: data.bio || '',
        dpUrl: data.dpUrl || '',
        postCount: typeof data.postCount === 'number' ? data.postCount : 0,
        createdAt: data.createdAt || null,
        updatedAt: data.updatedAt || null,
      };
      userSessionCache.set(profile.uid, profile);
      list.push(profile);
    });
    membersListLoaded = true;
    cachedMembersList = list;
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'users');
  }
}

/**
 * Checks case-insensitive userName uniqueness against users.userNameLower (1 read max).
 */
export async function isUserNameTaken(
  userName: string,
  excludeUid?: string
): Promise<boolean> {
  const lower = userName.trim().toLowerCase();
  try {
    const q = query(collection(db, 'users'), where('userNameLower', '==', lower), limit(1));
    const snap = await getDocs(q);
    if (snap.empty) return false;
    const foundDoc = snap.docs[0];
    if (excludeUid && foundDoc.id === excludeUid) {
      return false;
    }
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'users');
  }
}
