import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { getISTDateKey } from '../utils/istDate';
import { viewerSheetToken, viewerSheetUrl } from '../config';

const VIEWER_NAME_KEY = 'viewer_name';
const VIEWER_SENT_KEY = 'viewer_name_sent';
const VIEWER_ATTEMPTS_KEY = 'viewer_send_attempts';
const MAX_SEND_ATTEMPTS = 3;

let inFlightSend: Promise<void> | null = null;

function isAppsScriptConfigured(): boolean {
  return (
    Boolean(viewerSheetUrl) &&
    viewerSheetUrl.startsWith('https://script.google.com/macros/s/') &&
    !viewerSheetUrl.includes('YOUR_APPS_SCRIPT_ID')
  );
}

export function getSavedViewerName(): string | null {
  try {
    const raw = localStorage.getItem(VIEWER_NAME_KEY);
    if (!raw) return null;
    const trimmed = raw.trim().slice(0, 40);
    return trimmed || null;
  } catch {
    return null;
  }
}

export function isViewerNameSent(): boolean {
  try {
    return localStorage.getItem(VIEWER_SENT_KEY) === 'true';
  } catch {
    return false;
  }
}

export function validateViewerName(raw: string): { valid: boolean; cleaned: string; error?: string } {
  const cleaned = raw.trim();
  if (!cleaned) {
    return { valid: false, cleaned: '', error: 'Apna naam daalo.' };
  }
  if (cleaned.length < 1 || cleaned.length > 40) {
    return { valid: false, cleaned: cleaned.slice(0, 40), error: 'Naam 1 se 40 characters ka hona chahiye.' };
  }
  return { valid: true, cleaned };
}

/**
 * Sends viewer name to Google Apps Script Web App without any Firebase writes.
 * Retries on next app open up to 3 times if offline/network fails.
 */
export async function sendViewerNameOnceIfNeeded(): Promise<void> {
  if (inFlightSend) {
    return inFlightSend;
  }

  inFlightSend = (async () => {
    try {
      const name = getSavedViewerName();
      if (!name) return;
      if (isViewerNameSent()) return;

      const attempts = Number(localStorage.getItem(VIEWER_ATTEMPTS_KEY) || '0');
      if (attempts >= MAX_SEND_ATTEMPTS) {
        return;
      }

      if (typeof navigator !== 'undefined' && !navigator.onLine) {
        return;
      }

      if (!isAppsScriptConfigured()) {
        // Apps Script URL not configured yet, don't exhaust attempts
        return;
      }

      localStorage.setItem(VIEWER_ATTEMPTS_KEY, String(attempts + 1));

      // Send to Apps Script Web App (URL-encoded POST with shared token)
      const body = new URLSearchParams({
        name,
        token: viewerSheetToken,
      });

      await fetch(viewerSheetUrl, {
        method: 'POST',
        mode: 'no-cors', // Standard cross-origin POST for Apps Script web app
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: body.toString(),
      });

      localStorage.setItem(VIEWER_SENT_KEY, 'true');
    } catch (err) {
      console.warn('Google Sheet viewer sync will retry on next open:', err);
    } finally {
      inFlightSend = null;
    }
  })();

  return inFlightSend;
}

export async function joinAsViewer(rawName: string): Promise<{ ok: boolean; name?: string; error?: string }> {
  const check = validateViewerName(rawName);
  if (!check.valid) {
    return { ok: false, error: check.error };
  }

  try {
    const existingName = getSavedViewerName();
    if (existingName !== check.cleaned) {
      localStorage.setItem(VIEWER_NAME_KEY, check.cleaned);
      localStorage.setItem(VIEWER_SENT_KEY, 'false');
      localStorage.setItem(VIEWER_ATTEMPTS_KEY, '0');
    }
  } catch {
    return { ok: false, error: 'Browser localStorage save nahi kar paaya.' };
  }

  // Fire sync in background, never block the viewer entry
  void sendViewerNameOnceIfNeeded();

  // Also log to Firestore nameViewers collection
  try {
    const todayKey = getISTDateKey();
    void addDoc(collection(db, 'nameViewers'), {
      name: check.cleaned,
      dateKey: todayKey,
      createdAt: serverTimestamp(),
    }).catch((err) => console.warn('Firestore nameViewer log error:', err));
  } catch (err) {
    console.warn('Firestore nameViewer error:', err);
  }

  return { ok: true, name: check.cleaned };
}

export function exitViewerSession(): void {
  try {
    localStorage.removeItem(VIEWER_NAME_KEY);
    localStorage.removeItem(VIEWER_SENT_KEY);
    localStorage.removeItem(VIEWER_ATTEMPTS_KEY);
  } catch {
    // Ignore storage error
  }
}
