import { collection, getCountFromServer, query, where, Timestamp } from 'firebase/firestore';
import { db } from '../firebase';
import {
  ADMIN_TOKEN,
  baseAllowance,
  budgetDayStartHourIST,
  viewerPoolReads,
  viewerSheetToken,
  viewerSheetUrl,
} from '../config';

const DEVICE_ID_KEY = 'bm_device_id';
const BUDGET_STATE_KEY = 'bm_budget_state';
const LAST_HELLO_KEY = 'bm_last_hello_day';

export interface LocalBudgetState {
  dayKey: string;
  readsUsed: number;
  allowance: number;
  unreportedReads: number;
  reportCount: number;
  limitHit: boolean;
}

export interface AdminActivityStats {
  dayKey: string;
  viewersWithNames: number;
  guests: number;
  activeMembers: number;
  totalActive: number;
  limitHitCount: number;
  totalReadsServed: number;
  totalNamesSaved: number;
  viewerPoolReads: number;
}

/**
 * Returns or generates a persistent device UUID stored in localStorage.
 */
export function getDeviceId(): string {
  try {
    let id = localStorage.getItem(DEVICE_ID_KEY);
    if (!id) {
      id = 'dev_' + Math.random().toString(36).substring(2, 11) + '_' + Date.now().toString(36);
      localStorage.setItem(DEVICE_ID_KEY, id);
    }
    return id;
  } catch {
    return 'dev_fallback_' + Date.now().toString(36);
  }
}

/**
 * Returns budget day key (e.g., "20261026") in IST taking budgetDayStartHourIST into account.
 * dayOffset: 0 for today, 1 for yesterday.
 */
export function getBudgetDayKey(dayOffset = 0): string {
  const now = new Date();
  // Adjust to IST (+5:30)
  const istOffsetMs = (5 * 60 + 30) * 60 * 1000;
  const istTime = new Date(now.getTime() + istOffsetMs);

  // If current IST hour is less than budgetDayStartHourIST, consider it previous budget day
  if (istTime.getUTCHours() < budgetDayStartHourIST) {
    istTime.setUTCDate(istTime.getUTCDate() - 1);
  }

  if (dayOffset > 0) {
    istTime.setUTCDate(istTime.getUTCDate() - dayOffset);
  }

  const yyyy = istTime.getUTCFullYear();
  const mm = String(istTime.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(istTime.getUTCDate()).padStart(2, '0');
  return `${yyyy}${mm}${dd}`;
}

/**
 * Returns start Date for a given budget day key in IST.
 */
export function getBudgetDayStartDate(dayKey: string): Date {
  const yyyy = parseInt(dayKey.substring(0, 4), 10);
  const mm = parseInt(dayKey.substring(4, 6), 10) - 1;
  const dd = parseInt(dayKey.substring(6, 8), 10);

  // IST Date (UTC + 5:30)
  const date = new Date(Date.UTC(yyyy, mm, dd, budgetDayStartHourIST, 0, 0, 0));
  // Subtract 5:30 to get UTC Date
  date.setTime(date.getTime() - (5 * 60 + 30) * 60 * 1000);
  return date;
}

/**
 * Retrieves current local budget state, resetting automatically on a new budget day.
 */
export function getCurrentBudgetState(): LocalBudgetState {
  const currentDay = getBudgetDayKey(0);
  let state: LocalBudgetState | null = null;

  try {
    const raw = localStorage.getItem(BUDGET_STATE_KEY);
    if (raw) {
      state = JSON.parse(raw);
    }
  } catch {
    state = null;
  }

  // If no state or day changed, initialize fresh day state
  if (!state || state.dayKey !== currentDay) {
    state = {
      dayKey: currentDay,
      readsUsed: 0,
      allowance: baseAllowance,
      unreportedReads: 0,
      reportCount: 0,
      limitHit: false,
    };
    saveBudgetState(state);
  }

  return state;
}

function saveBudgetState(state: LocalBudgetState): void {
  try {
    localStorage.setItem(BUDGET_STATE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage errors
  }
}

/**
 * Checks if current device has hit daily read limit for guests and viewers.
 */
export function isLimitExceeded(): boolean {
  const state = getCurrentBudgetState();
  return state.readsUsed >= state.allowance;
}

/**
 * Returns whether user is allowed to load posts (always true for members/admin).
 */
export function canReadPosts(isMemberOrAdmin: boolean): boolean {
  if (isMemberOrAdmin) return true;
  return !isLimitExceeded();
}

/**
 * Records document reads for guests and viewers on the device.
 */
export function recordDocumentReads(count: number, isMemberOrAdmin = false): void {
  if (isMemberOrAdmin || count <= 0) return;

  const state = getCurrentBudgetState();
  state.readsUsed += count;
  state.unreportedReads += count;

  if (state.readsUsed >= state.allowance) {
    state.limitHit = true;
  }

  saveBudgetState(state);

  // Automatically report if unreported reads >= 15 or if limit was hit
  if (state.unreportedReads >= 15 || state.limitHit) {
    void reportMeter();
  }
}

/**
 * Calls Google Apps Script 'hello' endpoint on app open once per day.
 */
export async function helloMeter(viewerName?: string, isMemberOrAdmin = false): Promise<void> {
  if (isMemberOrAdmin) return;

  const currentDay = getBudgetDayKey(0);
  try {
    const lastHello = localStorage.getItem(LAST_HELLO_KEY);
    if (lastHello === currentDay) {
      // Already sent hello today
      return;
    }
  } catch {
    // Continue
  }

  if (
    !viewerSheetUrl ||
    !viewerSheetUrl.startsWith('https://script.google.com/macros/s/') ||
    viewerSheetUrl.includes('YOUR_APPS_SCRIPT_ID')
  ) {
    return;
  }

  try {
    const deviceId = getDeviceId();
    const body = new URLSearchParams({
      action: 'hello',
      token: viewerSheetToken,
      deviceId,
      name: viewerName || '',
    });

    const res = await fetch(viewerSheetUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
    });

    if (res.ok) {
      const json = await res.json();
      if (json && json.status === 'ok') {
        const state = getCurrentBudgetState();
        if (typeof json.allowance === 'number' && json.allowance > 0) {
          state.allowance = json.allowance;
        }
        if (typeof json.readsServedToday === 'number') {
          state.readsUsed = Math.max(state.readsUsed, json.readsServedToday);
        }
        state.limitHit = state.readsUsed >= state.allowance;
        saveBudgetState(state);

        try {
          localStorage.setItem(LAST_HELLO_KEY, currentDay);
        } catch {}
      }
    }
  } catch (err) {
    console.warn('Apps Script hello meter fallback to local base allowance:', err);
  }
}

/**
 * Reports accumulated reads to Google Apps Script meter.
 * Max ~4 reports per device per day.
 */
export async function reportMeter(force = false): Promise<void> {
  const state = getCurrentBudgetState();
  if (state.unreportedReads <= 0 && !force) return;
  if (state.reportCount >= 6 && !force) return; // Cap at ~6 calls per day

  if (
    !viewerSheetUrl ||
    !viewerSheetUrl.startsWith('https://script.google.com/macros/s/') ||
    viewerSheetUrl.includes('YOUR_APPS_SCRIPT_ID')
  ) {
    return;
  }

  const readsDelta = state.unreportedReads;
  state.unreportedReads = 0;
  state.reportCount += 1;
  saveBudgetState(state);

  try {
    const deviceId = getDeviceId();
    const body = new URLSearchParams({
      action: 'report',
      token: viewerSheetToken,
      deviceId,
      readsDelta: String(readsDelta),
      limitHit: String(state.limitHit),
    });

    const res = await fetch(viewerSheetUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
    });

    if (res.ok) {
      const json = await res.json();
      if (json && json.status === 'ok' && typeof json.allowance === 'number') {
        const updatedState = getCurrentBudgetState();
        updatedState.allowance = Math.max(updatedState.allowance, json.allowance);
        updatedState.limitHit = updatedState.readsUsed >= updatedState.allowance;
        saveBudgetState(updatedState);
      }
    }
  } catch (err) {
    console.warn('Apps Script report meter error:', err);
  }
}

/**
 * Fetches "Aaj ki Activity" stats for the Admin Dashboard.
 */
export async function fetchAdminActivityStats(dayOffset: 0 | 1 = 0): Promise<AdminActivityStats> {
  const dayKey = getBudgetDayKey(dayOffset);
  const dayStart = getBudgetDayStartDate(dayKey);

  let scriptStats = {
    viewersWithNames: 0,
    guests: 0,
    limitHitCount: 0,
    totalReadsServed: 0,
    totalNamesSaved: 0,
  };

  // 1. Fetch meter stats from Google Apps Script endpoint
  if (
    viewerSheetUrl &&
    viewerSheetUrl.startsWith('https://script.google.com/macros/s/') &&
    !viewerSheetUrl.includes('YOUR_APPS_SCRIPT_ID')
  ) {
    try {
      const url = `${viewerSheetUrl}?action=stats&adminToken=${encodeURIComponent(
        ADMIN_TOKEN
      )}&dayKey=${dayKey}`;
      const res = await fetch(url);
      if (res.ok) {
        const json = await res.json();
        if (json && json.status === 'ok') {
          scriptStats = {
            viewersWithNames: json.viewersWithNames || 0,
            guests: json.guests || 0,
            limitHitCount: json.limitHitCount || 0,
            totalReadsServed: json.totalReadsServed || 0,
            totalNamesSaved: json.totalNamesSaved || 0,
          };
        }
      }
    } catch (err) {
      console.warn('Failed to fetch stats from Google Apps Script:', err);
    }
  }

  // 2. Fetch active members count from Firestore (users where lastActiveAt >= dayStart)
  let activeMembers = 0;
  try {
    const dayStartTs = Timestamp.fromDate(dayStart);
    const usersCol = collection(db, 'users');
    const q = query(usersCol, where('lastActiveAt', '>=', dayStartTs));
    const snap = await getCountFromServer(q);
    activeMembers = snap.data().count;
  } catch (err) {
    console.warn('Firestore active members query failed:', err);
  }

  const totalActive = scriptStats.viewersWithNames + scriptStats.guests + activeMembers;

  return {
    dayKey,
    viewersWithNames: scriptStats.viewersWithNames,
    guests: scriptStats.guests,
    activeMembers,
    totalActive,
    limitHitCount: scriptStats.limitHitCount,
    totalReadsServed: scriptStats.totalReadsServed,
    totalNamesSaved: scriptStats.totalNamesSaved,
    viewerPoolReads,
  };
}
