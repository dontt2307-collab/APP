import React, { useEffect, useState } from 'react';
import { Heart } from 'lucide-react';
import {
  getEffectivePostLikes,
  subscribePostLikes,
  togglePostLike,
} from '../services/postService';
import { PostItem, UserProfile } from '../types';

interface LikeButtonProps {
  post: PostItem;
  currentMember: UserProfile | null;
  variant?: 'overlay' | 'compact' | 'detail';
}

export const LikeButton: React.FC<LikeButtonProps> = ({
  post,
  currentMember,
  variant = 'overlay',
}) => {
  const [, setTick] = useState(0);
  const [pending, setPending] = useState(false);
  const [animating, setAnimating] = useState(false);

  useEffect(() => {
    return subscribePostLikes(() => setTick((t) => t + 1));
  }, []);

  const likes = getEffectivePostLikes(post);
  const likeCount = likes.length;
  const canInteract = Boolean(currentMember);
  const isLiked = Boolean(currentMember && likes.includes(currentMember.uid));

  const swallowViewerEvent = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
  };

  const handleMemberToggle = async (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (!currentMember || pending) return;

    setAnimating(true);
    window.setTimeout(() => setAnimating(false), 300);

    setPending(true);
    try {
      await togglePostLike(post, currentMember.uid);
    } finally {
      setPending(false);
    }
  };

  if (variant === 'compact') {
    if (!canInteract) {
      return (
        <div
          role="status"
          aria-label={`${likeCount} likes`}
          onClick={swallowViewerEvent}
          className="pointer-events-auto inline-flex items-center gap-1 rounded-full bg-black/50 backdrop-blur-xs px-2.5 py-1 text-white select-none cursor-default"
        >
          <Heart className="w-3.5 h-3.5 text-white/90" strokeWidth={2.2} />
          <span className="text-[11px] font-bold tabular-nums leading-none">{likeCount}</span>
        </div>
      );
    }

    return (
      <button
        type="button"
        aria-pressed={isLiked}
        aria-label={isLiked ? 'Unlike post' : 'Like post'}
        disabled={pending}
        onClick={(e) => void handleMemberToggle(e)}
        className="pointer-events-auto inline-flex items-center gap-1 rounded-full bg-black/50 backdrop-blur-xs px-2.5 py-1 text-white select-none active:scale-90 transition-transform cursor-pointer"
      >
        <Heart
          className={`w-3.5 h-3.5 transition-all duration-200 ${
            isLiked ? 'fill-rose-500 text-rose-500' : 'text-white'
          } ${animating ? 'scale-140' : 'scale-100'}`}
          strokeWidth={2.2}
        />
        <span className="text-[11px] font-bold tabular-nums leading-none">{likeCount}</span>
      </button>
    );
  }

  if (variant === 'detail') {
    if (!canInteract) {
      return (
        <div
          role="status"
          aria-label={`${likeCount} likes`}
          onClick={swallowViewerEvent}
          className="min-h-[40px] px-3.5 rounded-full border bg-slate-50 border-slate-200/80 text-[#0F172A] flex items-center gap-1.5 select-none cursor-default"
        >
          <Heart className="w-4 h-4 text-slate-600" strokeWidth={2.2} />
          <span className="text-xs font-extrabold tabular-nums">{likeCount}</span>
        </div>
      );
    }

    return (
      <button
        type="button"
        aria-pressed={isLiked}
        aria-label={isLiked ? 'Unlike post' : 'Like post'}
        disabled={pending}
        onClick={(e) => void handleMemberToggle(e)}
        className={`min-h-[40px] px-3.5 rounded-full border flex items-center gap-1.5 select-none active:scale-95 transition-all cursor-pointer ${
          isLiked
            ? 'bg-rose-50 border-rose-200 text-rose-600'
            : 'bg-slate-50 border-slate-200/80 text-[#0F172A] hover:bg-slate-100'
        }`}
      >
        <Heart
          className={`w-4 h-4 transition-all duration-200 ${
            isLiked ? 'fill-rose-500 text-rose-500' : 'text-slate-700'
          } ${animating ? 'scale-140' : 'scale-100'}`}
          strokeWidth={2.2}
        />
        <span className="text-xs font-extrabold tabular-nums">{likeCount}</span>
      </button>
    );
  }

  // Default: 'overlay' inside PostCard
  if (!canInteract) {
    return (
      <div
        role="status"
        aria-label={`${likeCount} likes`}
        onClick={swallowViewerEvent}
        className="pointer-events-auto h-9 px-3 rounded-full bg-black/45 backdrop-blur-md border border-white/20 text-white flex items-center gap-1.5 shrink-0 select-none cursor-default"
      >
        <Heart className="w-4 h-4 text-white/90" strokeWidth={2.3} />
        <span className="text-xs font-extrabold tabular-nums leading-none">{likeCount}</span>
      </div>
    );
  }

  return (
    <button
      type="button"
      aria-pressed={isLiked}
      aria-label={isLiked ? 'Unlike post' : 'Like post'}
      disabled={pending}
      onClick={(e) => void handleMemberToggle(e)}
      className={`pointer-events-auto h-9 px-3 rounded-full backdrop-blur-md border text-white flex items-center gap-1.5 shrink-0 select-none active:scale-95 transition-all cursor-pointer ${
        isLiked
          ? 'bg-rose-500/25 border-rose-400/50'
          : 'bg-black/45 border-white/20 hover:bg-black/60'
      }`}
    >
      <Heart
        className={`w-4 h-4 transition-all duration-200 ${
          isLiked ? 'fill-rose-500 text-rose-500' : 'text-white'
        } ${animating ? 'scale-140' : 'scale-100'}`}
        strokeWidth={2.3}
      />
      <span className="text-xs font-extrabold tabular-nums leading-none">{likeCount}</span>
    </button>
  );
};
