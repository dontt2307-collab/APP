import React, { useState } from 'react';
import { Download, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  compact?: boolean;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ compact = false }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) return null;

  if (isInstallable) {
    if (compact) {
      return (
        <button
          type="button"
          onClick={() => void install()}
          title="Install Business Media"
          className="min-h-[40px] min-w-[40px] rounded-full bg-slate-100 hover:bg-slate-200 text-slate-800 flex items-center justify-center transition-colors shrink-0"
        >
          <Download className="w-4 h-4" />
        </button>
      );
    }
    return (
      <button
        type="button"
        onClick={() => void install()}
        className="w-full h-12 rounded-full bg-[#0F172A] text-white text-sm font-semibold flex items-center justify-center gap-2 hover:bg-slate-800 transition-colors whitespace-nowrap"
      >
        <Download className="w-4 h-4" />
        Business Media App Install Karo
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        {compact ? (
          <button
            type="button"
            onClick={() => setShowIOSGuide(true)}
            title="Install on iPhone"
            className="min-h-[40px] min-w-[40px] rounded-full bg-slate-100 hover:bg-slate-200 text-slate-800 flex items-center justify-center transition-colors shrink-0"
          >
            <Download className="w-4 h-4" />
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setShowIOSGuide(true)}
            className="w-full h-12 rounded-full bg-slate-100 text-slate-900 text-sm font-semibold flex items-center justify-center gap-2 hover:bg-slate-200 transition-colors whitespace-nowrap"
          >
            <Download className="w-4 h-4" />
            iPhone Home Screen Par Add Karo
          </button>
        )}

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-4">
            <div className="w-full max-w-[390px] rounded-[28px] bg-white p-6 shadow-2xl">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-bold text-[#0F172A]">iPhone / iPad par Install</h3>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed space-y-1">
                1. Safari ke neeche <strong>Share</strong> button dabao.
                <br />
                2. Neeche scroll karke <strong>Add to Home Screen</strong> chuno.
              </p>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full h-12 rounded-full bg-[#0F172A] text-white text-sm font-bold"
              >
                Samajh Gaya
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
