import React, { useCallback, useRef, useState } from 'react';
import { Loader2, RefreshCw } from 'lucide-react';

interface PullToRefreshProps {
  onRefresh: () => Promise<void>;
  children: React.ReactNode;
  disabled?: boolean;
}

const PULL_THRESHOLD = 65;

export const PullToRefresh: React.FC<PullToRefreshProps> = ({
  onRefresh,
  children,
  disabled = false,
}) => {
  const [pullDistance, setPullDistance] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startYRef = useRef(0);
  const isPullingRef = useRef(false);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (disabled || refreshing) return;
    if (window.scrollY <= 2) {
      startYRef.current = e.touches[0].clientY;
      isPullingRef.current = true;
    } else {
      isPullingRef.current = false;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isPullingRef.current || disabled || refreshing) return;
    if (window.scrollY > 2) {
      isPullingRef.current = false;
      setPullDistance(0);
      return;
    }

    const currentY = e.touches[0].clientY;
    const diffY = currentY - startYRef.current;

    if (diffY > 0) {
      // Rubber band damping formula
      const damped = Math.min(95, Math.pow(diffY, 0.82) * 1.8);
      setPullDistance(damped);
    } else {
      setPullDistance(0);
    }
  };

  const handleTouchEnd = useCallback(async () => {
    if (!isPullingRef.current && !pullDistance) return;
    isPullingRef.current = false;

    if (pullDistance >= PULL_THRESHOLD && !refreshing && !disabled) {
      setRefreshing(true);
      setPullDistance(52);
      try {
        await onRefresh();
      } finally {
        setRefreshing(false);
        setPullDistance(0);
      }
    } else {
      setPullDistance(0);
    }
  }, [disabled, onRefresh, pullDistance, refreshing]);

  const progressRatio = Math.min(1, pullDistance / PULL_THRESHOLD);
  const rotationDegrees = Math.min(360, progressRatio * 280);

  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={() => void handleTouchEnd()}
      className="relative min-h-full"
    >
      {/* Dynamic Pull Indicator Banner */}
      <div
        style={{
          height: `${refreshing ? 52 : pullDistance}px`,
          opacity: refreshing || pullDistance > 8 ? 1 : 0,
        }}
        className="overflow-hidden transition-all duration-200 ease-out flex items-center justify-center bg-slate-50 border-b border-slate-100"
      >
        <div className="flex items-center gap-2.5 px-4 py-2 text-xs font-bold text-[#0F172A]">
          {refreshing ? (
            <>
              <Loader2 className="w-4 h-4 text-[#0F172A] animate-spin shrink-0" />
              <span>Posts update ho rahi hain...</span>
            </>
          ) : (
            <>
              <RefreshCw
                style={{ transform: `rotate(${rotationDegrees}deg)` }}
                className="w-4 h-4 text-[#0F172A] transition-transform duration-75 shrink-0"
              />
              <span>
                {pullDistance >= PULL_THRESHOLD
                  ? 'Chhod do update ke liye'
                  : 'Neeche kheincho refresh karne ke liye'}
              </span>
            </>
          )}
        </div>
      </div>

      {children}
    </div>
  );
};
