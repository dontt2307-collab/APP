import React from 'react';
import { Briefcase, Maximize2, Trash2 } from 'lucide-react';
import { NAV_JOB_LABEL } from '../config';

import { getUserFromMemory } from '../services/userCache';
import { PostItem, UserProfile } from '../types';
import { formatISTTimestamp } from '../utils/istDate';
import { Avatar } from './Avatar';
import { LikeButton } from './LikeButton';
import { SafeImage } from './SafeImage';

interface PostCardProps {
  post: PostItem;
  currentMember: UserProfile | null;
  isAdmin: boolean;
  onSelectPost: (post: PostItem) => void;
  onOpenMemberProfile: (uid: string) => void;
  onOpenAuth?: () => void;
}

export const PostCard: React.FC<PostCardProps> = ({
  post,
  currentMember,
  isAdmin,
  onSelectPost,
  onOpenMemberProfile,
  onOpenAuth = () => {},
}) => {
  const cachedAuthor = getUserFromMemory(post.uid);
  const authorName =
    cachedAuthor?.fullName || post.userFullName || cachedAuthor?.userName || post.userName;
  const authorHandle = cachedAuthor?.userName || post.userName;
  const authorDp = cachedAuthor?.dpUrl || post.userDpUrl;

  const isJobPost = post.category === 'sarkari_naukri';

  return (
    <article className="rounded-[24px] overflow-hidden bg-white border border-slate-100 shadow-[0_8px_28px_rgba(15,23,42,0.06)] transition-all">


      {/* Author Header */}
      <div className="px-4 py-3 flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => onOpenMemberProfile(post.uid)}
          className="inline-flex items-center gap-2.5 text-left min-h-[44px] min-w-0 group/author"
        >
          <Avatar
            src={authorDp}
            name={authorName}
            sizeClass="w-9 h-9"
            textSizeClass="text-xs"
            ringClass="ring-1 ring-slate-200"
          />
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-sm font-extrabold text-[#0F172A] group-hover/author:underline truncate block leading-tight">
                {authorName}
              </span>
              {/* Sarkari Naukri Badge */}
              {isJobPost && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[10px] font-bold border border-emerald-200/70 shrink-0">
                  <Briefcase className="w-2.5 h-2.5" />
                  <span>{NAV_JOB_LABEL}</span>
                </span>
              )}
            </div>
            <span className="text-[11.5px] text-slate-500 font-medium truncate block leading-tight mt-0.5">
              @{authorHandle} &middot; {formatISTTimestamp(post.createdAt)}
            </span>
          </div>
        </button>

        <div className="flex items-center gap-1 shrink-0">
          {(isAdmin || (currentMember && post.uid === currentMember.uid)) && (
            <button
              type="button"
              onClick={() => onSelectPost(post)}
              aria-label="Delete post"
              className="min-h-[40px] min-w-[40px] rounded-full text-rose-500 hover:bg-rose-50 flex items-center justify-center shrink-0 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
          <button
            type="button"
            onClick={() => onSelectPost(post)}
            aria-label="Full photo dekho"
            className="min-h-[40px] min-w-[40px] rounded-full text-slate-400 hover:text-[#0F172A] hover:bg-slate-100 flex items-center justify-center shrink-0 transition-colors"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Full Uncropped Crisp Uploaded Photo */}
      <div
        role="button"
        tabIndex={0}
        onClick={() => onSelectPost(post)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') onSelectPost(post);
        }}
        className="cursor-pointer bg-[#F8FAFC] border-y border-slate-100"
      >
        <SafeImage
          src={post.imageUrl}
          alt={post.caption || `${authorName} ki post`}
          fit="contain"
          autoHeight
          className="w-full min-h-[160px] bg-[#F8FAFC]"
          imgClassName="max-h-[320px] mx-auto"
        />
      </div>

      {/* Bottom Action & Caption Row */}
      <div className="px-4 py-3.5 flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          {post.caption ? (
            <p
              onClick={() => onSelectPost(post)}
              className="text-[14px] text-slate-800 leading-relaxed line-clamp-3 cursor-pointer break-words"
            >
              {post.caption}
            </p>
          ) : (
            <p
              onClick={() => onSelectPost(post)}
              className="text-xs text-slate-400 py-2 cursor-pointer"
            >
              Puri photo dekhne ke liye tap karo
            </p>
          )}
        </div>

        <div className="shrink-0">
          <LikeButton post={post} currentMember={currentMember} variant="detail" />
        </div>
      </div>
    </article>
  );
};
