import React, { useCallback, useEffect, useRef, useState } from 'react';
import type { DocumentData, QueryDocumentSnapshot } from 'firebase/firestore';
import { Briefcase, RefreshCw, WifiOff } from 'lucide-react';
import { NAV_JOB_LABEL } from '../config';
import { isQuotaExceededError } from '../firebase';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { fetchCategoryPostsPage } from '../services/postService';
import { AuthModalMode, PostItem, UserProfile } from '../types';
import { Avatar } from './Avatar';
import { LimitExceededCard } from './LimitExceededCard';
import { PostCard } from './PostCard';
import { PullToRefresh } from './PullToRefresh';
import { PWAInstallButton } from './PWAInstallButton';
import { FeedSkeleton } from './Skeletons';

interface SarkariNaukriViewProps {
  currentMember: UserProfile | null;
  viewerName?: string | null;
  refreshSignal: number;
  isAdmin: boolean;
  onOpenAuth: (mode: AuthModalMode) => void;
  onOpenMemberProfile: (uid: string) => void;
  onSelectPost: (post: PostItem) => void;
  onGoToUploadSarkari: () => void;
  onGoToProfile: () => void;
}

export const SarkariNaukriView: React.FC<SarkariNaukriViewProps> = ({
  currentMember,
  viewerName,
  refreshSignal,
  isAdmin,
  onOpenAuth,
  onOpenMemberProfile,
  onSelectPost,
  onGoToUploadSarkari,
  onGoToProfile,
}) => {
  const isOnline = useOnlineStatus();
  const [posts, setPosts] = useState<PostItem[]>([]);
  const [lastDoc, setLastDoc] = useState<QueryDocumentSnapshot<DocumentData> | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [limitExceeded, setLimitExceeded] = useState(false);
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  const loadInitial = useCallback(async () => {
    setError(null);
    setInitialLoading(true);
    try {
      const isMemberOrAdmin = Boolean(currentMember || isAdmin);
      const page = await fetchCategoryPostsPage('sarkari_naukri', null, isMemberOrAdmin);

      if (page.limitExceeded) {
        setLimitExceeded(true);
        setPosts([]);
      } else {
        setLimitExceeded(false);
        setPosts(page.posts);
      }

      setLastDoc(page.lastDoc);
      setHasMore(page.hasMore);
    } catch (err) {
      if (isQuotaExceededError(err)) {
        setError('Aaj ka Firebase free Spark read quota poora ho gaya hai. Kal subah reset hoga.');
      } else if (!navigator.onLine) {
        setError('Internet band hai. Online aate hi Sarkari Naukri posts dikhengi.');
      } else {
        setError('Sarkari Naukri posts load nahi ho paayi. Dobara try karo.');
      }
    } finally {
      setInitialLoading(false);
    }
  }, [currentMember, isAdmin]);

  useEffect(() => {
    void loadInitial();
  }, [loadInitial, refreshSignal]);

  const loadMore = useCallback(async () => {
    if (loadingMore || !hasMore || !lastDoc || limitExceeded) return;
    setLoadingMore(true);
    try {
      const isMemberOrAdmin = Boolean(currentMember || isAdmin);
      const next = await fetchCategoryPostsPage('sarkari_naukri', lastDoc, isMemberOrAdmin);

      if (next.limitExceeded) {
        setLimitExceeded(true);
        setHasMore(false);
        return;
      }

      setPosts((prev) => {
        const existingIds = new Set(prev.map((p) => p.id));
        const uniqueNew = next.posts.filter((p) => !existingIds.has(p.id));
        return [...prev, ...uniqueNew];
      });
      setLastDoc(next.lastDoc);
      setHasMore(next.hasMore);
    } catch {
      // Allow retry on next scroll
    } finally {
      setLoadingMore(false);
    }
  }, [currentMember, hasMore, isAdmin, lastDoc, limitExceeded, loadingMore]);

  useEffect(() => {
    const node = sentinelRef.current;
    if (!node || !hasMore || initialLoading || limitExceeded) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          void loadMore();
        }
      },
      { rootMargin: '250px' }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [hasMore, initialLoading, limitExceeded, loadMore]);

  const isNameOnlyViewer = Boolean(viewerName && !currentMember);

  const handleRefresh = useCallback(async () => {
    setError(null);
    try {
      const isMemberOrAdmin = Boolean(currentMember || isAdmin);
      const page = await fetchCategoryPostsPage('sarkari_naukri', null, isMemberOrAdmin);

      if (page.limitExceeded) {
        setLimitExceeded(true);
        setPosts([]);
      } else {
        setLimitExceeded(false);
        setPosts(page.posts);
      }

      setLastDoc(page.lastDoc);
      setHasMore(page.hasMore);
    } catch (err) {
      if (isQuotaExceededError(err)) {
        setError('Aaj ka Firebase free Spark read quota poora ho gaya hai. Kal subah reset hoga.');
      } else if (!navigator.onLine) {
        setError('Internet band hai. Online aate hi Sarkari Naukri posts dikhengi.');
      }
    }
  }, [currentMember, isAdmin]);

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div className="pb-24 min-h-dvh bg-white">
        {/* Sticky Top Header */}
        <header className="sticky top-0 z-20 bg-white/95 backdrop-blur-md px-5 h-16 flex items-center justify-between gap-3 border-b border-slate-100/80">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-[#0F172A] shrink-0">
              <Briefcase className="w-4 h-4" strokeWidth={2.3} />
            </div>
            <h1 className="text-[20px] font-extrabold text-[#0F172A] tracking-tight truncate">
              {NAV_JOB_LABEL}
            </h1>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton compact />

            {currentMember ? (
              <button
                type="button"
                onClick={() => onOpenMemberProfile(currentMember.uid)}
                className="min-h-[40px] flex items-center gap-2 rounded-full pl-1 pr-3 py-1 bg-slate-100 hover:bg-slate-200/80 transition-colors"
              >
                <Avatar
                  src={currentMember.dpUrl}
                  name={currentMember.fullName || currentMember.userName}
                  sizeClass="w-7 h-7"
                  textSizeClass="text-xs"
                />
                <span className="text-xs font-bold text-[#0F172A] max-w-[84px] truncate">
                  {currentMember.fullName || currentMember.userName}
                </span>
              </button>
            ) : viewerName ? (
              <button
                type="button"
                onClick={onGoToProfile}
                className="min-h-[36px] px-3.5 rounded-full bg-slate-100 hover:bg-slate-200/80 text-xs font-bold text-slate-700 max-w-[132px] truncate transition-colors"
              >
                Hi, {viewerName}
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onOpenAuth('login')}
                className="min-h-[38px] px-4 rounded-full bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-bold transition-colors whitespace-nowrap"
              >
                Login / Naam
              </button>
            )}
          </div>
        </header>

        {!isOnline && (
          <div className="mx-5 mt-3 rounded-2xl bg-amber-50 border border-amber-200/70 px-4 py-2.5 flex items-center gap-2.5 text-xs font-semibold text-amber-900">
            <WifiOff className="w-4 h-4 shrink-0" />
            <span>Aap abhi offline ho. Kuch naye updates ruk sakte hain.</span>
          </div>
        )}

        {/* Sarkari Naukri Posts Feed Section */}
        <section className="pt-4">
          <div className="px-5 flex items-center justify-between mb-3.5">
            <div>
              <h2 className="text-[17px] font-extrabold text-[#0F172A]">{NAV_JOB_LABEL} Posts</h2>
              <p className="text-xs text-slate-400">Pichle 2 din ki bharti, form aur exam updates</p>
            </div>
            <button
              type="button"
              onClick={() => void loadInitial()}
              aria-label="Refresh Sarkari Naukri feed"
              className="min-h-[36px] min-w-[36px] rounded-full text-slate-400 hover:text-[#0F172A] hover:bg-slate-100 flex items-center justify-center transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>

          {initialLoading ? (
            <FeedSkeleton />
          ) : limitExceeded && posts.length === 0 ? (
            <LimitExceededCard isInline={false} />
          ) : error ? (
            <div className="mx-5 my-4 rounded-[24px] bg-slate-50 p-6 text-center space-y-4">
              <p className="text-sm font-medium text-slate-600">{error}</p>
              <button
                type="button"
                onClick={() => void loadInitial()}
                className="px-6 h-11 rounded-full bg-[#0F172A] text-white text-xs font-bold"
              >
                Dobara Try Karo
              </button>
            </div>
          ) : posts.length === 0 ? (
            <div className="mx-5 my-6 rounded-[26px] bg-[#F8FAFC] border border-slate-100 p-8 text-center space-y-4">
              <div className="w-14 h-14 rounded-full bg-white shadow-xs flex items-center justify-center mx-auto text-[#0F172A]">
                <Briefcase className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-[#0F172A]">
                  Abhi koi {NAV_JOB_LABEL} post nahi hai
                </h3>
                <p className="mt-1 text-xs text-slate-500 leading-relaxed">
                  {isNameOnlyViewer
                    ? 'Jaise hi naye updates upload honge, yahan dikhenge.'
                    : 'Upload karte waqt "Sarkari Naukri" select karke pehli post daalo!'}
                </p>
              </div>
              {!isNameOnlyViewer && (
                <button
                  type="button"
                  onClick={onGoToUploadSarkari}
                  className="px-6 h-12 rounded-full bg-[#0F172A] text-white text-xs font-bold"
                >
                  {NAV_JOB_LABEL} Post Daalo
                </button>
              )}
            </div>
          ) : (
            <div className="px-5 space-y-5">
              {posts.map((post) => (
                <div key={post.id}>
                  <PostCard
                    post={post}
                    currentMember={currentMember}
                    isAdmin={isAdmin}
                    onSelectPost={onSelectPost}
                    onOpenMemberProfile={onOpenMemberProfile}
                    onOpenAuth={() => onOpenAuth('login')}
                  />
                </div>
              ))}

              {limitExceeded ? (
                <LimitExceededCard isInline={true} />
              ) : (
                <div ref={sentinelRef} className="h-6 flex items-center justify-center">
                  {loadingMore && (
                    <span className="text-xs font-semibold text-slate-400">
                      Aur posts load ho rahi hain...
                    </span>
                  )}
                </div>
              )}
            </div>
          )}
        </section>
      </div>
    </PullToRefresh>
  );
};
