import React, { useCallback, useRef, useState } from 'react';
import { SafeImage } from './SafeImage';

interface ZoomableImageProps {
  src: string;
  alt: string;
  className?: string;
  imgClassName?: string;
  onExpand?: () => void;
}

export const ZoomableImage: React.FC<ZoomableImageProps> = ({
  src,
  alt,
  className = '',
  imgClassName = '',
  onExpand,
}) => {
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);

  const touchStartDistRef = useRef<number | null>(null);
  const startScaleRef = useRef(1);
  const lastTouchRef = useRef<{ x: number; y: number } | null>(null);
  const startPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const lastTapTimeRef = useRef<number>(0);
  const tapTimeoutRef = useRef<number | null>(null);

  const resetZoom = useCallback(() => {
    setScale(1);
    setPosition({ x: 0, y: 0 });
  }, []);

  const handleDoubleTapOrClick = () => {
    const now = Date.now();
    const timeDiff = now - lastTapTimeRef.current;

    if (timeDiff < 300) {
      // Cancel pending single tap expand timeout
      if (tapTimeoutRef.current) {
        window.clearTimeout(tapTimeoutRef.current);
        tapTimeoutRef.current = null;
      }
      // Toggle image zoom on double tap
      if (scale > 1.2) {
        resetZoom();
      } else {
        setScale(2.5);
      }
    } else {
      // Schedule single tap check
      if (onExpand && scale === 1) {
        tapTimeoutRef.current = window.setTimeout(() => {
          onExpand();
          tapTimeoutRef.current = null;
        }, 300);
      }
    }
    lastTapTimeRef.current = now;
  };

  // Touch Handlers for Pinch-to-zoom & Pan (Strictly image element only)
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 2) {
      // Cancel single tap timeout if pinching
      if (tapTimeoutRef.current) {
        window.clearTimeout(tapTimeoutRef.current);
        tapTimeoutRef.current = null;
      }
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      const dist = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
      touchStartDistRef.current = dist;
      startScaleRef.current = scale;
    } else if (e.touches.length === 1) {
      handleDoubleTapOrClick();
      lastTouchRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      startPosRef.current = { ...position };
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 2 && touchStartDistRef.current !== null) {
      // Prevent browser default full-page zoom
      if (e.cancelable) e.preventDefault();
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      const dist = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
      const factor = dist / touchStartDistRef.current;
      const newScale = Math.min(4, Math.max(1, startScaleRef.current * factor));
      setScale(newScale);
      if (newScale === 1) setPosition({ x: 0, y: 0 });
    } else if (e.touches.length === 1 && scale > 1 && lastTouchRef.current) {
      if (e.cancelable) e.preventDefault();
      const dx = e.touches[0].clientX - lastTouchRef.current.x;
      const dy = e.touches[0].clientY - lastTouchRef.current.y;
      const maxOffset = (scale - 1) * 160;
      setPosition({
        x: Math.min(maxOffset, Math.max(-maxOffset, startPosRef.current.x + dx)),
        y: Math.min(maxOffset, Math.max(-maxOffset, startPosRef.current.y + dy)),
      });
    }
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length < 2) {
      touchStartDistRef.current = null;
    }
    if (e.touches.length === 0) {
      lastTouchRef.current = null;
      if (scale < 1.05) {
        resetZoom();
      }
    }
  };

  // Mouse Wheel & Drag for Desktop image zoom only
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY < 0 ? 0.25 : -0.25;
    setScale((prev) => {
      const next = Math.min(4, Math.max(1, prev + delta));
      if (next === 1) setPosition({ x: 0, y: 0 });
      return next;
    });
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (scale <= 1) return;
    setIsDragging(true);
    lastTouchRef.current = { x: e.clientX, y: e.clientY };
    startPosRef.current = { ...position };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || scale <= 1 || !lastTouchRef.current) return;
    const dx = e.clientX - lastTouchRef.current.x;
    const dy = e.clientY - lastTouchRef.current.y;
    const maxOffset = (scale - 1) * 180;
    setPosition({
      x: Math.min(maxOffset, Math.max(-maxOffset, startPosRef.current.x + dx)),
      y: Math.min(maxOffset, Math.max(-maxOffset, startPosRef.current.y + dy)),
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    lastTouchRef.current = null;
  };

  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className={`relative overflow-hidden select-none touch-none ${className}`}
    >
      {/* Zoom transform target: Strictly scales ONLY the image element */}
      <div
        style={{
          transform: `translate3d(${position.x}px, ${position.y}px, 0px) scale(${scale})`,
          transition: isDragging || touchStartDistRef.current !== null ? 'none' : 'transform 0.18s ease-out',
        }}
        className="w-full h-full flex items-center justify-center cursor-grab active:cursor-grabbing"
      >
        <SafeImage
          src={src}
          alt={alt}
          fit="contain"
          autoHeight
          className="w-full bg-transparent pointer-events-none"
          imgClassName={imgClassName}
        />
      </div>
    </div>
  );
};
