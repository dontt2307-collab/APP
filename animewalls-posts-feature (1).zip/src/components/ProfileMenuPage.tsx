import { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Edit3,
  Images, // ADDED: POSTS FEATURE
  LayoutDashboard,
  LogIn,
  LogOut,
  Settings,
  UserCheck,
} from 'lucide-react';
import { AuthModalMode, UserProfile } from '../types';
import { Avatar } from './Avatar';
// ===== ADDED: POSTS FEATURE START =====
import { CommunityPosts } from './CommunityPosts';
// ===== ADDED: POSTS FEATURE END =====
import { PWAInstallButton } from './PWAInstallButton';

interface ProfileMenuPageProps {
  currentMember: UserProfile | null;
  viewerName: string | null;
  isAdmin?: boolean;
  onClose: () => void;
  onOpenAuth: (mode: AuthModalMode) => void;
  onEditProfile: () => void;
  onOpenSettings: () => void;
  onOpenAdmin: (tab: any) => void;
  onExit: () => void;
}

export const ProfileMenuPage: React.FC<ProfileMenuPageProps> = ({
  currentMember,
  viewerName,
  isAdmin = false,
  onClose,
  onOpenAuth,
  onEditProfile,
  onOpenSettings,
  onOpenAdmin,
  onExit,
}) => {
  // ===== ADDED: POSTS FEATURE START =====
  const [communityOpen, setCommunityOpen] = useState(false);
  // ===== ADDED: POSTS FEATURE END =====
  const displayName =
    currentMember?.fullName || currentMember?.userName || viewerName || 'Guest User';
  const roleLabel = currentMember
    ? `@${currentMember.userName} · Registered Member`
    : viewerName
      ? 'Name Account (View Only)'
      : 'Guest Mode';

  return (
    <div className="fixed inset-0 z-50 bg-[#F4F6F9] flex justify-center overflow-y-auto">
      <div className="w-full max-w-[430px] min-h-dvh bg-white flex flex-col justify-between shadow-2xl">
        {/* Top Section: Header + Account Summary + Options */}
        <div>
          <header className="sticky top-0 z-10 bg-white/95 backdrop-blur-md px-5 h-15 flex items-center gap-3 border-b border-slate-100">
            <button
              type="button"
              onClick={onClose}
              aria-label="Back to profile"
              className="min-h-[40px] min-w-[40px] -ml-2 rounded-full flex items-center justify-center text-[#0F172A] hover:bg-slate-100 transition-colors"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <h1 className="text-lg font-extrabold text-[#0F172A]">Settings</h1>
          </header>

          <div className="px-6 pt-6 space-y-6">
            {/* Clean Profile Summary Card */}
            <div className="rounded-[24px] bg-[#F8FAFC] border border-slate-100 p-4 flex items-center gap-3.5">
              <Avatar
                src={currentMember?.dpUrl || ''}
                name={displayName}
                sizeClass="w-13 h-13"
                textSizeClass="text-lg"
                ringClass="ring-2 ring-white shadow-xs"
              />
              <div className="min-w-0 flex-1">
                <p className="text-base font-extrabold text-[#0F172A] truncate">
                  {displayName}
                </p>
                <p className="text-xs font-medium text-slate-500 mt-0.5 truncate">{roleLabel}</p>
              </div>
            </div>

            {/* Menu Options List */}
            <div className="space-y-2.5">
              <p className="px-1 text-xs font-bold text-slate-400 uppercase tracking-wider">
                Account Options
              </p>

              {isAdmin && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenAdmin('overview');
                  }}
                  className="w-full min-h-[56px] rounded-[20px] bg-[#0F172A] hover:bg-slate-800 px-4 flex items-center justify-between text-left transition-colors shadow-xs group"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white">
                      <LayoutDashboard className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-sm font-extrabold text-white flex items-center gap-2">
                        Admin Dashboard
                        <span className="text-[10px] bg-white/20 text-white font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                          Admin
                        </span>
                      </p>
                      <p className="text-xs text-slate-300">
                        Overview, reports, members & notifications
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-white transition-colors" />
                </button>
              )}

              {/* ===== ADDED: POSTS FEATURE START ===== */}
              <button
                type="button"
                onClick={() => setCommunityOpen(true)}
                className="w-full min-h-[56px] rounded-[20px] bg-[#F8FAFC] hover:bg-slate-100 px-4 flex items-center justify-between text-left transition-colors"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-full bg-white shadow-2xs flex items-center justify-center text-[#0F172A]">
                    <Images className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-[#0F172A]">Community Posts</p>
                    <p className="text-xs text-slate-500">Sabke posts dekho aur apni photo upload karo</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
              {/* ===== ADDED: POSTS FEATURE END ===== */}

              {currentMember ? (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onEditProfile();
                    }}
                    className="w-full min-h-[56px] rounded-[20px] bg-[#F8FAFC] hover:bg-slate-100 px-4 flex items-center justify-between text-left transition-colors"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="w-10 h-10 rounded-full bg-white shadow-2xs flex items-center justify-center text-[#0F172A]">
                        <Edit3 className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-[#0F172A]">Edit Profile</p>
                        <p className="text-xs text-slate-500">
                          DP image, naam, username aur bio badlo
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenSettings();
                    }}
                    className="w-full min-h-[56px] rounded-[20px] bg-[#F8FAFC] hover:bg-slate-100 px-4 flex items-center justify-between text-left transition-colors"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="w-10 h-10 rounded-full bg-white shadow-2xs flex items-center justify-center text-[#0F172A]">
                        <Settings className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-[#0F172A]">Settings</p>
                        <p className="text-xs text-slate-500">ImgBB API keys aur app settings</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>
                </>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenAuth('login');
                    }}
                    className="w-full min-h-[56px] rounded-[20px] bg-[#F8FAFC] hover:bg-slate-100 px-4 flex items-center justify-between text-left transition-colors"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="w-10 h-10 rounded-full bg-white shadow-2xs flex items-center justify-center text-[#0F172A]">
                        <LogIn className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-[#0F172A]">Google se Sign In Karo</p>
                        <p className="text-xs text-slate-500">
                          Member banke post upload aur like karne ke liye
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>

                  {!viewerName && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenAuth('viewer');
                      }}
                      className="w-full min-h-[56px] rounded-[20px] bg-[#F8FAFC] hover:bg-slate-100 px-4 flex items-center justify-between text-left transition-colors"
                    >
                      <div className="flex items-center gap-3.5">
                        <div className="w-10 h-10 rounded-full bg-white shadow-2xs flex items-center justify-center text-[#0F172A]">
                          <UserCheck className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-[#0F172A]">Sirf Naam Se Aao</p>
                          <p className="text-xs text-slate-500">Bina account ke apna naam jodo</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400" />
                    </button>
                  )}
                </>
              )}

              <div className="pt-2">
                <PWAInstallButton compact={false} />
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section: Exit Button */}
        <div className="px-6 pt-8 pb-8 mt-auto">
          <button
            type="button"
            onClick={() => {
              onClose();
              onExit();
            }}
            className="w-full h-14 rounded-full bg-rose-50 hover:bg-rose-100 border border-rose-200/80 text-rose-600 text-[15px] font-extrabold flex items-center justify-center gap-2 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>{currentMember ? 'Logout' : 'Exit'}</span>
          </button>
        </div>
      </div>
      {/* ===== ADDED: POSTS FEATURE START ===== */}
      {communityOpen && (
        <CommunityPosts
          currentMember={currentMember}
          onClose={() => setCommunityOpen(false)}
          onOpenAuth={() => {
            setCommunityOpen(false);
            onClose();
            onOpenAuth('login');
          }}
        />
      )}
      {/* ===== ADDED: POSTS FEATURE END ===== */}
    </div>
  );
};
