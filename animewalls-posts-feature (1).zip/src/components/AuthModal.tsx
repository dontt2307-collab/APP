import React, { useRef, useState } from 'react';
import { AtSign, Camera, ChevronLeft, Eye, FileText, KeyRound, Smile, User } from 'lucide-react';
import {
  authenticateWithGoogle,
  cancelPendingGoogleOnboarding,
  completeGoogleMemberSetup,
  mapAuthErrorToHinglish,
  MEMBER_LIMIT_MESSAGE,
  sanitizeUsernameInput,
  USERNAME_PATTERN,
} from '../services/authService';
import {
  cleanImgbbKey,
  ImgbbUploadError,
  prependMemberImgbbKey,
  uploadImageWithFallback,
  verifyImgbbKey,
} from '../services/imgbbService';
import { exitViewerSession, joinAsViewer } from '../services/viewerService';
import { AuthModalMode, UserProfile } from '../types';
import { compressImageFile } from '../utils/imageCompress';
import { Avatar } from './Avatar';

interface AuthModalProps {
  initialMode: AuthModalMode;
  /** True when rendered as the dedicated Login Page right after Onboarding */
  isEntryGate?: boolean;
  onClose: () => void;
  onBackToOnboarding?: () => void;
  onContinueAsGuest?: () => void;
  onSignedUp: (profile: UserProfile) => void;
  onLoggedIn: (profile: UserProfile) => void;
  onViewerJoined?: (name: string) => void;
}

type InternalAuthStep = 'login' | 'google_setup' | 'viewer';

const GoogleLogoIcon: React.FC = () => (
  <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
    <path
      fill="#EA4335"
      d="M12 10.2v3.9h5.5c-.24 1.26-.96 2.33-2.04 3.05l3.3 2.56c1.92-1.77 3.04-4.38 3.04-7.48 0-.72-.06-1.41-.19-2.03H12z"
    />
    <path
      fill="#34A853"
      d="M12 22c2.75 0 5.06-.91 6.75-2.47l-3.3-2.56c-.91.61-2.08.98-3.45.98-2.65 0-4.9-1.79-5.7-4.2H2.89v2.64A9.997 9.997 0 0 0 12 22z"
    />
    <path
      fill="#4A90E2"
      d="M6.3 13.75A5.996 5.996 0 0 1 5.98 12c0-.61.11-1.2.32-1.75V7.61H2.89A9.997 9.997 0 0 0 2 12c0 1.61.39 3.14 1.09 4.39l3.21-2.64z"
    />
    <path
      fill="#FBBC05"
      d="M12 6.05c1.5 0 2.84.52 3.9 1.53l2.92-2.92C17.05 3.01 14.75 2 12 2A9.997 9.997 0 0 0 2.89 7.61l3.41 2.64c.8-2.41 3.05-4.2 5.7-4.2z"
    />
  </svg>
);

export const AuthModal: React.FC<AuthModalProps> = ({
  initialMode,
  isEntryGate = false,
  onClose,
  onBackToOnboarding,
  onContinueAsGuest,
  onSignedUp,
  onLoggedIn,
  onViewerJoined,
}) => {
  const [step, setStep] = useState<InternalAuthStep>(initialMode);

  // Post-Google Sign-In setup states
  const [pendingUid, setPendingUid] = useState<string>('');
  const [pendingEmail, setPendingEmail] = useState<string>('');
  const [fullName, setFullName] = useState<string>('');
  const [userName, setUserName] = useState<string>('');
  const [bio, setBio] = useState<string>('');
  const [previewDp, setPreviewDp] = useState<string>('');
  const [defaultHttpsDp, setDefaultHttpsDp] = useState<string>('');
  const [pendingDpBase64, setPendingDpBase64] = useState<string | null>(null);
  const [statusText, setStatusText] = useState<string | null>(null);

  // Name-only viewer state
  const [viewerName, setViewerName] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [needsSetupKey, setNeedsSetupKey] = useState(false);
  const [inlineKeyInput, setInlineKeyInput] = useState('');

  const dpFileInputRef = useRef<HTMLInputElement | null>(null);

  const switchStep = (next: InternalAuthStep) => {
    setError(null);
    setStatusText(null);
    setStep(next);
  };

  const handleTopBack = async () => {
    if (step === 'google_setup') {
      setLoading(true);
      try {
        await cancelPendingGoogleOnboarding();
      } finally {
        setLoading(false);
        setPendingUid('');
        setPendingDpBase64(null);
        switchStep('login');
      }
      return;
    }
    if (step === 'viewer' && isEntryGate) {
      switchStep('login');
      return;
    }
    if (isEntryGate && onBackToOnboarding) {
      onBackToOnboarding();
      return;
    }
    onClose();
  };

  const handleViewerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await joinAsViewer(viewerName);
      if (!res.ok || !res.name) {
        setError(res.error || 'Apna sahi naam daalo.');
        return;
      }
      if (onViewerJoined) onViewerJoined(res.name);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);
    try {
      const outcome = await authenticateWithGoogle();
      if (outcome.status === 'EXISTING') {
        exitViewerSession();
        onLoggedIn(outcome.profile);
        return;
      }

      // New member within the 20-member cap -> enter Name + Username (a-z0-9) + optional DP
      setPendingUid(outcome.uid);
      setPendingEmail(outcome.email);
      setFullName(outcome.suggestedName);
      setUserName(outcome.suggestedUsername);
      setBio('');
      setDefaultHttpsDp(outcome.suggestedDpUrl);
      setPreviewDp(outcome.suggestedDpUrl);
      setPendingDpBase64(null);
      switchStep('google_setup');
    } catch (err) {
      setError(mapAuthErrorToHinglish(err));
    } finally {
      setLoading(false);
    }
  };

  const handlePickSetupDp = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    setStatusText('DP photo compress ho rahi hai...');
    try {
      const compressed = await compressImageFile(file);
      setPreviewDp(compressed.previewDataUrl);
      setPendingDpBase64(compressed.base64Payload);
      setStatusText(null);
    } catch (err) {
      setStatusText(null);
      setError(err instanceof Error ? err.message : 'Photo select nahi ho paayi.');
    }
  };

  const handleCompleteGoogleSetup = async (e?: React.FormEvent, skipCustomDp = false) => {
    if (e) e.preventDefault();
    setError(null);
    setNeedsSetupKey(false);

    const trimmedName = fullName.trim();
    const cleanedHandle = sanitizeUsernameInput(userName);

    if (trimmedName.length < 2 || trimmedName.length > 50) {
      setError('Apna naam 2 se 50 characters ke beech daalo.');
      return;
    }
    if (!USERNAME_PATTERN.test(cleanedHandle)) {
      setError('Username me kam se kam 2 small letters (a-z) ya numbers (0-9) likho.');
      return;
    }

    setLoading(true);
    try {
      let finalDpUrl = defaultHttpsDp;

      if (pendingDpBase64 && !skipCustomDp) {
        setStatusText('DP ImgBB par upload ho rahi hai...');
        finalDpUrl = await uploadImageWithFallback(pendingDpBase64, pendingUid);
      } else if (!previewDp) {
        finalDpUrl = '';
      }

      setStatusText('Account save ho raha hai...');
      const profile = await completeGoogleMemberSetup({
        uid: pendingUid,
        fullName: trimmedName,
        userName: cleanedHandle,
        dpUrl: finalDpUrl,
        bio,
      });

      setStatusText(null);
      exitViewerSession();
      onSignedUp(profile);
    } catch (err) {
      setStatusText(null);
      if (err instanceof ImgbbUploadError) {
        setError(err.message);
        if (err.kind === 'ALL_KEYS_FAILED') {
          setNeedsSetupKey(true);
        }
      } else {
        setError(mapAuthErrorToHinglish(err));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSaveInlineKeyInSetup = async () => {
    const cleaned = cleanImgbbKey(inlineKeyInput);
    if (!cleaned) {
      setError('Sahi ImgBB API key paste karo (https://api.imgbb.com se copy karo).');
      setNeedsSetupKey(true);
      return;
    }
    setLoading(true);
    setStatusText('ImgBB key verify ho rahi hai...');
    try {
      const check = await verifyImgbbKey(cleaned);
      if (!check.valid) {
        setStatusText(null);
        setLoading(false);
        setError(check.message);
        setNeedsSetupKey(true);
        return;
      }
      await prependMemberImgbbKey(pendingUid, cleaned);
      setInlineKeyInput('');
    } catch (err) {
      setStatusText(null);
      setLoading(false);
      setError(err instanceof Error ? err.message : 'Key save nahi ho paayi.');
      setNeedsSetupKey(true);
      return;
    }
    await handleCompleteGoogleSetup(undefined, false);
  };



  return (
    <div
      className={`${
        isEntryGate ? 'min-h-dvh w-full' : 'fixed inset-0 z-50 overflow-y-auto'
      } bg-[#F4F6F9] flex justify-center`}
    >
      <div className="w-full max-w-[430px] min-h-dvh bg-white px-7 pt-5 pb-10 flex flex-col shadow-[0_0_50px_rgba(15,23,42,0.08)]">
        {/* Top Bar */}
        <div className="flex items-center justify-between min-h-[44px]">
          <button
            type="button"
            disabled={loading}
            onClick={() => void handleTopBack()}
            aria-label="Back"
            className="min-h-[44px] min-w-[44px] -ml-2 rounded-full flex items-center justify-center text-[#0F172A] hover:bg-slate-100 disabled:opacity-50 transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <span className="font-script text-[26px] text-[#0F172A] leading-none select-none">
            Business Media
          </span>

          <div className="w-9" />
        </div>

        {/* STEP 1: GOOGLE SIGN-IN ONLY */}
        {step === 'login' && (
          <div className="mt-6 flex-1 flex flex-col justify-between">
            <div>
              <div className="text-center mb-8">
                <h1 className="text-[28px] font-extrabold text-[#0F172A] tracking-tight">
                  Swagat Hai
                </h1>
                <p className="mt-1.5 text-sm text-slate-500">
                  Google se Member Sign In karo
                </p>
              </div>

              {/* Primary Google Sign-In Button */}
              <div className="space-y-4">
                <button
                  type="button"
                  disabled={loading}
                  onClick={() => void handleGoogleSignIn()}
                  className="w-full h-14 rounded-full bg-[#0F172A] hover:bg-slate-800 disabled:opacity-60 text-white text-[15px] font-bold shadow-[0_10px_25px_rgba(15,23,42,0.14)] px-6 flex items-center justify-center gap-3 transition-all"
                >
                  <span className="w-8 h-8 rounded-full bg-white flex items-center justify-center shrink-0">
                    <GoogleLogoIcon />
                  </span>
                  <span>
                    {loading ? 'Google khul raha hai...' : 'Google se Sign In karo'}
                  </span>
                </button>

                <p className="text-center text-xs text-slate-400 font-medium px-2">
                  Sign in ke baad apna Naam aur Username chuno
                </p>

                {error && (
                  <div className="rounded-[20px] bg-rose-50 px-4 py-3.5 text-sm text-rose-700 font-medium leading-relaxed">
                    <p>{error}</p>
                  </div>
                )}
              </div>

              <div className="my-7 flex items-center gap-3">
                <div className="h-px flex-1 bg-slate-200" />
                <span className="text-xs text-slate-400 font-medium">ya bina login ke</span>
                <div className="h-px flex-1 bg-slate-200" />
              </div>

              <div className="space-y-3">
                <button
                  type="button"
                  disabled={loading}
                  onClick={() => switchStep('viewer')}
                  className="w-full h-13 rounded-full bg-[#F3F4F6] hover:bg-slate-200/80 text-[#0F172A] text-sm font-bold px-5 transition-colors"
                >
                  Bina account ke, sirf naam se aao
                </button>
              </div>
            </div>

            <p className="mt-8 text-center text-xs text-slate-400">
              Sirf Apne Log &middot; Sirf Apni Post
            </p>
          </div>
        )}

        {/* NAME-ONLY VIEWER MODE */}
        {step === 'viewer' && (
          <div className="mt-4 flex-1 flex flex-col justify-between">
            <div>
              <div className="text-center mb-7">
                <h1 className="text-[28px] font-extrabold text-[#0F172A] tracking-tight">
                  Sirf naam se aao
                </h1>
                <p className="mt-1.5 text-sm text-slate-500">
                  Bina login ke saari Business aur Sarkari Naukri posts dekho
                </p>
              </div>

              <form onSubmit={(e) => void handleViewerSubmit(e)} className="space-y-4">
                <label className="flex items-center gap-3.5 bg-[#F3F4F6] rounded-full h-14 px-5 focus-within:ring-2 focus-within:ring-[#0F172A]/20 transition-shadow">
                  <Smile className="w-5 h-5 text-slate-400 shrink-0" />
                  <input
                    type="text"
                    value={viewerName}
                    onChange={(e) => setViewerName(e.target.value)}
                    placeholder="Apna naam likho (max 50 chars)"
                    maxLength={50}
                    required
                    className="w-full bg-transparent text-[15px] text-[#0F172A] placeholder:text-slate-400 outline-none"
                  />
                </label>

                {error && (
                  <div className="rounded-[20px] bg-rose-50 px-4 py-3 text-sm text-rose-700 font-medium">
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="mt-2 w-full h-14 rounded-full bg-[#0F172A] hover:bg-slate-800 disabled:opacity-60 text-white text-[15px] font-bold shadow-[0_10px_25px_rgba(15,23,42,0.14)] transition-all"
                >
                  {loading ? 'Chalu ho raha hai...' : 'Andar Aao'}
                </button>
              </form>
            </div>

            <div className="mt-8 text-center">
              <button
                type="button"
                onClick={() => switchStep('login')}
                className="block w-full py-2 text-sm text-slate-600 hover:text-[#0F172A]"
              >
                Member banna hai?{' '}
                <span className="font-bold text-[#0F172A]">Google se Sign In karo</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: POST-GOOGLE SIGN-IN -> ENTER NAME, USERNAME (a-z0-9) & DP */}
        {step === 'google_setup' && (
          <div className="mt-3 flex-1 flex flex-col justify-between">
            <div>
              <div className="text-center mb-6">
                <h1 className="text-[26px] font-extrabold text-[#0F172A] tracking-tight">
                  Apni profile banao
                </h1>
                <p className="mt-1 text-sm text-slate-500">
                  {pendingEmail
                    ? `${pendingEmail} se jud gaye — ab naam aur username rakho`
                    : 'Apna naam, username aur DP set karo'}
                </p>
              </div>

              {/* Circular DP Picker */}
              <div className="flex flex-col items-center mb-6">
                <div className="relative">
                  <Avatar
                    src={previewDp}
                    name={fullName || userName || 'Member'}
                    sizeClass="w-24 h-24"
                    textSizeClass="text-3xl"
                    ringClass="ring-4 ring-slate-100 shadow-md"
                  />
                  <button
                    type="button"
                    disabled={loading}
                    onClick={() => dpFileInputRef.current?.click()}
                    aria-label="Choose profile photo"
                    className="absolute bottom-0 right-0 w-9 h-9 rounded-full bg-white text-[#0F172A] shadow-md border border-slate-200 flex items-center justify-center hover:bg-slate-50 transition-colors"
                  >
                    <Camera className="w-4 h-4" />
                  </button>
                  <input
                    ref={dpFileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={(e) => void handlePickSetupDp(e)}
                    className="hidden"
                  />
                </div>
                <span className="mt-2 text-xs text-slate-400 font-medium">
                  DP image lagane ke liye camera icon dabao (optional)
                </span>
              </div>

              <form onSubmit={(e) => void handleCompleteGoogleSetup(e, false)} className="space-y-4">
                {/* Enter Name */}
                <div>
                  <label className="flex items-center gap-3.5 bg-[#F3F4F6] rounded-full h-14 px-5 focus-within:ring-2 focus-within:ring-[#0F172A]/20 transition-shadow">
                    <User className="w-5 h-5 text-slate-400 shrink-0" />
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="Enter Name (Aapka poora naam)"
                      maxLength={50}
                      required
                      className="w-full bg-transparent text-[15px] text-[#0F172A] placeholder:text-slate-400 outline-none"
                    />
                  </label>
                </div>

                {/* Enter Username (strictly small letters a-z & numbers 0-9) */}
                <div>
                  <label className="flex items-center gap-3 bg-[#F3F4F6] rounded-full h-14 px-5 focus-within:ring-2 focus-within:ring-[#0F172A]/20 transition-shadow">
                    <AtSign className="w-5 h-5 text-slate-400 shrink-0" />
                    <input
                      type="text"
                      value={userName}
                      onChange={(e) => setUserName(sanitizeUsernameInput(e.target.value))}
                      placeholder="username (small letters aur numbers)"
                      autoCapitalize="none"
                      autoCorrect="off"
                      spellCheck={false}
                      maxLength={30}
                      required
                      className="w-full bg-transparent text-[15px] font-semibold text-[#0F172A] placeholder:font-normal placeholder:text-slate-400 outline-none"
                    />
                  </label>
                  <p className="mt-1.5 px-3 text-xs text-slate-500">
                    Sirf small letters (<span className="font-semibold">a-z</span>) aur numbers (
                    <span className="font-semibold">0-9</span>) allowed hain (jaise{' '}
                    <span className="font-semibold">rahul07</span>)
                  </p>
                </div>

                {/* Optional Bio */}
                <label className="flex items-start gap-3.5 bg-[#F3F4F6] rounded-[24px] py-3.5 px-5 focus-within:ring-2 focus-within:ring-[#0F172A]/20 transition-shadow">
                  <FileText className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
                  <textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="Chhota sa bio likho (optional)"
                    rows={2}
                    maxLength={160}
                    className="w-full bg-transparent text-[15px] text-[#0F172A] placeholder:text-slate-400 outline-none resize-none"
                  />
                </label>

                {statusText && (
                  <div className="rounded-[20px] bg-slate-100 px-4 py-3 text-xs font-semibold text-slate-700 text-center">
                    {statusText}
                  </div>
                )}

                {error && (
                  <div className="rounded-[20px] bg-rose-50 border border-rose-100 px-4 py-3.5 text-xs font-semibold text-rose-800 leading-relaxed space-y-2.5">
                    <p>{error}</p>
                    {needsSetupKey && (
                      <div className="space-y-2 pt-1">
                        <div className="flex items-center gap-2 bg-white rounded-full h-10 px-4 border border-rose-200">
                          <KeyRound className="w-4 h-4 text-slate-400 shrink-0" />
                          <input
                            type="text"
                            autoComplete="off"
                            autoCapitalize="none"
                            autoCorrect="off"
                            spellCheck={false}
                            disabled={loading}
                            value={inlineKeyInput}
                            onChange={(e) => setInlineKeyInput(e.target.value)}
                            placeholder="Yahan ImgBB API key paste karo..."
                            className="w-full bg-transparent text-xs font-medium text-[#0F172A] placeholder:text-slate-400 outline-none"
                          />
                        </div>
                        <button
                          type="button"
                          disabled={loading || !inlineKeyInput.trim()}
                          onClick={() => void handleSaveInlineKeyInSetup()}
                          className="px-4 h-9 rounded-full bg-[#0F172A] disabled:opacity-50 text-white text-xs font-bold"
                        >
                          Key Save & DP Upload Karo
                        </button>
                      </div>
                    )}
                    {pendingDpBase64 && (
                      <div>
                        <button
                          type="button"
                          disabled={loading}
                          onClick={() => void handleCompleteGoogleSetup(undefined, true)}
                          className="px-4 h-9 rounded-full bg-white border border-rose-200 text-rose-800 text-xs font-bold"
                        >
                          Bina nayi DP ke save karo
                        </button>
                      </div>
                    )}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="mt-2 w-full h-14 rounded-full bg-[#0F172A] hover:bg-slate-800 disabled:opacity-60 text-white text-[15px] font-bold shadow-[0_10px_25px_rgba(15,23,42,0.14)] transition-all"
                >
                  {loading ? 'Save ho raha hai...' : 'Continue'}
                </button>
              </form>
            </div>
          </div>
        )}


      </div>
    </div>
  );
};
