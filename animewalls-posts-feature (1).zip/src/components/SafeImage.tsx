import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ImageOff, RefreshCw } from 'lucide-react';
import { getImgbbProxyFallbackUrl } from '../services/imgbbService';

interface SafeImageProps {
  src: string;
  alt: string;
  className?: string;
  imgClassName?: string;
  fit?: 'cover' | 'contain';
  autoHeight?: boolean;
  fallbackLabel?: string;
}

export const SafeImage: React.FC<SafeImageProps> = ({
  src,
  alt,
  className = '',
  imgClassName = '',
  fit = 'cover',
  autoHeight = false,
  fallbackLabel,
}) => {
  const cleanSrc = (src || '').trim();
  const [effectiveSrc, setEffectiveSrc] = useState(cleanSrc);
  const [attemptStage, setAttemptStage] = useState<0 | 1 | 2>(0);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(!cleanSrc);
  const imgRef = useRef<HTMLImageElement | null>(null);

  const syncIfAlreadyComplete = useCallback((node: HTMLImageElement | null) => {
    imgRef.current = node;
    if (node && node.complete && node.naturalWidth > 0) {
      setLoaded(true);
      setFailed(false);
    }
  }, []);

  useEffect(() => {
    setEffectiveSrc(cleanSrc);
    setAttemptStage(0);
    setFailed(!cleanSrc);

    const node = imgRef.current;
    if (cleanSrc && node && node.src && node.complete && node.naturalWidth > 0) {
      setLoaded(true);
    } else {
      setLoaded(false);
    }
  }, [cleanSrc]);

  // Automatically retry failed images as soon as device reconnects to internet
  useEffect(() => {
    if (!failed || !cleanSrc) return;
    const onReconnect = () => {
      setFailed(false);
      setLoaded(false);
      setAttemptStage(0);
      setEffectiveSrc(cleanSrc);
    };
    window.addEventListener('online', onReconnect);
    return () => window.removeEventListener('online', onReconnect);
  }, [failed, cleanSrc]);

  const handleImageError = () => {
    // Stage 0 -> Stage 1: Try same-origin /api/image-proxy if ImgBB/Google host is blocked by ISP DNS
    if (attemptStage === 0) {
      const proxyUrl = getImgbbProxyFallbackUrl(cleanSrc);
      if (proxyUrl) {
        setAttemptStage(1);
        setLoaded(false);
        setEffectiveSrc(proxyUrl);
        return;
      }
    }

    // Stage 1 -> Stage 2: One cache-busted direct retry for transient mobile carrier hiccups
    if (attemptStage < 2 && cleanSrc.startsWith('https://')) {
      setAttemptStage(2);
      setLoaded(false);
      const sep = cleanSrc.includes('?') ? '&' : '?';
      setEffectiveSrc(`${cleanSrc}${sep}_r=${Date.now()}`);
      return;
    }

    setFailed(true);
  };

  const handleManualRetry = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!cleanSrc) return;
    setFailed(false);
    setLoaded(false);
    setAttemptStage(0);
    const sep = cleanSrc.includes('?') ? '&' : '?';
    setEffectiveSrc(`${cleanSrc}${sep}_r=${Date.now()}`);
  };

  if (failed || !effectiveSrc) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 via-slate-200/70 to-slate-100 text-slate-400 select-none py-10 ${className}`}
      >
        <ImageOff className="w-7 h-7 mb-2 opacity-70" />
        <span className="text-xs font-medium text-slate-500 px-3 text-center truncate max-w-full">
          {fallbackLabel || 'Photo load nahi hui'}
        </span>
        {cleanSrc && (
          <button
            type="button"
            onClick={handleManualRetry}
            className="mt-2.5 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white text-[#0F172A] text-[11px] font-bold shadow-xs border border-slate-200 hover:bg-slate-50 transition-colors"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Dobara Load Karo</span>
          </button>
        )}
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {!loaded && (
        <div className="absolute inset-0 min-h-[160px] animate-pulse bg-gradient-to-r from-slate-100 via-slate-200/70 to-slate-100" />
      )}
      <img
        ref={syncIfAlreadyComplete}
        src={effectiveSrc}
        alt={alt}
        referrerPolicy="no-referrer"
        decoding="async"
        loading="eager"
        onLoad={() => {
          setLoaded(true);
          setFailed(false);
        }}
        onError={handleImageError}
        className={`${autoHeight ? 'w-full h-auto block' : 'w-full h-full block'} ${
          fit === 'contain' ? 'object-contain' : 'object-cover object-center'
        } transition-opacity duration-200 ${loaded ? 'opacity-100' : 'opacity-0'} ${imgClassName}`}
      />
    </div>
  );
};
