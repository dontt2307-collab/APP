import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Briefcase, Search as SearchIcon, Trash2, X } from 'lucide-react';
import { NAV_JOB_LABEL } from '../config';
import { fetchPostsPage, searchPostsMerged } from '../services/postService';
import { fetchAllMembersOnce, getUserFromMemory } from '../services/userCache';
import { PostItem, SearchCursors, UserProfile } from '../types';
import { Avatar } from './Avatar';
import { LikeButton } from './LikeButton';
import { LimitExceededCard } from './LimitExceededCard';
import { SafeImage } from './SafeImage';
import { GridSkeleton } from './Skeletons';

interface SearchViewProps {
  currentMember: UserProfile | null;
  refreshSignal: number;
  isAdmin: boolean;
  onSelectPost: (post: PostItem) => void;
  onOpenMemberProfile: (uid: string) => void;
}

export const SearchView: React.FC<SearchViewProps> = ({
  currentMember,
  refreshSignal,
  isAdmin,
  onSelectPost,
  onOpenMemberProfile,
}) => {
  const [inputText, setInputText] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');

  const [recentPosts, setRecentPosts] = useState<PostItem[]>([]);
  const [loadingRecent, setLoadingRecent] = useState(true);

  const [results, setResults] = useState<PostItem[]>([]);
  const [cursors, setCursors] = useState<SearchCursors | undefined>(undefined);
  const [hasMore, setHasMore] = useState(false);
  const [searching, setSearching] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [limitExceeded, setLimitExceeded] = useState(false);

  const sentinelRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const t = window.setTimeout(() => {
      setDebouncedQuery(inputText.trim());
    }, 300);
    return () => window.clearTimeout(t);
  }, [inputText]);

  useEffect(() => {
    let active = true;
    (async () => {
      setLoadingRecent(true);
      try {
        const isMemberOrAdmin = Boolean(currentMember || isAdmin);
        const [res] = await Promise.all([
          fetchPostsPage(null, isMemberOrAdmin),
          fetchAllMembersOnce().catch(() => [] as UserProfile[]),
        ]);
        if (active) {
          if (res.limitExceeded) {
            setLimitExceeded(true);
            setRecentPosts([]);
          } else {
            setLimitExceeded(false);
            setRecentPosts(res.posts);
          }
        }
      } catch {
        // Handled gracefully
      } finally {
        if (active) setLoadingRecent(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [currentMember, isAdmin, refreshSignal]);

  const executeInitialSearch = useCallback(async (q: string) => {
    if (!q) {
      setResults([]);
      setCursors(undefined);
      setHasMore(false);
      setError(null);
      return;
    }

    setSearching(true);
    setError(null);
    try {
      const isMemberOrAdmin = Boolean(currentMember || isAdmin);
      const res = await searchPostsMerged(q, undefined, isMemberOrAdmin);
      if (res.limitExceeded) {
        setLimitExceeded(true);
        setResults([]);
      } else {
        setResults(res.posts);
        setCursors(res.cursors);
        setHasMore(res.hasMore);
      }
    } catch {
      setError('Search karte waqt dikkat aayi. Dobara try karo.');
    } finally {
      setSearching(false);
    }
  }, [currentMember, isAdmin]);

  useEffect(() => {
    void executeInitialSearch(debouncedQuery);
  }, [debouncedQuery, executeInitialSearch]);

  const loadMoreResults = useCallback(async () => {
    if (!debouncedQuery || loadingMore || !hasMore || !cursors || limitExceeded) return;
    setLoadingMore(true);
    try {
      const isMemberOrAdmin = Boolean(currentMember || isAdmin);
      const res = await searchPostsMerged(debouncedQuery, cursors, isMemberOrAdmin);
      if (res.limitExceeded) {
        setLimitExceeded(true);
        setHasMore(false);
        return;
      }
      setResults((prev) => {
        const seen = new Set(prev.map((p) => p.id));
        return [...prev, ...res.posts.filter((p) => !seen.has(p.id))];
      });
      setCursors(res.cursors);
      setHasMore(res.hasMore);
    } catch {
      // Retry on scroll
    } finally {
      setLoadingMore(false);
    }
  }, [cursors, currentMember, debouncedQuery, hasMore, isAdmin, limitExceeded, loadingMore]);

  useEffect(() => {
    const node = sentinelRef.current;
    if (!node || !hasMore || searching || limitExceeded) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          void loadMoreResults();
        }
      },
      { rootMargin: '240px' }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [hasMore, limitExceeded, loadMoreResults, searching]);

  const activePosts = debouncedQuery ? results : recentPosts;
  const isBusy = debouncedQuery ? searching : loadingRecent;

  return (
    <div className="min-h-dvh pb-24 bg-white">
      {/* Search Input Bar */}
      <div className="sticky top-0 z-20 bg-white/95 backdrop-blur-md px-5 pt-3 pb-3 border-b border-slate-100/80">
        <label
          htmlFor="searchInput"
          className="flex items-center gap-3 h-12 px-4 rounded-full bg-[#F3F4F6] focus-within:ring-2 focus-within:ring-[#0F172A]/20 transition-all cursor-text"
        >
          <SearchIcon className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            id="searchInput"
            type="search"
            autoComplete="off"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Naam ya caption ka shabd likho..."
            className="w-full bg-transparent text-[15px] text-[#0F172A] placeholder:text-slate-400 outline-none"
          />
          {inputText && (
            <button
              type="button"
              onClick={() => setInputText('')}
              aria-label="Clear search"
              className="w-7 h-7 rounded-full bg-slate-200/80 text-slate-600 flex items-center justify-center shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </label>

        <p className="mt-2 px-1 text-xs text-slate-400 font-medium">
          Pichle 2 din ki saari posts search me shamil hain
        </p>
      </div>

      {/* Results / Recent Grid */}
      <div className="pt-3">
        {!debouncedQuery && activePosts.length > 0 && (
          <p className="px-5 mb-2.5 text-xs font-bold text-slate-500">Taaza Explore</p>
        )}

        {isBusy ? (
          <GridSkeleton />
        ) : limitExceeded && activePosts.length === 0 ? (
          <div className="px-5 py-4">
            <LimitExceededCard isInline={false} />
          </div>
        ) : error ? (
          <div className="mx-5 my-6 rounded-[24px] bg-slate-50 p-6 text-center space-y-3">
            <p className="text-sm text-slate-600 font-medium">{error}</p>
            <button
              type="button"
              onClick={() => void executeInitialSearch(debouncedQuery)}
              className="px-5 h-11 rounded-full bg-[#0F172A] text-white text-xs font-bold"
            >
              Dobara Try Karo
            </button>
          </div>
        ) : activePosts.length === 0 ? (
          <div className="mx-5 my-8 rounded-[24px] bg-[#F8FAFC] border border-slate-100 p-8 text-center">
            <p className="text-base font-bold text-[#0F172A]">
              {debouncedQuery ? 'Koi matching post nahi mili' : 'Abhi koi post nahi hai'}
            </p>
            <p className="mt-1.5 text-xs text-slate-500">
              {debouncedQuery
                ? 'Member ke naam ki shuruaat ya caption ka poora shabd try karo.'
                : 'Nayi posts aate hi yahan grid me dikhengi.'}
            </p>
          </div>
        ) : (
          <div className="px-5">
            <div className="grid grid-cols-2 gap-3.5">
              {activePosts.map((post) => {
                const cachedAuthor = getUserFromMemory(post.uid);
                const authorName =
                  cachedAuthor?.fullName ||
                  post.userFullName ||
                  cachedAuthor?.userName ||
                  post.userName;
                const authorDp = cachedAuthor?.dpUrl || post.userDpUrl;
                const isJob = post.category === 'sarkari_naukri';

                return (
                  <div
                    key={post.id}
                    className="relative aspect-[4/5] rounded-[22px] overflow-hidden bg-slate-100 border border-slate-100 shadow-xs group"
                  >
                    <button
                      type="button"
                      onClick={() => onSelectPost(post)}
                      className="w-full h-full block text-left"
                    >
                      <SafeImage
                        src={post.imageUrl}
                        alt={post.caption || authorName}
                        className="w-full h-full"
                      />
                    </button>

                    {/* Sarkari Naukri Badge on Photo */}
                    {isJob && (
                      <div className="absolute top-2 left-2 z-10 flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-700/90 backdrop-blur-xs text-white text-[9.5px] font-bold shadow-sm">
                        <Briefcase className="w-2.5 h-2.5" />
                        <span>{NAV_JOB_LABEL}</span>
                      </div>
                    )}

                    {/* Top-right compact Like / Delete */}
                    <div className="absolute top-2.5 right-2.5 z-10 flex flex-col gap-2">
                      <LikeButton
                        post={post}
                        currentMember={currentMember}
                        variant="compact"
                      />
                      {(isAdmin || (currentMember && post.uid === currentMember.uid)) && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectPost(post);
                          }}
                          className="w-8 h-8 rounded-full bg-rose-50/90 backdrop-blur-xs text-rose-600 flex items-center justify-center shadow-sm"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent pt-10 pb-3 px-3 pointer-events-none">
                      <button
                        type="button"
                        onClick={() => onOpenMemberProfile(post.uid)}
                        className="pointer-events-auto inline-flex items-center gap-2 max-w-full"
                      >
                        <Avatar
                          src={authorDp}
                          name={authorName}
                          sizeClass="w-6 h-6"
                          textSizeClass="text-[10px]"
                          ringClass="ring-1 ring-white/80"
                        />
                        <span className="text-xs font-bold text-white truncate hover:underline">
                          {authorName}
                        </span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {limitExceeded ? (
              <div className="mt-4">
                <LimitExceededCard isInline={true} />
              </div>
            ) : (
              <div ref={sentinelRef} className="h-8 flex items-center justify-center mt-3">
                {loadingMore && (
                  <span className="text-xs font-semibold text-slate-400">
                    Aur results load ho rahe hain...
                  </span>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
