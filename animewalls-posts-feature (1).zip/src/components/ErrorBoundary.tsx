import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error caught by ErrorBoundary:', error, errorInfo);
  }

  private handleReload = () => {
    window.location.reload();
  };

  private handleReset = () => {
    try {
      localStorage.removeItem('onboarding_done');
    } catch {}
    this.setState({ hasError: false, error: null });
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-dvh w-full bg-[#0F172A] flex items-center justify-center p-6 text-white select-none">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center shadow-2xl flex flex-col items-center">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 mb-4">
              <AlertTriangle className="w-7 h-7" />
            </div>
            <h2 className="text-xl font-bold tracking-tight mb-2">Kuch rukawat aayi</h2>
            <p className="text-sm text-slate-400 mb-6 leading-relaxed">
              App load karte waqt chhota issue aaya. Dobara try karein.
            </p>
            <div className="w-full space-y-3">
              <button
                type="button"
                onClick={this.handleReload}
                className="w-full h-12 rounded-full bg-white text-[#0F172A] font-bold text-sm flex items-center justify-center gap-2 hover:bg-slate-100 transition-colors shadow-lg"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Reload Karein</span>
              </button>
              <button
                type="button"
                onClick={this.handleReset}
                className="w-full h-11 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition-colors"
              >
                Reset & Restart
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
