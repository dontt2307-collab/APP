// ===== ADDED: POSTS FEATURE START =====
// Admin > "Posts & Users": stats, all posts (delete), users list (ban / unban).
// Admin check is done by the backend: GET /api/me -> isAdmin (not Firestore).
import React, { useCallback, useEffect, useState } from 'react';
import { ChevronLeft, RefreshCw, ShieldAlert, Trash2 } from 'lucide-react';
import { api, ApiPost, ApiUser, formatApiDate, isApiConfigured } from '../services/apiService';
import { importFirestorePostsToBackend } from '../services/postService';
import { Avatar } from './Avatar';
import { SafeImage } from './SafeImage';

const PAGE = 20;

interface AdminPostsUsersProps {
  onBack: () => void;
}

export const AdminPostsUsers: React.FC<AdminPostsUsersProps> = ({ onBack }) => {
  const [allowed, setAllowed] = useState<boolean | null>(null);
  const [stats, setStats] = useState<{ users: number; posts: number } | null>(null);
  const [posts, setPosts] = useState<ApiPost[]>([]);
  const [hasMore, setHasMore] = useState(false);
  const [users, setUsers] = useState<ApiUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [view, setView] = useState<'posts' | 'users'>('posts');
  const [msg, setMsg] = useState<{ text: string; err: boolean } | null>(null);

  const say = (text: string, err = false) => {
    setMsg({ text, err });
    window.setTimeout(() => setMsg(null), 3500);
  };
  const errText = (e: unknown) => (e instanceof Error ? e.message : 'Kuch galat ho gaya.');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const me = await api<{ isAdmin: boolean }>('/api/me');
      if (!me.isAdmin) {
        setAllowed(false);
        return;
      }
      setAllowed(true);
      const [s, p, u] = await Promise.all([
        api<{ users: number; posts: number }>('/api/admin/stats'),
        api<ApiPost[]>(`/api/posts?limit=${PAGE}`),
        api<ApiUser[]>('/api/admin/users'),
      ]);
      setStats(s);
      setPosts(p);
      setHasMore(p.length === PAGE);
      setUsers(u);
    } catch (e) {
      say(errText(e), true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const loadMore = async () => {
    setLoadingMore(true);
    try {
      const rows = await api<ApiPost[]>(
        `/api/posts?limit=${PAGE}&before_id=${posts[posts.length - 1].id}`
      );
      setPosts((p) => [...p, ...rows]);
      setHasMore(rows.length === PAGE);
    } catch (e) {
      say(errText(e), true);
    } finally {
      setLoadingMore(false);
    }
  };

  const delPost = async (id: number) => {
    if (!window.confirm('Ye post delete karein?')) return;
    setBusy('p' + id);
    try {
      await api(`/api/posts/${id}`, { method: 'DELETE' });
      say('Post delete ho gayi.');
      await load();
    } catch (e) {
      say(errText(e), true);
    } finally {
      setBusy(null);
    }
  };

  const importOld = async () => {
    if (!window.confirm('Firestore ki purani posts (max 500) backend me copy karein? Duplicate nahi banenge.')) return;
    setBusy('import');
    try {
      const n = await importFirestorePostsToBackend();
      say(`${n} purani posts import ho gayi.`);
      await load();
    } catch (e) {
      say(errText(e), true);
    } finally {
      setBusy(null);
    }
  };

  const toggleBan = async (u: ApiUser) => {
    const ban = !u.banned;
    if (ban && !window.confirm(`${u.name || u.email || 'Is user'} ko ban karein?`)) return;
    setBusy('u' + u.uid);
    try {
      await api(`/api/admin/users/${encodeURIComponent(u.uid)}/ban`, {
        method: 'POST',
        body: { banned: ban },
      });
      setUsers((list) => list.map((x) => (x.uid === u.uid ? { ...x, banned: ban ? 1 : 0 } : x)));
      say(ban ? 'User ban ho gaya.' : 'User unban ho gaya.');
    } catch (e) {
      say(errText(e), true);
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="p-4 space-y-4">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-[#0F172A] transition-colors mb-1"
      >
        <ChevronLeft className="w-4 h-4" />
        <span>Back to Overview</span>
      </button>

      {msg && (
        <div
          role="status"
          className={`rounded-2xl px-4 py-3 text-xs font-bold ${
            msg.err
              ? 'bg-rose-50 border border-rose-200 text-rose-800'
              : 'bg-emerald-50 border border-emerald-200 text-emerald-800'
          }`}
        >
          {msg.text}
        </div>
      )}

      {!isApiConfigured() ? (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs font-semibold text-amber-900">
          Backend URL set nahi hai. <code>.env</code> me <code>VITE_API_BASE</code> daalo.
        </div>
      ) : loading && allowed === null ? (
        <div className="py-12 flex justify-center text-slate-400">
          <RefreshCw className="w-5 h-5 animate-spin" />
        </div>
      ) : allowed === false ? (
        <div className="p-6 rounded-2xl bg-white border border-slate-200/80 text-center space-y-2">
          <ShieldAlert className="w-6 h-6 text-rose-500 mx-auto" />
          <p className="text-xs font-bold text-[#0F172A]">Backend ke hisaab se aap admin nahi ho.</p>
          <p className="text-[11px] text-slate-500">
            Sirf dxobad000@gmail.com se login karne par admin milega.
          </p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-2.5">
            <div className="p-3 rounded-2xl bg-indigo-50/60 border border-indigo-100/80">
              <span className="text-[10px] font-bold text-indigo-700 block">Backend Users</span>
              <span className="text-xl font-black text-[#0F172A] tabular-nums">{stats?.users ?? 0}</span>
            </div>
            <div className="p-3 rounded-2xl bg-emerald-50/60 border border-emerald-100/80">
              <span className="text-[10px] font-bold text-emerald-700 block">Community Posts</span>
              <span className="text-xl font-black text-[#0F172A] tabular-nums">{stats?.posts ?? 0}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 p-1.5 rounded-full bg-[#F3F4F6]">
            {(['posts', 'users'] as const).map((v) => (
              <button
                key={v}
                type="button"
                onClick={() => setView(v)}
                className={`h-10 rounded-full text-xs font-bold transition-all ${
                  view === v ? 'bg-[#0F172A] text-white shadow-sm' : 'text-slate-600'
                }`}
              >
                {v === 'posts' ? `All Posts (${stats?.posts ?? 0})` : `Users (${users.length})`}
              </button>
            ))}
          </div>

          <button
            type="button"
            disabled={busy === 'import'}
            onClick={() => void importOld()}
            className="w-full h-10 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold disabled:opacity-50"
          >
            {busy === 'import' ? 'Import ho raha hai...' : 'Purani Firestore posts backend me import karo (ek baar)'}
          </button>

          {view === 'posts' ? (
            <div className="space-y-3">
              {posts.length === 0 && (
                <p className="py-8 text-center text-xs text-slate-400 font-medium">Koi post nahi hai.</p>
              )}
              {posts.map((p) => (
                <div
                  key={p.id}
                  className="rounded-2xl bg-white border border-slate-200/80 shadow-2xs overflow-hidden"
                >
                  <div className="flex items-center gap-2.5 p-3">
                    <Avatar
                      src={p.user_photo || ''}
                      name={p.user_name || 'Member'}
                      sizeClass="w-8 h-8"
                      textSizeClass="text-xs"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-extrabold text-[#0F172A] truncate">
                        {p.user_name || 'Member'}
                      </p>
                      <p className="text-[10px] text-slate-400">{formatApiDate(p.created_at)}</p>
                    </div>
                    <button
                      type="button"
                      disabled={busy === 'p' + p.id}
                      onClick={() => void delPost(p.id)}
                      aria-label="Delete post"
                      className="h-8 px-3 rounded-full bg-rose-50 text-rose-600 text-[11px] font-bold flex items-center gap-1 disabled:opacity-40"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Delete
                    </button>
                  </div>
                  <SafeImage src={p.url} alt={p.caption || 'Post'} autoHeight fit="contain" />
                  {p.caption && (
                    <p className="p-3 text-xs text-slate-700 whitespace-pre-wrap break-words">{p.caption}</p>
                  )}
                </div>
              ))}
              {hasMore && (
                <button
                  type="button"
                  disabled={loadingMore}
                  onClick={() => void loadMore()}
                  className="w-full h-11 rounded-full bg-slate-100 text-slate-700 text-xs font-bold disabled:opacity-50"
                >
                  Aur dikhao
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-2.5">
              {users.length === 0 && (
                <p className="py-8 text-center text-xs text-slate-400 font-medium">Koi user nahi hai.</p>
              )}
              {users.map((u) => (
                <div
                  key={u.uid}
                  className="p-3 rounded-2xl bg-white border border-slate-200/80 shadow-2xs flex items-center gap-3"
                >
                  <Avatar
                    src={u.photo || ''}
                    name={u.name || u.email || 'User'}
                    sizeClass="w-10 h-10"
                    textSizeClass="text-sm"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-extrabold text-[#0F172A] truncate">
                      {u.name || '(no name)'}
                      {u.banned ? (
                        <span className="ml-2 text-[10px] bg-rose-100 text-rose-700 font-black px-2 py-0.5 rounded-full">
                          BANNED
                        </span>
                      ) : null}
                    </p>
                    <p className="text-[11px] text-slate-500 truncate">{u.email}</p>
                    <p className="text-[10px] text-slate-400">
                      {u.post_count} posts · last login {formatApiDate(u.last_login)}
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={busy === 'u' + u.uid}
                    onClick={() => void toggleBan(u)}
                    className={`h-8 px-3 rounded-full text-[11px] font-bold disabled:opacity-40 ${
                      u.banned ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-600'
                    }`}
                  >
                    {u.banned ? 'Unban' : 'Ban'}
                  </button>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};
// ===== ADDED: POSTS FEATURE END =====
