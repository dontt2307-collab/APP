// ===== ADDED: POSTS FEATURE START =====
// "Community Posts": feed of ALL members' posts (public), upload / edit / delete via Flask API.
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Check, ChevronLeft, ImagePlus, Lock, Pencil, RefreshCw, Trash2, X } from 'lucide-react';
import { api, ApiPost, formatApiDate, isApiConfigured } from '../services/apiService';
import { UserProfile } from '../types';
import { Avatar } from './Avatar';
import { SafeImage } from './SafeImage';

const PAGE = 20;
const MAX_BYTES = 5 * 1024 * 1024;
const OK_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

interface CommunityPostsProps {
  currentMember: UserProfile | null;
  onClose: () => void;
  onOpenAuth: () => void;
}

export const CommunityPosts: React.FC<CommunityPostsProps> = ({
  currentMember,
  onClose,
  onOpenAuth,
}) => {
  const [posts, setPosts] = useState<ApiPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [myUid, setMyUid] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);

  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [uploading, setUploading] = useState(false);

  const [editingId, setEditingId] = useState<number | null>(null);
  const [editText, setEditText] = useState('');
  const [busyId, setBusyId] = useState<number | null>(null);
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const [toast, setToast] = useState<{ text: string; kind: 'ok' | 'err' } | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);

  const showToast = useCallback((text: string, kind: 'ok' | 'err' = 'ok') => {
    setToast({ text, kind });
    window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 3500);
  }, []);

  const errText = (e: unknown) => (e instanceof Error ? e.message : 'Kuch galat ho gaya.');

  const loadFeed = useCallback(async () => {
    setLoading(true);
    try {
      const rows = await api<ApiPost[]>(`/api/posts?limit=${PAGE}`);
      setPosts(rows);
      setHasMore(rows.length === PAGE);
    } catch (e) {
      showToast(errText(e), 'err');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    void loadFeed();
    return () => window.clearTimeout(toastTimer.current);
  }, [loadFeed]);

  // Who am I + am I admin (decided by the backend, not Firestore)
  useEffect(() => {
    if (!currentMember) {
      setMyUid(null);
      setIsAdmin(false);
      return;
    }
    let active = true;
    api<{ uid: string; isAdmin: boolean }>('/api/me')
      .then((me) => {
        if (!active) return;
        setMyUid(me.uid);
        setIsAdmin(Boolean(me.isAdmin));
      })
      .catch((e) => {
        if (active) showToast(errText(e), 'err'); // e.g. 403 "Account banned"
      });
    return () => {
      active = false;
    };
  }, [currentMember, showToast]);

  useEffect(() => {
    return () => {
      if (preview) URL.revokeObjectURL(preview);
    };
  }, [preview]);

  const loadMore = async () => {
    if (!posts.length) return;
    setLoadingMore(true);
    try {
      const rows = await api<ApiPost[]>(
        `/api/posts?limit=${PAGE}&before_id=${posts[posts.length - 1].id}`
      );
      setPosts((p) => [...p, ...rows]);
      setHasMore(rows.length === PAGE);
    } catch (e) {
      showToast(errText(e), 'err');
    } finally {
      setLoadingMore(false);
    }
  };

  const pickFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    if (!OK_TYPES.includes(f.type)) {
      showToast('Sirf jpg, png, webp ya gif photo chalegi.', 'err');
      return;
    }
    if (f.size > MAX_BYTES) {
      showToast('Photo 5MB se badi hai. Chhoti photo chuno.', 'err');
      return;
    }
    setFile(f);
    setPreview(URL.createObjectURL(f));
  };

  const clearFile = () => {
    setFile(null);
    setPreview(null);
  };

  const upload = async () => {
    if (!file || uploading) return;
    setUploading(true);
    try {
      const form = new FormData();
      form.append('image', file);
      form.append('caption', caption);
      await api('/api/posts', { method: 'POST', form });
      clearFile();
      setCaption('');
      showToast('Post upload ho gayi!');
      await loadFeed();
    } catch (e) {
      showToast(errText(e), 'err');
    } finally {
      setUploading(false);
    }
  };

  const saveEdit = async (id: number) => {
    setBusyId(id);
    try {
      await api(`/api/posts/${id}`, { method: 'PUT', body: { caption: editText } });
      setEditingId(null);
      showToast('Caption update ho gaya.');
      await loadFeed();
    } catch (e) {
      showToast(errText(e), 'err');
    } finally {
      setBusyId(null);
    }
  };

  const remove = async (id: number) => {
    setConfirmId(null);
    setBusyId(id);
    try {
      await api(`/api/posts/${id}`, { method: 'DELETE' });
      showToast('Post delete ho gayi.');
      await loadFeed();
    } catch (e) {
      showToast(errText(e), 'err');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] bg-[#F4F6F9] flex justify-center overflow-y-auto">
      <div className="w-full max-w-[430px] min-h-dvh bg-white shadow-2xl pb-10">
        <header className="sticky top-0 z-10 bg-white/95 backdrop-blur-md px-5 h-15 flex items-center gap-3 border-b border-slate-100">
          <button
            type="button"
            onClick={onClose}
            aria-label="Back"
            className="min-h-[40px] min-w-[40px] -ml-2 rounded-full flex items-center justify-center text-[#0F172A] hover:bg-slate-100 transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-lg font-extrabold text-[#0F172A] flex-1">Community Posts</h1>
          <button
            type="button"
            onClick={() => void loadFeed()}
            disabled={loading}
            aria-label="Refresh"
            className="min-h-[40px] min-w-[40px] rounded-full flex items-center justify-center text-slate-600 hover:bg-slate-100 disabled:opacity-40"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </header>

        {toast && (
          <div
            role="status"
            className={`fixed top-4 left-1/2 -translate-x-1/2 z-[70] max-w-[380px] w-[calc(100%-32px)] rounded-2xl px-4 py-3 text-xs font-bold shadow-lg ${
              toast.kind === 'err'
                ? 'bg-rose-50 border border-rose-200 text-rose-800'
                : 'bg-emerald-50 border border-emerald-200 text-emerald-800'
            }`}
          >
            {toast.text}
          </div>
        )}

        <div className="px-5 pt-5 space-y-5">
          {!isApiConfigured() && (
            <div className="rounded-[22px] bg-amber-50 border border-amber-200/80 p-4 text-xs font-semibold text-amber-900 leading-relaxed">
              Backend URL set nahi hai. <code>.env</code> me <code>VITE_API_BASE</code> daalo.
            </div>
          )}

          {/* Upload (members only) */}
          {currentMember ? (
            <div className="rounded-[26px] bg-[#F8FAFC] border border-slate-100 p-4 space-y-3">
              {preview ? (
                <div className="relative rounded-[20px] overflow-hidden bg-white border border-slate-200/80">
                  <img
                    src={preview}
                    alt="Selected preview"
                    className="w-full max-h-[360px] object-contain block"
                  />
                  {!uploading && (
                    <button
                      type="button"
                      onClick={clearFile}
                      aria-label="Remove photo"
                      className="absolute top-2.5 right-2.5 w-9 h-9 rounded-full bg-black/60 text-white flex items-center justify-center"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="w-full h-[150px] rounded-[20px] bg-white border-2 border-dashed border-slate-200 hover:border-[#0F172A]/30 flex flex-col items-center justify-center gap-2 transition-colors"
                >
                  <ImagePlus className="w-7 h-7 text-[#0F172A]" />
                  <span className="text-sm font-bold text-[#0F172A]">Photo chuno</span>
                  <span className="text-[11px] text-slate-400">jpg, png, webp, gif · max 5MB</span>
                </button>
              )}
              <input
                ref={fileRef}
                type="file"
                accept="image/jpeg,image/png,image/webp,image/gif"
                onChange={pickFile}
                className="hidden"
              />
              <textarea
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                disabled={uploading}
                maxLength={500}
                rows={2}
                placeholder="Caption likho... (Optional)"
                className="w-full rounded-[20px] bg-white p-3.5 text-sm text-[#0F172A] placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-[#0F172A]/20 resize-none"
              />
              <button
                type="button"
                onClick={() => void upload()}
                disabled={!file || uploading}
                className="w-full h-12 rounded-full bg-[#0F172A] hover:bg-slate-800 disabled:opacity-40 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all"
              >
                {uploading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Upload ho rahi hai...</span>
                  </>
                ) : (
                  <span>Post Share Karo</span>
                )}
              </button>
            </div>
          ) : (
            <div className="rounded-[26px] bg-[#F8FAFC] border border-slate-100 p-5 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-white shadow-sm flex items-center justify-center mx-auto text-[#0F172A]">
                <Lock className="w-5 h-5" />
              </div>
              <p className="text-sm font-bold text-[#0F172A]">Post upload karne ke liye Sign In karo</p>
              <button
                type="button"
                onClick={onOpenAuth}
                className="h-11 px-6 rounded-full bg-[#0F172A] text-white text-xs font-bold"
              >
                Google se Sign In Karo
              </button>
            </div>
          )}

          {/* Feed */}
          {loading && posts.length === 0 ? (
            <div className="py-12 flex justify-center text-slate-400">
              <RefreshCw className="w-5 h-5 animate-spin" />
            </div>
          ) : posts.length === 0 ? (
            <p className="py-10 text-center text-xs font-medium text-slate-400">
              Abhi koi post nahi hai.
            </p>
          ) : (
            <div className="space-y-5">
              {posts.map((p) => {
                const mine = myUid !== null && p.uid === myUid;
                const canDelete = mine || isAdmin;
                const name = p.user_name || 'Member';
                return (
                  <article
                    key={p.id}
                    className="rounded-[26px] bg-white border border-slate-200/80 shadow-2xs overflow-hidden"
                  >
                    <div className="flex items-center gap-3 p-3.5">
                      <Avatar
                        src={p.user_photo || ''}
                        name={name}
                        sizeClass="w-10 h-10"
                        textSizeClass="text-sm"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-extrabold text-[#0F172A] truncate">{name}</p>
                        <p className="text-[11px] text-slate-400">{formatApiDate(p.created_at)}</p>
                      </div>
                      {(mine || canDelete) && (
                        <div className="flex items-center gap-1">
                          {mine && editingId !== p.id && (
                            <button
                              type="button"
                              disabled={busyId === p.id}
                              onClick={() => {
                                setEditingId(p.id);
                                setEditText(p.caption || '');
                              }}
                              aria-label="Edit caption"
                              className="w-9 h-9 rounded-full text-slate-600 hover:bg-slate-100 flex items-center justify-center"
                            >
                              <Pencil className="w-4 h-4" />
                            </button>
                          )}
                          {canDelete && (
                            <button
                              type="button"
                              disabled={busyId === p.id}
                              onClick={() => setConfirmId(p.id)}
                              aria-label="Delete post"
                              className="w-9 h-9 rounded-full text-rose-600 hover:bg-rose-50 flex items-center justify-center"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      )}
                    </div>

                    <SafeImage src={p.url} alt={p.caption || `Post by ${name}`} autoHeight fit="contain" />

                    {editingId === p.id ? (
                      <div className="p-3.5 space-y-2.5">
                        <textarea
                          value={editText}
                          onChange={(e) => setEditText(e.target.value)}
                          maxLength={500}
                          rows={3}
                          className="w-full rounded-[18px] bg-[#F3F4F6] p-3 text-sm text-[#0F172A] outline-none focus:ring-2 focus:ring-[#0F172A]/20 resize-none"
                        />
                        <div className="flex gap-2">
                          <button
                            type="button"
                            disabled={busyId === p.id}
                            onClick={() => void saveEdit(p.id)}
                            className="h-9 px-4 rounded-full bg-[#0F172A] text-white text-xs font-bold flex items-center gap-1.5 disabled:opacity-40"
                          >
                            <Check className="w-3.5 h-3.5" /> Save
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingId(null)}
                            className="h-9 px-4 rounded-full bg-slate-100 text-slate-700 text-xs font-bold"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      p.caption && (
                        <p className="p-3.5 text-sm text-[#0F172A] leading-relaxed whitespace-pre-wrap break-words">
                          {p.caption}
                        </p>
                      )
                    )}
                  </article>
                );
              })}

              {hasMore && (
                <button
                  type="button"
                  onClick={() => void loadMore()}
                  disabled={loadingMore}
                  className="w-full h-12 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {loadingMore && <RefreshCw className="w-4 h-4 animate-spin" />}
                  Aur dikhao
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {confirmId !== null && (
        <div className="fixed inset-0 z-[70] bg-black/60 flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-[28px] bg-white p-6 shadow-2xl space-y-4">
            <div className="text-center">
              <h3 className="text-lg font-black text-[#0F172A]">Post delete karein?</h3>
              <p className="mt-2 text-xs text-slate-600">Ye wapas nahi aayegi.</p>
            </div>
            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={() => setConfirmId(null)}
                className="flex-1 h-11 rounded-full bg-slate-100 text-slate-700 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void remove(confirmId)}
                className="flex-1 h-11 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
// ===== ADDED: POSTS FEATURE END =====
