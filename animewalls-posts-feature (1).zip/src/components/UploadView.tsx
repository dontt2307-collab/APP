import React, { useEffect, useRef, useState } from 'react';
import {
  Briefcase,
  Camera,
  FileText,
  ImagePlus,
  Info,
  KeyRound,
  Lock,
  RefreshCw,
  Settings,
  X,
} from 'lucide-react';
import { onlyAdminCanPostJobs, NAV_JOB_LABEL, UPLOAD_INFO_HINT, postVisibleDays } from '../config';

import { isQuotaExceededError } from '../firebase';
import {
  cleanImgbbKey,
  ImgbbUploadError,
  prependMemberImgbbKey,
  uploadImageWithFallback,
  verifyImgbbKey,
} from '../services/imgbbService';
import {
  createPostAtomic,
  DAILY_POST_LIMIT,
  getTodayPostCount,
} from '../services/postService';
import { AuthModalMode, PostCategory, PostItem, UserProfile } from '../types';
import { CompressedImageResult, compressImageFile } from '../utils/imageCompress';

interface UploadViewProps {
  currentMember: UserProfile | null;
  viewerName?: string | null;
  isAdmin?: boolean;
  defaultCategory?: PostCategory;
  onOpenAuth: (mode: AuthModalMode) => void;
  onOpenSettings: () => void;
  onPostCreated: (newPost: PostItem, updatedMember: UserProfile) => void;
}

export const UploadView: React.FC<UploadViewProps> = ({
  currentMember,
  viewerName,
  isAdmin = false,
  defaultCategory = 'general',
  onOpenAuth,
  onOpenSettings,
  onPostCreated,
}) => {
  const initialCategory: PostCategory =
    defaultCategory === 'sarkari_naukri' ? 'sarkari_naukri' : 'general';

  const [category, setCategory] = useState<PostCategory>(initialCategory);
  const [compressed, setCompressed] = useState<CompressedImageResult | null>(null);
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [todayCount, setTodayCount] = useState<number | null>(null);
  const [stepLabel, setStepLabel] = useState<string | null>(null);
  const [progressPct, setProgressPct] = useState<number>(0);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [failureType, setFailureType] = useState<'NONE' | 'KEYS' | 'NETWORK'>('NONE');
  const [inlineKeyInput, setInlineKeyInput] = useState('');

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (defaultCategory === 'sarkari_naukri') {
      if (!onlyAdminCanPostJobs || isAdmin) {
        setCategory('sarkari_naukri');
      } else {
        setCategory('general');
      }
    } else {
      setCategory('general');
    }
  }, [defaultCategory, isAdmin]);

  useEffect(() => {
    if (!currentMember) return;
    let active = true;
    (async () => {
      try {
        const res = await getTodayPostCount(currentMember.uid);
        if (active) setTodayCount(res.count);
      } catch {
        // Non-blocking
      }
    })();
    return () => {
      active = false;
    };
  }, [currentMember]);

  if (!currentMember) {
    return (
      <div className="min-h-dvh pb-24 bg-white px-7 pt-10 flex flex-col justify-center">
        <div className="rounded-[28px] bg-[#F8FAFC] border border-slate-100 p-7 text-center space-y-5">
          <div className="w-16 h-16 rounded-full bg-white shadow-sm flex items-center justify-center mx-auto text-[#0F172A]">
            <Lock className="w-7 h-7" />
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-[#0F172A]">Google se Sign In karo</h1>
            <p className="mt-2 text-sm text-slate-500 leading-relaxed">
              {viewerName
                ? `Hi ${viewerName}! Sirf registered members hi nayi photo post upload kar sakte hain.`
                : 'Nayi Normal ya Sarkari Naukri post upload karne ke liye Google se Member Sign In karo.'}
            </p>
          </div>
          <div className="space-y-3 pt-1">
            <button
              type="button"
              onClick={() => onOpenAuth('login')}
              className="w-full h-14 rounded-full bg-[#0F172A] hover:bg-slate-800 text-white text-[15px] font-bold shadow-[0_10px_25px_rgba(15,23,42,0.14)] transition-all"
            >
              Google se Sign In Karo
            </button>
            {!viewerName && (
              <button
                type="button"
                onClick={() => onOpenAuth('viewer')}
                className="w-full h-11 rounded-full text-slate-600 text-xs font-bold hover:bg-slate-100 transition-colors"
              >
                Bina account ke, sirf naam se aao
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  const isDailyLimitReached = !isAdmin && (todayCount ?? 0) >= DAILY_POST_LIMIT;
  const isJobPostingBlocked = onlyAdminCanPostJobs && !isAdmin;

  const handleSelectFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    setFailureType('NONE');
    setUploadedImageUrl(null);
    setStepLabel('Photo resize aur compress ho rahi hai...');
    setProgressPct(25);
    try {
      const result = await compressImageFile(file);
      setCompressed(result);
      setStepLabel(null);
      setProgressPct(0);
    } catch (err) {
      setStepLabel(null);
      setProgressPct(0);
      setError(err instanceof Error ? err.message : 'Photo process nahi ho paayi.');
    }
  };

  const runUploadFlow = async () => {
    if (!compressed) {
      setError('Pehle ek photo select karo.');
      return;
    }
    if (isDailyLimitReached) {
      setError(
        'Aaj ki 20 posts ki daily limit poori ho gayi hai (India time ke hisaab se). Kal raat 12 baje ke baad nayi post daal sakte ho.'
      );
      return;
    }
    if (category === 'sarkari_naukri' && isJobPostingBlocked) {
      setError('Sarkari Naukri post sirf admin dal sakte hain.');
      return;
    }

    setError(null);
    setFailureType('NONE');
    setUploading(true);

    try {
      setStepLabel('Daily limit check ho rahi hai...');
      setProgressPct(20);
      const latestQuota = await getTodayPostCount(currentMember.uid);
      setTodayCount(latestQuota.count);

      if (!isAdmin && latestQuota.count >= DAILY_POST_LIMIT) {
        throw new Error('DAILY_LIMIT_REACHED');
      }

      let hostedImageUrl = uploadedImageUrl;
      if (!hostedImageUrl) {
        setStepLabel('ImgBB par photo upload ho rahi hai...');
        setProgressPct(60);
        hostedImageUrl = await uploadImageWithFallback(
          compressed.base64Payload,
          currentMember.uid,
          (postVisibleDays + 1) * 86400
        );
        setUploadedImageUrl(hostedImageUrl);
      }

      setStepLabel('Post save ho rahi hai...');
      setProgressPct(90);
      const createdPost = await createPostAtomic({
        member: currentMember,
        category,
        caption,
        imageUrl: hostedImageUrl,
      });

      setProgressPct(100);
      setStepLabel(null);
      setCompressed(null);
      setUploadedImageUrl(null);
      setCaption('');
      setInlineKeyInput('');

      const updatedMember: UserProfile = {
        ...currentMember,
        postCount: currentMember.postCount + 1,
      };
      onPostCreated(createdPost, updatedMember);
    } catch (err) {
      setStepLabel(null);
      setProgressPct(0);

      if (err instanceof ImgbbUploadError) {
        setError(err.message);
        setFailureType(err.kind === 'ALL_KEYS_FAILED' ? 'KEYS' : 'NETWORK');
      } else if (err instanceof Error && err.message.includes('DAILY_LIMIT_REACHED')) {
        setTodayCount(DAILY_POST_LIMIT);
        setError(
          'Aaj ki 20 posts ki daily limit poori ho gayi hai (India time ke hisaab se). Kal raat 12 baje ke baad nayi post daal sakte ho.'
        );
      } else if (err instanceof Error && err.message.includes('ONLY_ADMIN_CAN_POST_JOBS')) {
        setError('Sarkari Naukri post upload karne ki permission sirf admin ke paas hai.');
      } else if (isQuotaExceededError(err)) {
        setError('Aaj ka Firebase database quota poora ho gaya hai. Kal reset hone ke baad try karo.');
      } else {
        setError('Post save karne me dikkat aayi. Ek baar Retry dabao.');
        setFailureType('NETWORK');
      }
    } finally {
      setUploading(false);
    }
  };

  const handleSaveInlineKeyAndUpload = async () => {
    const cleaned = cleanImgbbKey(inlineKeyInput);
    if (!cleaned) {
      setError(
        'Sahi ImgBB API key paste karo (https://api.imgbb.com par "Get API key" se copy karo).'
      );
      setFailureType('KEYS');
      return;
    }

    setUploading(true);
    setStepLabel('ImgBB API key verify ho rahi hai...');
    setProgressPct(15);
    try {
      const check = await verifyImgbbKey(cleaned);
      if (!check.valid) {
        setStepLabel(null);
        setProgressPct(0);
        setUploading(false);
        setError(check.message);
        setFailureType('KEYS');
        return;
      }

      await prependMemberImgbbKey(currentMember.uid, cleaned);
      setInlineKeyInput('');
    } catch (err) {
      setStepLabel(null);
      setProgressPct(0);
      setUploading(false);
      setError(err instanceof Error ? err.message : 'Key save nahi ho paayi.');
      setFailureType('KEYS');
      return;
    }

    void runUploadFlow();
  };

  return (
    <div className="min-h-dvh pb-28 bg-white px-5 pt-4">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-100">
        <div>
          <h1 className="text-xl font-extrabold text-[#0F172A] tracking-tight">
            Nayi Post Upload Karo
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Category chuno aur photo share karo
          </p>
        </div>
        {todayCount !== null && (
          <span className="text-xs font-semibold text-slate-500 tabular-nums">
            Aaj: {todayCount}/{DAILY_POST_LIMIT}
          </span>
        )}
      </div>

      {/* Calm 2-Day Visibility Hint matching Profile Strip */}
      <div className="mt-3.5 rounded-2xl bg-slate-50 border border-slate-200/90 px-3.5 py-3 flex items-center gap-2.5 text-xs text-slate-700 font-semibold shadow-xs">
        <Info className="w-4 h-4 text-slate-500 shrink-0" />
        <p className="leading-snug">{UPLOAD_INFO_HINT}</p>
      </div>

      {/* Category Selector Chips: Normal post vs Sarkari Naukri */}
      <div className="mt-4 mb-5">

        <p className="text-xs font-bold text-slate-600 mb-2">
          Post ki Category
        </p>
        <div className="grid grid-cols-2 gap-2.5 p-1.5 rounded-full bg-[#F3F4F6]">
          {/* Chip 1: Normal post */}
          <button
            type="button"
            disabled={uploading}
            onClick={() => setCategory('general')}
            className={`h-11 rounded-full text-xs font-bold flex items-center justify-center gap-2 transition-all ${
              category === 'general'
                ? 'bg-[#0F172A] text-white shadow-sm'
                : 'text-slate-600 hover:text-[#0F172A]'
            }`}
          >
            <FileText className="w-4 h-4 shrink-0" />
            <span>Normal post</span>
          </button>

          {/* Chip 2: Sarkari Naukri */}
          <button
            type="button"
            disabled={uploading || isJobPostingBlocked}
            onClick={() => {
              if (!isJobPostingBlocked) {
                setCategory('sarkari_naukri');
              }
            }}
            className={`h-11 rounded-full text-xs font-bold flex items-center justify-center gap-2 transition-all ${
              isJobPostingBlocked ? 'opacity-40 cursor-not-allowed' : ''
            } ${
              category === 'sarkari_naukri'
                ? 'bg-[#0F172A] text-white shadow-sm'
                : 'text-slate-600 hover:text-[#0F172A]'
            }`}
          >
            <Briefcase className="w-4 h-4 shrink-0" />
            <span>{NAV_JOB_LABEL}</span>
          </button>
        </div>
        {isJobPostingBlocked ? (
          <p className="mt-1.5 px-2 text-[11px] font-medium text-amber-700">
            Sarkari Naukri post sirf Admin post kar sakta hai.
          </p>
        ) : (
          <p className="mt-1.5 px-2 text-[11px] font-medium text-slate-500">
            {category === 'sarkari_naukri'
              ? `Yeh post "${NAV_JOB_LABEL}" tab me dikhegi.`
              : 'Yeh post Home feed aur Search me dikhegi.'}
          </p>
        )}
      </div>

      {isDailyLimitReached && (
        <div className="mb-5 rounded-[22px] bg-amber-50 border border-amber-200/80 p-4 text-xs font-semibold text-amber-900 leading-relaxed">
          Aaj ki 20 posts ki daily limit poori ho chuki hai (India time Asia/Kolkata ke hisaab se).
          Agli post raat 12:00 AM IST ke baad upload kar sakte ho.
        </div>
      )}

      {/* Photo Picker / Preview Card */}
      {!compressed ? (
        <button
          type="button"
          disabled={uploading || isDailyLimitReached}
          onClick={() => fileInputRef.current?.click()}
          className="w-full h-[270px] rounded-[26px] bg-[#F8FAFC] border-2 border-dashed border-slate-200 hover:border-[#0F172A]/30 disabled:opacity-50 flex flex-col items-center justify-center gap-3 transition-colors"
        >
          <div className="w-15 h-15 rounded-full bg-white shadow-sm flex items-center justify-center text-[#0F172A]">
            <ImagePlus className="w-7 h-7" />
          </div>
          <div className="text-center px-4">
            <p className="text-sm font-bold text-[#0F172A]">Gallery se photo chuno</p>
            <p className="text-xs text-slate-400 mt-1">
              Auto compress (max 1080px JPEG) hokar fast upload hogi
            </p>
          </div>
        </button>
      ) : (
        <div className="relative rounded-[26px] overflow-hidden bg-[#F8FAFC] border border-slate-200/80 shadow-xs">
          <img
            src={compressed.previewDataUrl}
            alt="Selected preview"
            className="w-full max-h-[460px] object-contain mx-auto block"
          />
          {!uploading && (
            <div className="absolute top-3 right-3 flex items-center gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                aria-label="Change photo"
                className="h-9 px-3.5 rounded-full bg-white/90 backdrop-blur-md text-xs font-bold text-[#0F172A] shadow-sm flex items-center gap-1.5"
              >
                <Camera className="w-3.5 h-3.5" />
                Badlo
              </button>
              <button
                type="button"
                onClick={() => {
                  setCompressed(null);
                  setUploadedImageUrl(null);
                }}
                aria-label="Remove photo"
                className="w-9 h-9 rounded-full bg-black/60 text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={(e) => void handleSelectFile(e)}
        className="hidden"
      />

      {/* Optional Caption */}
      <div className="mt-5">
        <textarea
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          disabled={uploading}
          placeholder={
            category === 'sarkari_naukri'
              ? 'Vacancy, last date ya details likho... (Optional)'
              : 'Post ke baare me likho... (Optional)'
          }
          rows={3}
          maxLength={500}
          className="w-full rounded-[24px] bg-[#F3F4F6] p-4 text-[15px] text-[#0F172A] placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-[#0F172A]/20 resize-none"
        />
        <p className="text-right text-xs text-slate-400 mt-1 tabular-nums">{caption.length}/500</p>
      </div>

      {/* Progress Bar */}
      {stepLabel && (
        <div className="mt-3 rounded-[20px] bg-slate-100 p-4 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-[#0F172A]">
            <span>{stepLabel}</span>
            <span className="tabular-nums">{progressPct}%</span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden">
            <div
              className="h-full bg-[#0F172A] transition-all duration-200"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>
      )}

      {/* Error + Inline Key Save / Retry Actions */}
      {error && (
        <div className="mt-4 rounded-[22px] bg-rose-50 border border-rose-100 p-4 space-y-3">
          <p className="text-xs font-semibold text-rose-800 leading-relaxed">{error}</p>

          {failureType === 'KEYS' && (
            <div className="space-y-2.5 pt-1">
              <div className="flex items-center gap-2.5 bg-white rounded-full h-11 px-4 border border-rose-200">
                <KeyRound className="w-4 h-4 text-slate-400 shrink-0" />
                <input
                  type="text"
                  autoComplete="off"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                  disabled={uploading}
                  value={inlineKeyInput}
                  onChange={(e) => setInlineKeyInput(e.target.value)}
                  placeholder="Yahan ImgBB API key paste karo..."
                  className="w-full bg-transparent text-xs font-medium text-[#0F172A] placeholder:text-slate-400 outline-none"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  disabled={uploading || !inlineKeyInput.trim()}
                  onClick={() => void handleSaveInlineKeyAndUpload()}
                  className="h-9 px-4 rounded-full bg-[#0F172A] text-white text-xs font-bold disabled:opacity-40"
                >
                  Key Save Karo & Dobara Upload Karo
                </button>
                <button
                  type="button"
                  disabled={uploading}
                  onClick={onOpenSettings}
                  className="h-9 px-3.5 rounded-full bg-white border border-slate-200 text-xs font-bold text-slate-700 flex items-center gap-1.5"
                >
                  <Settings className="w-3.5 h-3.5" />
                  Settings me jao
                </button>
              </div>
            </div>
          )}

          {failureType === 'NETWORK' && (
            <div className="pt-1">
              <button
                type="button"
                disabled={uploading}
                onClick={() => void runUploadFlow()}
                className="h-9 px-4 rounded-full bg-[#0F172A] text-white text-xs font-bold flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Dobara Try Karo
              </button>
            </div>
          )}
        </div>
      )}

      {/* Main Submit Button */}
      <div className="mt-6">
        <button
          type="button"
          disabled={!compressed || uploading || isDailyLimitReached}
          onClick={() => void runUploadFlow()}
          className="w-full h-14 rounded-full bg-[#0F172A] hover:bg-slate-800 disabled:opacity-40 text-white font-bold text-base shadow-[0_10px_25px_rgba(15,23,42,0.18)] transition-all flex items-center justify-center gap-2"
        >
          {uploading ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin" />
              <span>Upload ho rahi hai...</span>
            </>
          ) : (
            <span>Post Share Karo</span>
          )}
        </button>
      </div>
    </div>
  );
};
