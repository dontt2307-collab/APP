import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Bell,
  Briefcase,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Clock,
  Download,
  Edit2,
  ExternalLink,
  FileSpreadsheet,
  Filter,
  Flag,
  LayoutDashboard,
  MessageSquare,
  RefreshCw,
  Search,
  Send,
  ShieldAlert,
  Sparkles,
  TrendingUp,
  Trash,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
  X,
} from 'lucide-react';

import {
  CleanupSummary,
  createNotification,
  deleteNotification,
  deletePostAndReportsBatch,
  dismissReportsBatch,
  downloadAllNamesCSV,
  downloadMembersCSV,
  fetchAllMembersForAdmin,
  fetchMemberOverdueDetails,
  fetchNameViewersData,
  fetchNotificationsPage,
  fetchOverviewStats,
  fetchReportsPage,
  removeMemberAtomic,
  runAdminCleanup,
  updateNotification,
} from '../services/adminService';

import { AdminActivityStats, fetchAdminActivityStats } from '../services/budgetService';
import { AdminTabId, NameViewerRecord, NotificationItem, ReportItem, UserProfile } from '../types';
import { formatISTTimestamp } from '../utils/istDate';
import { Avatar } from './Avatar';
// ===== ADDED: POSTS FEATURE START =====
import { AdminPostsUsers } from './AdminPostsUsers';
// ===== ADDED: POSTS FEATURE END =====
import { SafeImage } from './SafeImage';

interface AdminDashboardProps {
  onClose: () => void;
  onLogout?: () => void;
  initialTab?: AdminTabId;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onClose,
  onLogout,
  initialTab = 'overview',
}) => {
  const [activeTab, setActiveTab] = useState<AdminTabId>(initialTab);

  // Data states
  const [stats, setStats] = useState<any>(null);
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [members, setMembers] = useState<UserProfile[]>([]);

  // Activity stats state
  const [activityDayOffset, setActivityDayOffset] = useState<0 | 1>(0);
  const [activityStats, setActivityStats] = useState<AdminActivityStats | null>(null);

  // Name Viewers states
  const [nameViewersList, setNameViewersList] = useState<NameViewerRecord[]>([]);
  const [nameViewersStats, setNameViewersStats] = useState<{ totalCount: number; todayCount: number }>({
    totalCount: 0,
    todayCount: 0,
  });
  const [nameViewerSearchQuery, setNameViewerSearchQuery] = useState('');

  // Search filter state for members
  const [searchQuery, setSearchQuery] = useState('');

  // Overdue post info cached per member { [uid]: { overdueCount, oldestAgeDays, loaded } }
  const [memberOverdueMap, setMemberOverdueMap] = useState<
    Record<string, { overdueCount: number; oldestAgeDays: number; loading?: boolean }>
  >({});
  const [expandedMemberUid, setExpandedMemberUid] = useState<string | null>(null);

  const [lastDoc, setLastDoc] = useState<any>(null);
  const [hasMore, setHasMore] = useState(false);

  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Dialogs
  const [confirmDialog, setConfirmDialog] = useState<{
    title: string;
    message: string;
    confirmLabel?: string;
    isDanger?: boolean;
    onConfirm: () => Promise<void>;
  } | null>(null);

  const [cleanupRunning, setCleanupRunning] = useState(false);
  const [cleanupSummary, setCleanupSummary] = useState<CleanupSummary | null>(null);

  // Notification form states
  const [editingNotif, setEditingNotif] = useState<NotificationItem | null>(null);
  const [notifForm, setNotifForm] = useState({ title: '', body: '', to: 'all' });
  const [removingUid, setRemovingUid] = useState<string | null>(null);
  const [deleteMemberPosts, setDeleteMemberPosts] = useState(true);

  const loadData = async (isLoadMore = false) => {
    if (isLoadMore) setLoadingMore(true);
    else setLoading(true);
    setError(null);
    try {
      if (activeTab === 'overview') {
        const [overviewData, actStats] = await Promise.all([
          fetchOverviewStats(),
          fetchAdminActivityStats(activityDayOffset),
        ]);
        setStats(overviewData);
        setActivityStats(actStats);
      } else if (activeTab === 'reports') {
        const res = await fetchReportsPage(isLoadMore ? lastDoc : null);
        if (res) {
          setReports((prev) => (isLoadMore ? [...prev, ...res.reports] : res.reports));
          setLastDoc(res.lastDoc);
          setHasMore(res.hasMore);
        }
      } else if (activeTab === 'notifications') {
        const res = await fetchNotificationsPage(isLoadMore ? lastDoc : null);
        if (res) {
          setNotifications((prev) =>
            isLoadMore ? [...prev, ...res.notifications] : res.notifications
          );
          setLastDoc(res.lastDoc);
          setHasMore(res.hasMore);
        }
      } else if (activeTab === 'members') {
        const data = await fetchAllMembersForAdmin();
        setMembers(data || []);
      } else if (activeTab === 'nameManagement') {
        const data = await fetchNameViewersData();
        setNameViewersList(data.viewers || []);
        setNameViewersStats({ totalCount: data.totalCount, todayCount: data.todayCount });
      }
    } catch {
      setError('Data load nahi ho paaya.');
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  useEffect(() => {
    setLastDoc(null);
    setHasMore(false);
    void loadData();
  }, [activeTab, activityDayOffset]);

  // Load member overdue details lazily to save reads
  const handleToggleMemberExpand = async (uid: string) => {
    if (expandedMemberUid === uid) {
      setExpandedMemberUid(null);
      return;
    }
    setExpandedMemberUid(uid);

    if (!memberOverdueMap[uid]) {
      setMemberOverdueMap((prev) => ({
        ...prev,
        [uid]: { overdueCount: 0, oldestAgeDays: 0, loading: true },
      }));
      const details = await fetchMemberOverdueDetails(uid);
      setMemberOverdueMap((prev) => ({
        ...prev,
        [uid]: { ...details, loading: false },
      }));
    }
  };

  // Run manual "Purani posts saaf karo" action
  const handleTriggerCleanup = () => {
    setConfirmDialog({
      title: 'Purani Posts Saaf Karein?',
      message:
        '2 din se purani sabhi posts permanently delete ho jayengi aur members ka post count update ho jayega. Koi notification ya warning nahi bheji jayegi.',
      confirmLabel: 'Posts Saaf Karo',
      isDanger: false,
      onConfirm: async () => {
        setCleanupRunning(true);
        try {
          const summary = await runAdminCleanup();
          setCleanupSummary(summary);
          setActionSuccess('Purani posts saaf kar di gayi hain!');
          void loadData();
        } catch {
          setError('Purani posts saaf karne me dikkat aayi.');
        } finally {
          setCleanupRunning(false);
        }
      },
    });
  };

  const handleNotifSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifForm.title.trim() || !notifForm.body.trim()) return;
    setLoading(true);
    setError(null);
    try {
      if (editingNotif) {
        await updateNotification(
          editingNotif.id,
          notifForm.title,
          notifForm.body,
          notifForm.to
        );
      } else {
        await createNotification(notifForm.title, notifForm.body, notifForm.to);
      }
      setNotifForm({ title: '', body: '', to: 'all' });
      setEditingNotif(null);
      setActionSuccess('Notification save ho gaya.');
      setTimeout(() => setActionSuccess(null), 3000);
      void loadData();
    } catch {
      setError('Notification save karne me error aaya.');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteNotif = (id: string) => {
    setConfirmDialog({
      title: 'Notification Delete',
      message: 'Yeh notification permanent delete karein?',
      confirmLabel: 'Delete',
      isDanger: true,
      onConfirm: async () => {
        setLoading(true);
        setError(null);
        try {
          await deleteNotification(id);
          setActionSuccess('Notification delete ho gaya.');
          setTimeout(() => setActionSuccess(null), 3000);
          void loadData();
        } catch {
          setError('Delete karne me error aaya.');
        } finally {
          setLoading(false);
        }
      },
    });
  };

  const handleRemoveMember = () => {
    if (!removingUid) return;
    const targetUid = removingUid;
    const targetMember = members.find((m) => m.uid === targetUid);
    setConfirmDialog({
      title: 'Member Remove (Hatao)',
      message: `Kya aap sach me ${targetMember?.fullName || targetMember?.userName || 'is member'} ko remove karna chahte hain? Slot free ho jayega.${
        deleteMemberPosts ? ' (Iske saare posts bhi delete ho jayenge)' : ''
      }`,
      confirmLabel: 'Remove Member',
      isDanger: true,
      onConfirm: async () => {
        setLoading(true);
        setError(null);
        try {
          await removeMemberAtomic(targetUid, deleteMemberPosts);
          setRemovingUid(null);
          setActionSuccess('Member successfully remove ho gaya aur slot free ho gaya.');
          setTimeout(() => setActionSuccess(null), 3000);
          void loadData();
        } catch {
          setError('Member remove karne me error aaya.');
        } finally {
          setLoading(false);
        }
      },
    });
  };

  const handleDeletePostByReport = (report: ReportItem) => {
    setConfirmDialog({
      title: 'Reported Post Delete',
      message: 'Is post ko delete karein? Owner ka postCount -1 hoga aur reports bhi saaf hongi.',
      confirmLabel: 'Delete Post',
      isDanger: true,
      onConfirm: async () => {
        setLoading(true);
        setError(null);
        try {
          await deletePostAndReportsBatch(report.postId, report.postOwnerUid);
          setActionSuccess('Post delete ho gayi.');
          setTimeout(() => setActionSuccess(null), 3000);
          void loadData();
        } catch {
          setError('Post delete karne me error aaya.');
        } finally {
          setLoading(false);
        }
      },
    });
  };

  const handleDismissReports = (postId: string) => {
    setConfirmDialog({
      title: 'Reports Dismiss',
      message: 'Post rakhein aur iske sabhi reports dismiss karein?',
      confirmLabel: 'Dismiss',
      isDanger: false,
      onConfirm: async () => {
        setLoading(true);
        setError(null);
        try {
          await dismissReportsBatch(postId);
          setActionSuccess('Reports dismiss ho gayi.');
          setTimeout(() => setActionSuccess(null), 3000);
          void loadData();
        } catch {
          setError('Dismiss karne me error aaya.');
        } finally {
          setLoading(false);
        }
      },
    });
  };

  // Header back navigation logic
  const handleHeaderBack = () => {
    if (activeTab !== 'overview') {
      setActiveTab('overview');
    } else {
      onClose();
    }
  };

  const getHeaderTitle = () => {
    switch (activeTab) {
      case 'members':
        return 'Members Management';
      case 'notifications':
        return 'Notifications Center';
      case 'reports':
        return 'Member Reports';
      case 'nameManagement':
        return 'Name Users Management';
      default:
        return 'Admin Analytics & Dashboard';
    }
  };

  const filteredMembers = members.filter((m) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      (m.fullName && m.fullName.toLowerCase().includes(q)) ||
      (m.userName && m.userName.toLowerCase().includes(q))
    );
  });

  const filteredNameViewers = nameViewersList.filter((v) => {
    const q = nameViewerSearchQuery.toLowerCase().trim();
    if (!q) return true;
    return v.name && v.name.toLowerCase().includes(q);
  });

  const memberCountNum = stats?.memberCount ?? members.length;
  const pendingReportsNum = stats?.pendingReports ?? reports.length;
  const totalPostsNum = stats?.totalPosts ?? 0;
  const postsTodayNum = stats?.postsToday ?? 0;
  const nameTotalNum = stats?.nameViewersTotal ?? nameViewersStats.totalCount;
  const nameTodayNum = stats?.nameViewersToday ?? nameViewersStats.todayCount;

  return (
    <div className="fixed inset-0 z-50 bg-[#F4F6F9] overflow-y-auto flex justify-center selection:bg-rose-100 selection:text-rose-900">
      <div className="w-full max-w-[430px] min-h-dvh bg-[#F8FAFC] pb-24 shadow-2xl relative flex flex-col font-sans">
        {/* Sociafy Style Top Header */}
        <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md px-4 h-16 flex items-center justify-between border-b border-slate-200/80 shadow-2xs">
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              type="button"
              onClick={handleHeaderBack}
              className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center shrink-0 transition-all hover:scale-105 active:scale-95"
              title={activeTab !== 'overview' ? 'Back to Overview' : 'Close Dashboard'}
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="min-w-0">
              <h1 className="text-sm font-extrabold text-[#0F172A] tracking-tight truncate leading-tight">
                {getHeaderTitle()}
              </h1>
              <p className="text-[10px] font-medium text-slate-400 truncate">
                Business Media Platform
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={cleanupRunning}
              onClick={handleTriggerCleanup}
              className="h-8 px-3 rounded-full bg-gradient-to-r from-orange-500 via-rose-500 to-amber-500 hover:opacity-95 text-white text-[11px] font-black flex items-center gap-1 shadow-sm shadow-orange-500/20 transition-all active:scale-95 whitespace-nowrap"
            >
              <Sparkles className="w-3.5 h-3.5 animate-pulse" />
              <span>Posts Saaf</span>
            </button>
            <button
              type="button"
              onClick={() => void loadData()}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-all active:scale-95"
              title="Refresh Analytics"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-rose-500' : ''}`} />
            </button>
          </div>
        </header>

        {/* Success & Error alerts */}
        {actionSuccess && (
          <div className="mx-4 mt-3 rounded-2xl bg-emerald-50 border border-emerald-200/80 p-3 text-xs font-bold text-emerald-800 flex items-center gap-2 shadow-2xs">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span>{actionSuccess}</span>
          </div>
        )}
        {error && (
          <div className="mx-4 mt-3 rounded-2xl bg-rose-50 border border-rose-200/80 p-3 text-xs font-bold text-rose-800 flex items-center gap-2 shadow-2xs">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Overview Page View */}
        {activeTab === 'overview' && (
          <div className="p-4 space-y-4">
            {/* Top Title Kicker (Sociafy Header Banner) */}
            <div className="flex items-center justify-between pt-1">
              <div>
                <h2 className="text-base font-black text-[#0F172A] tracking-tight">
                  Platform Analytics Overview
                </h2>
                <p className="text-[11px] font-medium text-slate-500">
                  Track performance, members, and content status
                </p>
              </div>
              <button
                type="button"
                onClick={() => downloadMembersCSV(members)}
                className="h-8 px-3 rounded-xl bg-white border border-slate-200 hover:border-slate-300 text-slate-700 text-[11px] font-extrabold flex items-center gap-1.5 shadow-2xs transition-all hover:shadow-xs"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                <span>Export CSV</span>
              </button>
            </div>

            {/* Sociafy 4-KPI Metric Cards Grid */}
            <div className="grid grid-cols-2 gap-3">
              {/* Card 1: Total Members */}
              <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between">
                <div className="flex items-start justify-between">
                  <span className="text-[11px] font-extrabold text-slate-500 uppercase tracking-wider">
                    Total Members
                  </span>
                  <div className="w-8 h-8 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center shrink-0">
                    <Users className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-black text-[#0F172A] tabular-nums tracking-tight">
                      {memberCountNum}
                    </span>
                    <span className="text-xs font-bold text-slate-400">/ 20</span>
                  </div>
                  <div className="mt-1 flex items-center gap-1">
                    <span className="inline-flex items-center px-1.5 py-0.5 rounded-md text-[10px] font-bold bg-emerald-50 text-emerald-600">
                      <TrendingUp className="w-2.5 h-2.5 mr-0.5" /> {20 - memberCountNum} slots free
                    </span>
                  </div>
                </div>
              </div>

              {/* Card 2: Total Posts */}
              <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between">
                <div className="flex items-start justify-between">
                  <span className="text-[11px] font-extrabold text-slate-500 uppercase tracking-wider">
                    Total Posts
                  </span>
                  <div className="w-8 h-8 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-black text-[#0F172A] tabular-nums tracking-tight">
                      {totalPostsNum}
                    </span>
                  </div>
                  <div className="mt-1 flex items-center gap-1">
                    <span className="inline-flex items-center px-1.5 py-0.5 rounded-md text-[10px] font-bold bg-blue-50 text-blue-600">
                      Live Firestore
                    </span>
                  </div>
                </div>
              </div>

              {/* Card 3: Posts Today */}
              <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between">
                <div className="flex items-start justify-between">
                  <span className="text-[11px] font-extrabold text-slate-500 uppercase tracking-wider">
                    Posts Today
                  </span>
                  <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                    <Clock className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-black text-[#0F172A] tabular-nums tracking-tight">
                      {postsTodayNum}
                    </span>
                  </div>
                  <div className="mt-1 flex items-center gap-1">
                    <span className="inline-flex items-center px-1.5 py-0.5 rounded-md text-[10px] font-bold bg-emerald-50 text-emerald-600">
                      IST Calendar
                    </span>
                  </div>
                </div>
              </div>

              {/* Card 4: Pending Reports */}
              <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between">
                <div className="flex items-start justify-between">
                  <span className="text-[11px] font-extrabold text-slate-500 uppercase tracking-wider">
                    Member Reports
                  </span>
                  <div className="w-8 h-8 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                    <Flag className="w-4 h-4" />
                  </div>
                </div>
                <div className="mt-2">
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-black text-rose-600 tabular-nums tracking-tight">
                      {pendingReportsNum}
                    </span>
                  </div>
                  <div className="mt-1 flex items-center gap-1">
                    <span
                      className={`inline-flex items-center px-1.5 py-0.5 rounded-md text-[10px] font-bold ${
                        pendingReportsNum > 0
                          ? 'bg-rose-50 text-rose-600'
                          : 'bg-slate-100 text-slate-500'
                      }`}
                    >
                      {pendingReportsNum > 0 ? 'Action Needed' : 'All Clear'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Aaj ki Activity Card */}
            <div className="p-4 rounded-[24px] bg-white border border-slate-200/80 shadow-2xs space-y-3.5">
              {/* Header with Title, Day Toggle & Refresh */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-purple-600" />
                  <h3 className="text-sm font-black text-[#0F172A]">
                    {activityDayOffset === 0 ? 'Aaj ki Activity' : 'Kal ki Activity'}
                  </h3>
                </div>

                <div className="flex items-center gap-1.5">
                  <div className="flex items-center bg-slate-100 p-0.5 rounded-full text-[11px] font-bold">
                    <button
                      type="button"
                      onClick={() => setActivityDayOffset(0)}
                      className={`px-2.5 py-1 rounded-full transition-all ${
                        activityDayOffset === 0
                          ? 'bg-[#0F172A] text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Aaj
                    </button>
                    <button
                      type="button"
                      onClick={() => setActivityDayOffset(1)}
                      className={`px-2.5 py-1 rounded-full transition-all ${
                        activityDayOffset === 1
                          ? 'bg-[#0F172A] text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Kal
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => void loadData()}
                    className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-all"
                    title="Refresh Activity Stats"
                  >
                    <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin text-purple-600' : ''}`} />
                  </button>
                </div>
              </div>

              {/* 4 Activity Metrics Grid */}
              <div className="grid grid-cols-2 gap-2.5">
                <div className="p-3 rounded-2xl bg-purple-50/60 border border-purple-100/80">
                  <span className="text-[10px] font-bold text-purple-700 block">Name-wale Viewers</span>
                  <span className="text-xl font-black text-[#0F172A] tabular-nums">
                    {activityStats?.viewersWithNames ?? 0}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
                  <span className="text-[10px] font-bold text-slate-500 block">Guests (bina naam)</span>
                  <span className="text-xl font-black text-[#0F172A] tabular-nums">
                    {activityStats?.guests ?? 0}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-emerald-50/60 border border-emerald-100/80">
                  <span className="text-[10px] font-bold text-emerald-700 block">Active Members</span>
                  <span className="text-xl font-black text-[#0F172A] tabular-nums">
                    {activityStats?.activeMembers ?? 0}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-indigo-50/60 border border-indigo-100/80">
                  <span className="text-[10px] font-bold text-indigo-700 block">TOTAL Active</span>
                  <span className="text-xl font-black text-[#0F172A] tabular-nums">
                    {activityStats?.totalActive ?? 0}
                  </span>
                </div>
              </div>

              {/* Limit Completed & Total Reads Meter */}
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-700">Limit Pura Parne Wale Viewers</span>
                  <span className="font-black text-rose-600 tabular-nums">
                    {activityStats?.limitHitCount ?? 0} viewers
                  </span>
                </div>

                <div className="pt-1 space-y-1">
                  <div className="flex items-center justify-between text-[11px] font-bold">
                    <span className="text-slate-600">Viewers Pool Reads</span>
                    <span className="text-[#0F172A] tabular-nums">
                      {(activityStats?.totalReadsServed ?? 0).toLocaleString()} / {(activityStats?.viewerPoolReads ?? 36000).toLocaleString()}
                    </span>
                  </div>
                  {(() => {
                    const pool = activityStats?.viewerPoolReads || 36000;
                    const served = activityStats?.totalReadsServed || 0;
                    const pct = Math.min(100, Math.round((served / pool) * 100));
                    const isHigh = pct >= 80;

                    return (
                      <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${
                            isHigh
                              ? 'bg-gradient-to-r from-amber-500 to-rose-500'
                              : 'bg-gradient-to-r from-indigo-500 to-purple-500'
                          }`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    );
                  })()}
                </div>
              </div>

              {/* Total Names Saved & Quick Link */}
              <div className="flex items-center justify-between pt-1 text-xs">
                <span className="font-semibold text-slate-500">
                  Total Names Saved: <strong className="text-[#0F172A] font-extrabold">{activityStats?.totalNamesSaved ?? nameViewersStats.totalCount}</strong>
                </span>
                <button
                  type="button"
                  onClick={() => setActiveTab('nameManagement')}
                  className="font-bold text-purple-600 hover:text-purple-800 transition-colors flex items-center gap-1"
                >
                  <span>Name List →</span>
                </button>
              </div>
            </div>

            {/* Sociafy Promo Banner: Purani Posts Saaf Karo */}
            <div className="rounded-[28px] bg-gradient-to-br from-orange-500 via-rose-500 to-amber-500 p-4 text-white shadow-md shadow-orange-500/15 relative overflow-hidden">
              <div className="relative z-10 flex items-center justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 mb-1">
                    <Sparkles className="w-4 h-4 text-amber-200" />
                    <span className="text-[10px] font-black uppercase tracking-wider text-amber-100">
                      Manual Cleanup Action
                    </span>
                  </div>
                  <h3 className="text-sm font-black tracking-tight text-white">
                    Purani Posts Saaf Karo
                  </h3>
                  <p className="text-[11px] text-white/90 mt-0.5 leading-snug">
                    2 din se purani sabhi posts database se saaf karein. No automatic notifications.
                  </p>
                </div>
                <button
                  type="button"
                  disabled={cleanupRunning}
                  onClick={handleTriggerCleanup}
                  className="px-4 py-2.5 rounded-full bg-white text-[#0F172A] text-xs font-black shadow-sm hover:bg-amber-50 transition-all shrink-0 active:scale-95 whitespace-nowrap"
                >
                  {cleanupRunning ? 'Running...' : 'Posts Saaf Karo'}
                </button>
              </div>
            </div>

            {/* Member Capacity Progress Indicator */}
            <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-2xs space-y-2">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-[#0F172A]">Member Slots Capacity</span>
                <span className="text-slate-500 tabular-nums">
                  {memberCountNum} / 20 ({Math.round((memberCountNum / 20) * 100)}%)
                </span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-slate-100 overflow-hidden p-0.5">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-rose-500 transition-all duration-500"
                  style={{ width: `${Math.min(100, (memberCountNum / 20) * 100)}%` }}
                />
              </div>
            </div>

            {/* Sociafy Style "More Options" Menu Grid */}
            <div className="space-y-3 pt-1">
              <h4 className="text-[#0F172A] text-xs font-black uppercase tracking-wider px-1">
                More Options & Tools
              </h4>
              <div className="space-y-2.5">
                {/* Option 1: Members Management */}
                <button
                  type="button"
                  onClick={() => setActiveTab('members')}
                  className="w-full p-3.5 rounded-2xl bg-white border border-slate-200/80 hover:border-slate-300 shadow-2xs hover:shadow-xs transition-all flex items-center justify-between text-left group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 text-[#0F172A] group-hover:bg-[#0F172A] group-hover:text-white transition-colors flex items-center justify-center shrink-0">
                      <Users className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-[#0F172A] truncate">
                          Members Management
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-slate-100 text-[10px] font-bold text-slate-600">
                          {memberCountNum}/20
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium truncate mt-0.5">
                        Registered members list, overdue posts & slot release
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors shrink-0 ml-2" />
                </button>

                {/* Option 2: Name Users Management (NEW) */}
                <button
                  type="button"
                  onClick={() => setActiveTab('nameManagement')}
                  className="w-full p-3.5 rounded-2xl bg-white border border-slate-200/80 hover:border-slate-300 shadow-2xs hover:shadow-xs transition-all flex items-center justify-between text-left group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-colors flex items-center justify-center shrink-0">
                      <UserCheck className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-[#0F172A] truncate">
                          Name Management
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-purple-50 text-[10px] font-bold text-purple-700">
                          {nameTotalNum} total &middot; +{nameTodayNum} today
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium truncate mt-0.5">
                        Name users total, today joins & download all names CSV
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors shrink-0 ml-2" />
                </button>

                {/* Option 3: Notifications */}
                <button
                  type="button"
                  onClick={() => setActiveTab('notifications')}
                  className="w-full p-3.5 rounded-2xl bg-white border border-slate-200/80 hover:border-slate-300 shadow-2xs hover:shadow-xs transition-all flex items-center justify-between text-left group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors flex items-center justify-center shrink-0">
                      <Bell className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <span className="text-xs font-black text-[#0F172A] block truncate">
                        Notifications Center
                      </span>
                      <p className="text-[11px] text-slate-500 font-medium truncate mt-0.5">
                        Send broadcast or targeted member messages
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors shrink-0 ml-2" />
                </button>

                {/* Option 4: Member Reports */}
                <button
                  type="button"
                  onClick={() => setActiveTab('reports')}
                  className="w-full p-3.5 rounded-2xl bg-white border border-slate-200/80 hover:border-slate-300 shadow-2xs hover:shadow-xs transition-all flex items-center justify-between text-left group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 group-hover:bg-rose-600 group-hover:text-white transition-colors flex items-center justify-center shrink-0">
                      <Flag className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-[#0F172A] truncate">
                          Member Reports
                        </span>
                        {pendingReportsNum > 0 && (
                          <span className="px-2 py-0.5 rounded-full bg-rose-100 text-[10px] font-bold text-rose-700">
                            {pendingReportsNum} pending
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium truncate mt-0.5">
                        Moderate reported posts and dismiss spam
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors shrink-0 ml-2" />
                </button>

                {/* ===== ADDED: POSTS FEATURE START ===== */}
                <button
                  type="button"
                  onClick={() => setActiveTab('postsUsers')}
                  className="w-full p-3.5 rounded-2xl bg-white border border-slate-200/80 hover:border-slate-300 shadow-2xs hover:shadow-xs transition-all flex items-center justify-between text-left group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors flex items-center justify-center shrink-0">
                      <Users className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <span className="text-xs font-black text-[#0F172A] truncate block">
                        Posts & Users
                      </span>
                      <p className="text-[11px] text-slate-500 font-medium truncate mt-0.5">
                        Community posts delete, users ban / unban
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors shrink-0 ml-2" />
                </button>
                {/* ===== ADDED: POSTS FEATURE END ===== */}
              </div>
            </div>

            {/* System Info Box */}
            <div className="p-4 rounded-2xl bg-slate-100/70 border border-slate-200/60 space-y-2 mt-4 text-xs">
              <h4 className="font-extrabold text-[#0F172A]">System Architecture Info</h4>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                Posts visible days: <strong className="text-slate-900">2 din</strong>.
                Firestore TTL policy: <strong className="text-slate-900">posts.expireAt (7 din)</strong>.
                Name-only viewers Google Sheet & Firestore sync me record hote hain.
              </p>
            </div>
          </div>
        )}

        {/* Tab: Name Management (NEW) */}
        {activeTab === 'nameManagement' && (
          <div className="p-4 space-y-4">
            <button
              type="button"
              onClick={() => setActiveTab('overview')}
              className="inline-flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-[#0F172A] transition-colors mb-1"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Back to Overview</span>
            </button>

            {/* Top Stats Cards & Title */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-[#0F172A]">
                    Name Users Management
                  </h3>
                  <p className="text-[11px] text-slate-500 font-medium">
                    Name-only viewers analytics and complete records
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => downloadAllNamesCSV(nameViewersList)}
                  className="h-9 px-3.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-black flex items-center gap-1.5 shadow-sm shadow-purple-200 transition-all active:scale-95"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download All Names</span>
                </button>
              </div>

              {/* 2 Metric Cards */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
                  <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                    Total Name Users
                  </span>
                  <p className="text-2xl font-black text-[#0F172A] tabular-nums mt-1">
                    {nameViewersStats.totalCount}
                  </p>
                  <span className="text-[10px] font-bold text-purple-600 mt-0.5 block">
                    Recorded Viewers
                  </span>
                </div>

                <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
                  <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                    Today New Users
                  </span>
                  <p className="text-2xl font-black text-emerald-600 tabular-nums mt-1">
                    +{nameViewersStats.todayCount}
                  </p>
                  <span className="text-[10px] font-bold text-emerald-600 mt-0.5 block">
                    Joined Today IST
                  </span>
                </div>
              </div>

              {/* Search input for Name Users */}
              <div className="relative pt-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-4" />
                <input
                  type="text"
                  value={nameViewerSearchQuery}
                  onChange={(e) => setNameViewerSearchQuery(e.target.value)}
                  placeholder="Naam search karein..."
                  className="w-full h-10 pl-9 pr-3 rounded-xl bg-white border border-slate-200 text-xs font-semibold text-slate-800 outline-none focus:ring-2 focus:ring-[#0F172A]/20"
                />
              </div>
            </div>

            {/* List of Name Users */}
            <div className="space-y-2">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-black text-[#0F172A]">
                  Recorded Name Users ({filteredNameViewers.length})
                </span>
                <button
                  type="button"
                  onClick={() => downloadAllNamesCSV(nameViewersList)}
                  className="text-xs font-extrabold text-purple-600 hover:text-purple-800 flex items-center gap-1"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>CSV Download</span>
                </button>
              </div>

              {filteredNameViewers.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-2xl border border-slate-200/80">
                  <p className="text-xs text-slate-400 font-medium">
                    {nameViewerSearchQuery ? 'Koi matching name nahi mila.' : 'Abhi koi name user data nahi hai.'}
                  </p>
                </div>
              ) : (
                <div className="bg-white rounded-2xl border border-slate-200/80 overflow-hidden divide-y divide-slate-100 shadow-2xs">
                  {filteredNameViewers.map((item, index) => (
                    <div key={item.id || index} className="p-3 flex items-center justify-between gap-3 hover:bg-slate-50/80 transition-colors">
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="w-6 h-6 rounded-lg bg-slate-100 text-slate-500 text-[11px] font-bold flex items-center justify-center shrink-0 tabular-nums">
                          {index + 1}
                        </span>
                        <div className="min-w-0">
                          <span className="text-xs font-extrabold text-[#0F172A] truncate block">
                            {item.name}
                          </span>
                          <span className="text-[10px] text-slate-400 block tabular-nums">
                            {formatISTTimestamp(item.createdAt)}
                          </span>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-extrabold shrink-0">
                        Viewer
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Members Sub-page */}
        {activeTab === 'members' && (
          <div className="p-4 space-y-4">
            <button
              type="button"
              onClick={() => setActiveTab('overview')}
              className="inline-flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-[#0F172A] transition-colors mb-1"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Back to Overview</span>
            </button>

            {/* Top search & title */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-[#0F172A]">
                    Registered Members ({members.length}/20)
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Tap member to view overdue post metrics
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => downloadMembersCSV(members)}
                  className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1 shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>CSV</span>
                </button>
              </div>

              {/* Search Bar */}
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Member naam ya username search karein..."
                  className="w-full h-10 pl-9 pr-3 rounded-xl bg-white border border-slate-200 text-xs font-semibold text-slate-800 outline-none focus:ring-2 focus:ring-[#0F172A]/20"
                />
              </div>
            </div>

            {/* Members List */}
            <div className="space-y-2.5">
              {filteredMembers.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-2xl border border-slate-200/80">
                  <p className="text-xs text-slate-400 font-medium">Koi member nahi mila.</p>
                </div>
              ) : (
                filteredMembers.map((m) => {
                  const isExpanded = expandedMemberUid === m.uid;
                  const overdueInfo = memberOverdueMap[m.uid];

                  return (
                    <div
                      key={m.uid}
                      className="rounded-2xl border transition-all p-3.5 bg-white border-slate-200/80 shadow-2xs hover:shadow-xs"
                    >
                      <div
                        className="flex items-center justify-between gap-3 cursor-pointer"
                        onClick={() => void handleToggleMemberExpand(m.uid)}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <Avatar
                            src={m.dpUrl}
                            name={m.fullName || m.userName}
                            sizeClass="w-10 h-10"
                            textSizeClass="text-xs"
                          />
                          <div className="min-w-0">
                            <span className="text-xs font-black text-[#0F172A] truncate block">
                              {m.fullName || m.userName}
                            </span>
                            <p className="text-[11px] text-slate-500 truncate">
                              @{m.userName} &middot; {m.postCount ?? 0} posts
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setRemovingUid(m.uid);
                              setDeleteMemberPosts(true);
                            }}
                            className="py-1 px-3 rounded-full text-xs font-bold bg-rose-50 hover:bg-rose-100 text-rose-600 transition-colors"
                          >
                            Hatao
                          </button>
                          {isExpanded ? (
                            <ChevronUp className="w-4 h-4 text-slate-400" />
                          ) : (
                            <ChevronDown className="w-4 h-4 text-slate-400" />
                          )}
                        </div>
                      </div>

                      {/* Expanded details */}
                      {isExpanded && (
                        <div className="mt-3 pt-3 border-t border-slate-100 space-y-2 text-xs">
                          <div className="grid grid-cols-2 gap-2 text-[11px]">
                            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                              <span className="text-slate-400 block font-semibold">Overdue posts (&gt;2 din)</span>
                              <span className="text-sm font-black text-[#0F172A] tabular-nums">
                                {overdueInfo?.loading
                                  ? 'Loading...'
                                  : overdueInfo?.overdueCount ?? 0}
                              </span>
                            </div>
                            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                              <span className="text-slate-400 block font-semibold">Oldest overdue age</span>
                              <span className="text-sm font-black text-[#0F172A] tabular-nums">
                                {overdueInfo?.loading
                                  ? 'Loading...'
                                  : (overdueInfo?.oldestAgeDays ?? 0) > 0
                                  ? `${overdueInfo?.oldestAgeDays} din`
                                  : '0 din'}
                              </span>
                            </div>
                          </div>

                          <div className="pt-1">
                            <button
                              type="button"
                              onClick={() => {
                                setRemovingUid(m.uid);
                                setDeleteMemberPosts(true);
                              }}
                              className="w-full py-2.5 px-4 rounded-xl text-xs font-black bg-rose-600 hover:bg-rose-700 text-white shadow-sm shadow-rose-200 transition-colors"
                            >
                              Member Hatao (Free 1 Slot)
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Tab 3: Targeted Notifications Sub-page */}
        {activeTab === 'notifications' && (
          <div className="p-4 space-y-5">
            <button
              type="button"
              onClick={() => setActiveTab('overview')}
              className="inline-flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-[#0F172A] transition-colors mb-1"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Back to Overview</span>
            </button>

            {/* Create/Edit Form */}
            <form
              onSubmit={handleNotifSubmit}
              className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-2xs space-y-3"
            >
              <h3 className="text-xs font-black text-[#0F172A]">
                {editingNotif ? 'Notification Edit Karo' : 'Nayi Notification Bhejo'}
              </h3>

              {/* Recipient Selector */}
              <div>
                <label className="text-[11px] font-bold text-slate-600 block mb-1">
                  Kisko bhejna hai?
                </label>
                <select
                  value={notifForm.to}
                  onChange={(e) => setNotifForm({ ...notifForm, to: e.target.value })}
                  className="w-full h-10 px-3 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 outline-none focus:ring-2 focus:ring-[#0F172A]/20"
                >
                  <option value="all">Sabko (Broadcast)</option>
                  {members.map((m) => (
                    <option key={m.uid} value={m.uid}>
                      {m.fullName || m.userName} (@{m.userName})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <input
                  type="text"
                  required
                  value={notifForm.title}
                  onChange={(e) => setNotifForm({ ...notifForm, title: e.target.value })}
                  placeholder="Notification title..."
                  className="w-full h-10 px-3 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 outline-none focus:ring-2 focus:ring-[#0F172A]/20"
                />
              </div>

              <div>
                <textarea
                  required
                  rows={2}
                  value={notifForm.body}
                  onChange={(e) => setNotifForm({ ...notifForm, body: e.target.value })}
                  placeholder="Message body..."
                  className="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 outline-none focus:ring-2 focus:ring-[#0F172A]/20 resize-none"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 h-10 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{editingNotif ? 'Update Karo' : 'Send Karo'}</span>
                </button>
                {editingNotif && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingNotif(null);
                      setNotifForm({ title: '', body: '', to: 'all' });
                    }}
                    className="h-10 px-4 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold"
                  >
                    Cancel
                  </button>
                )}
              </div>
            </form>

            {/* Notifications List */}
            <div className="space-y-3">
              <h4 className="text-xs font-black text-[#0F172A]">Bheji Gayi Notifications</h4>
              {notifications.length === 0 ? (
                <p className="text-xs text-slate-400">Koi notification nahi mili.</p>
              ) : (
                notifications.map((n) => {
                  const targetMember = members.find((m) => m.uid === n.to);
                  const recipientLabel =
                    n.to === 'all' || !n.to
                      ? 'Sabko'
                      : targetMember
                      ? `@${targetMember.userName}`
                      : n.to;

                  return (
                    <div
                      key={n.id}
                      className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs space-y-1.5"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h5 className="text-xs font-black text-[#0F172A]">{n.title}</h5>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              n.to === 'all' || !n.to
                                ? 'bg-blue-50 text-blue-700'
                                : 'bg-purple-50 text-purple-700'
                            }`}
                          >
                            To: {recipientLabel}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingNotif(n);
                              setNotifForm({ title: n.title, body: n.body, to: n.to || 'all' });
                            }}
                            className="w-7 h-7 rounded-lg hover:bg-slate-100 text-slate-600 flex items-center justify-center"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteNotif(n.id)}
                            className="w-7 h-7 rounded-lg hover:bg-rose-50 text-rose-600 flex items-center justify-center"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">{n.body}</p>
                      <span className="text-[10px] text-slate-400 block tabular-nums">
                        {formatISTTimestamp(n.createdAt)}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* ===== ADDED: POSTS FEATURE START ===== */}
        {activeTab === 'postsUsers' && <AdminPostsUsers onBack={() => setActiveTab('overview')} />}
        {/* ===== ADDED: POSTS FEATURE END ===== */}

        {/* Tab 4: Member Reports Sub-page */}
        {activeTab === 'reports' && (
          <div className="p-4 space-y-4">
            <button
              type="button"
              onClick={() => setActiveTab('overview')}
              className="inline-flex items-center gap-1 text-xs font-bold text-slate-600 hover:text-[#0F172A] transition-colors mb-1"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Back to Overview</span>
            </button>

            <h3 className="text-xs font-black text-[#0F172A]">
              Member Reports ({reports.length})
            </h3>
            {reports.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-2xl border border-slate-200/80">
                <p className="text-xs text-slate-400 font-medium">Abhi koi pending report nahi hai.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {reports.map((r) => (
                  <div
                    key={r.id}
                    className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs space-y-2.5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-black text-rose-600 uppercase tracking-wider">
                          Reason: {r.reason}
                        </span>
                        <p className="text-xs font-bold text-slate-800 mt-0.5">
                          Reported: {r.postOwnerName} ki post
                        </p>
                        <p className="text-[11px] text-slate-400">
                          Reporter: {r.reporterName} &middot; {formatISTTimestamp(r.createdAt)}
                        </p>
                      </div>
                    </div>

                    {r.postImageUrl && (
                      <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-100 max-h-36">
                        <SafeImage
                          src={r.postImageUrl}
                          alt="Reported post"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}

                    {r.postCaption && (
                      <p className="text-xs text-slate-600 line-clamp-2 italic">
                        "{r.postCaption}"
                      </p>
                    )}

                    <div className="flex gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => handleDeletePostByReport(r)}
                        className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center justify-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete Post</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDismissReports(r.postId)}
                        className="flex-1 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold"
                      >
                        Dismiss Report
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Summary Dialog after Cleanup */}
        {cleanupSummary && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="w-full max-w-sm rounded-[28px] bg-white p-6 shadow-2xl space-y-4">
              <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto">
                <Sparkles className="w-6 h-6" />
              </div>
              <div className="text-center">
                <h3 className="text-lg font-black text-[#0F172A]">Purani Posts Saaf</h3>
                <p className="mt-1 text-xs text-slate-500">
                  2 din se purani posts safalta se delete kar di gayi hain.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Posts delete hui:</span>
                  <strong className="text-rose-600 tabular-nums">{cleanupSummary.postsDeleted}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Members prabhavit:</span>
                  <strong className="text-slate-900 tabular-nums">{cleanupSummary.affectedMembersCount}</strong>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setCleanupSummary(null)}
                className="w-full h-11 rounded-full bg-[#0F172A] text-white text-xs font-bold"
              >
                Theek Hai (Close)
              </button>
            </div>
          </div>
        )}

        {/* Member Remove Modal */}
        {removingUid && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="w-full max-w-sm rounded-[28px] bg-white p-6 shadow-2xl space-y-4">
              <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <div className="text-center">
                <h3 className="text-lg font-black text-[#0F172A]">Member Remove Karein?</h3>
                <p className="mt-1 text-xs text-slate-500 leading-relaxed">
                  Member account permanently hat jayega aur registration slot (1/20) free ho jayega.
                </p>
              </div>

              <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={deleteMemberPosts}
                  onChange={(e) => setDeleteMemberPosts(e.target.checked)}
                  className="rounded text-[#0F172A]"
                />
                <span className="text-xs font-bold text-slate-700">
                  Is member ki saari posts bhi delete karein
                </span>
              </label>

              <div className="flex gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setRemovingUid(null)}
                  className="flex-1 h-11 rounded-full bg-slate-100 text-slate-700 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleRemoveMember}
                  className="flex-1 h-11 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md shadow-rose-200"
                >
                  Remove Member
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Generic Confirm Dialog */}
        {confirmDialog && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="w-full max-w-sm rounded-[28px] bg-white p-6 shadow-2xl space-y-4">
              <div className="text-center">
                <h3 className="text-lg font-black text-[#0F172A]">{confirmDialog.title}</h3>
                <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                  {confirmDialog.message}
                </p>
              </div>
              <div className="flex gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setConfirmDialog(null)}
                  className="flex-1 h-11 rounded-full bg-slate-100 text-slate-700 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    const fn = confirmDialog.onConfirm;
                    setConfirmDialog(null);
                    await fn();
                  }}
                  className={`flex-1 h-11 rounded-full text-xs font-bold ${
                    confirmDialog.isDanger
                      ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-md shadow-rose-200'
                      : 'bg-[#0F172A] hover:bg-slate-800 text-white'
                  }`}
                >
                  {confirmDialog.confirmLabel || 'Confirm'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
