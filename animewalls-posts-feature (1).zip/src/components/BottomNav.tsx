import React from 'react';
import { Briefcase, Home, Plus, Search, User } from 'lucide-react';
import { NAV_JOB_LABEL } from '../config';
import { TabId } from '../types';

interface BottomNavProps {
  activeTab: TabId;
  onSelectTab: (tab: TabId) => void;
  hideUpload?: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  hideUpload = false,
}) => {
  return (
    <nav
      aria-label="Bottom navigation"
      className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] h-[68px] z-30 bg-white/95 backdrop-blur-md border-t border-slate-100 px-2 flex items-center justify-between select-none"
    >
      {/* 1. Home */}
      <button
        type="button"
        onClick={() => onSelectTab('home')}
        className={`flex-1 min-h-[48px] flex flex-col items-center justify-center gap-1 transition-colors ${
          activeTab === 'home' ? 'text-[#0F172A]' : 'text-slate-400 hover:text-slate-600'
        }`}
      >
        <Home className="w-[22px] h-[22px]" strokeWidth={activeTab === 'home' ? 2.5 : 1.9} />
        <span className={`text-[10px] leading-none whitespace-nowrap ${activeTab === 'home' ? 'font-bold' : 'font-medium'}`}>
          Home
        </span>
      </button>

      {/* 2. Sarkari Naukri (Briefcase Icon) */}
      <button
        type="button"
        onClick={() => onSelectTab('sarkari')}
        className={`flex-1 min-h-[48px] flex flex-col items-center justify-center gap-1 transition-colors ${
          activeTab === 'sarkari' ? 'text-[#0F172A]' : 'text-slate-400 hover:text-slate-600'
        }`}
      >
        <Briefcase className="w-[21px] h-[21px]" strokeWidth={activeTab === 'sarkari' ? 2.5 : 1.9} />
        <span className={`text-[9.5px] tracking-tight leading-none whitespace-nowrap ${activeTab === 'sarkari' ? 'font-bold' : 'font-medium'}`}>
          {NAV_JOB_LABEL}
        </span>
      </button>

      {/* 3. Center Raised "+" Upload Button (Hidden for Name-only Viewers) */}
      {!hideUpload && (
        <div className="flex-1 flex items-center justify-center">
          <button
            type="button"
            aria-label="Upload post"
            onClick={() => onSelectTab('upload')}
            className={`-mt-4 w-13 h-13 rounded-full bg-[#0F172A] text-white shadow-[0_10px_24px_rgba(15,23,42,0.28)] flex items-center justify-center active:scale-95 transition-transform ${
              activeTab === 'upload' ? 'ring-4 ring-slate-200' : ''
            }`}
          >
            <Plus className="w-6 h-6" strokeWidth={2.5} />
          </button>
        </div>
      )}

      {/* 4. Search */}
      <button
        type="button"
        onClick={() => onSelectTab('search')}
        className={`flex-1 min-h-[48px] flex flex-col items-center justify-center gap-1 transition-colors ${
          activeTab === 'search' ? 'text-[#0F172A]' : 'text-slate-400 hover:text-slate-600'
        }`}
      >
        <Search className="w-[22px] h-[22px]" strokeWidth={activeTab === 'search' ? 2.5 : 1.9} />
        <span className={`text-[10px] leading-none whitespace-nowrap ${activeTab === 'search' ? 'font-bold' : 'font-medium'}`}>
          Search
        </span>
      </button>

      {/* 5. Profile */}
      <button
        type="button"
        onClick={() => onSelectTab('profile')}
        className={`flex-1 min-h-[48px] flex flex-col items-center justify-center gap-1 transition-colors ${
          activeTab === 'profile' ? 'text-[#0F172A]' : 'text-slate-400 hover:text-slate-600'
        }`}
      >
        <User className="w-[22px] h-[22px]" strokeWidth={activeTab === 'profile' ? 2.5 : 1.9} />
        <span className={`text-[10px] leading-none whitespace-nowrap ${activeTab === 'profile' ? 'font-bold' : 'font-medium'}`}>
          Profile
        </span>
      </button>
    </nav>
  );
};
