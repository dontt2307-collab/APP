import React from 'react';
import { Clock, Sparkles } from 'lucide-react';
import { LIMIT_EXCEEDED_SUBTITLE, LIMIT_EXCEEDED_TITLE } from '../config';

interface LimitExceededCardProps {
  isInline?: boolean; // True when shown inline at bottom of scrolling feed
}

export const LimitExceededCard: React.FC<LimitExceededCardProps> = ({ isInline = false }) => {
  if (isInline) {
    return (
      <div className="my-6 p-5 rounded-[24px] bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white text-center shadow-lg border border-slate-700/60 space-y-2 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-rose-500/10 rounded-full blur-xl pointer-events-none" />
        <div className="w-10 h-10 rounded-2xl bg-white/10 text-amber-300 flex items-center justify-center mx-auto backdrop-blur-xs">
          <Clock className="w-5 h-5" />
        </div>
        <h3 className="text-sm font-extrabold tracking-tight text-white">
          {LIMIT_EXCEEDED_TITLE}
        </h3>
        <p className="text-xs text-slate-300 max-w-xs mx-auto leading-relaxed">
          {LIMIT_EXCEEDED_SUBTITLE}
        </p>
      </div>
    );
  }

  return (
    <div className="my-8 px-4 flex justify-center">
      <div className="w-full max-w-sm rounded-[28px] bg-white border border-slate-200/80 p-6 text-center shadow-xl shadow-slate-200/50 space-y-3 relative overflow-hidden">
        <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto shadow-2xs">
          <Sparkles className="w-6 h-6 animate-pulse" />
        </div>
        <div className="space-y-1">
          <h3 className="text-base font-black text-[#0F172A] tracking-tight">
            {LIMIT_EXCEEDED_TITLE}
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed font-medium">
            {LIMIT_EXCEEDED_SUBTITLE}
          </p>
        </div>
        <div className="pt-2">
          <span className="inline-flex items-center px-3 py-1 rounded-full text-[11px] font-bold bg-slate-100 text-slate-600">
            Daily Free Quota Completed
          </span>
        </div>
      </div>
    </div>
  );
};
