import React, { useEffect, useState } from 'react';
import { getImgbbProxyFallbackUrl } from '../services/imgbbService';

interface AvatarProps {
  src?: string;
  name: string;
  sizeClass?: string;
  textSizeClass?: string;
  ringClass?: string;
}

const AVATAR_GRADIENTS = [
  'from-sky-500 to-indigo-600',
  'from-amber-500 to-rose-500',
  'from-emerald-500 to-teal-600',
  'from-violet-500 to-fuchsia-600',
  'from-slate-700 to-slate-900',
];

function pickGradient(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
  }
  return AVATAR_GRADIENTS[hash % AVATAR_GRADIENTS.length];
}

export const Avatar: React.FC<AvatarProps> = ({
  src,
  name,
  sizeClass = 'w-10 h-10',
  textSizeClass = 'text-sm',
  ringClass = '',
}) => {
  const cleanSrc = (src || '').trim();
  const [effectiveSrc, setEffectiveSrc] = useState(cleanSrc);
  const [stage, setStage] = useState<0 | 1 | 2>(0);
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    setEffectiveSrc(cleanSrc);
    setStage(0);
    setImgError(false);
  }, [cleanSrc]);

  useEffect(() => {
    if (!imgError || !cleanSrc) return;
    const onReconnect = () => {
      setEffectiveSrc(cleanSrc);
      setStage(0);
      setImgError(false);
    };
    window.addEventListener('online', onReconnect);
    return () => window.removeEventListener('online', onReconnect);
  }, [imgError, cleanSrc]);

  const handleError = () => {
    if (stage === 0 && cleanSrc) {
      const proxyUrl = getImgbbProxyFallbackUrl(cleanSrc);
      if (proxyUrl) {
        setStage(1);
        setEffectiveSrc(proxyUrl);
        return;
      }
    }
    if (stage < 2 && cleanSrc.startsWith('https://')) {
      setStage(2);
      const sep = cleanSrc.includes('?') ? '&' : '?';
      setEffectiveSrc(`${cleanSrc}${sep}_r=${Date.now()}`);
      return;
    }
    setImgError(true);
  };

  const initial = (name?.trim()?.[0] || 'B').toUpperCase();

  if (effectiveSrc && !imgError) {
    return (
      <div
        className={`relative rounded-full overflow-hidden bg-slate-200 shrink-0 select-none ${sizeClass} ${ringClass}`}
      >
        <img
          src={effectiveSrc}
          alt={name}
          referrerPolicy="no-referrer"
          decoding="async"
          loading="eager"
          onError={handleError}
          className="w-full h-full object-cover object-center block"
        />
      </div>
    );
  }

  return (
    <div
      className={`rounded-full bg-gradient-to-br ${pickGradient(
        name || 'BM'
      )} text-white font-bold flex items-center justify-center shrink-0 select-none ${sizeClass} ${textSizeClass} ${ringClass}`}
      aria-label={name}
    >
      {initial}
    </div>
  );
};
