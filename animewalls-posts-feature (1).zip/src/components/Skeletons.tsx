import React from 'react';

const Shimmer = () => (
  <div className="absolute inset-0 -translate-x-full animate-[shimmer_2s_infinite] bg-gradient-to-r from-transparent via-white/50 to-transparent" />
);

export const FeedSkeleton: React.FC = () => (
  <div className="space-y-5 px-5 pt-2 pb-6">
    {[0, 1, 2].map((i) => (
      <div
        key={i}
        className="w-full h-[340px] rounded-[26px] bg-slate-200 relative overflow-hidden p-5 flex flex-col justify-end"
      >
        <Shimmer />
        <div className="flex items-center gap-3 mb-2.5">
          <div className="w-9 h-9 rounded-full bg-slate-300" />
          <div className="h-4 w-28 rounded-full bg-slate-300" />
        </div>
        <div className="h-3.5 w-3/4 rounded-full bg-slate-300" />
      </div>
    ))}
  </div>
);

export const GridSkeleton: React.FC = () => (
  <div className="grid grid-cols-2 gap-3.5 px-5 py-2">
    {[0, 1, 2, 3, 4, 5].map((i) => (
      <div
        key={i}
        className="aspect-[4/5] rounded-[22px] bg-slate-200 relative overflow-hidden"
      >
        <Shimmer />
      </div>
    ))}
  </div>
);

export const ProfileHeaderSkeleton: React.FC = () => (
  <div className="px-6 pt-6 pb-4 flex flex-col items-center">
    <div className="w-24 h-24 rounded-full bg-slate-200 mb-4 relative overflow-hidden"><Shimmer /></div>
    <div className="h-6 w-36 rounded-full bg-slate-200 mb-2 relative overflow-hidden"><Shimmer /></div>
    <div className="h-4 w-52 rounded-full bg-slate-200 mb-4 relative overflow-hidden"><Shimmer /></div>
    <div className="h-10 w-40 rounded-full bg-slate-200 relative overflow-hidden"><Shimmer /></div>
  </div>
);

