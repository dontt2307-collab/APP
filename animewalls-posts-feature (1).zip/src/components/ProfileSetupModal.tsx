import React, { useRef, useState } from 'react';
import { AtSign, Camera, ChevronLeft, FileText, KeyRound, Trash2, User } from 'lucide-react';
import {
  sanitizeUsernameInput,
  updateMemberProfile,
  USERNAME_PATTERN,
} from '../services/authService';
import {
  cleanImgbbKey,
  ImgbbUploadError,
  prependMemberImgbbKey,
  uploadImageWithFallback,
  verifyImgbbKey,
} from '../services/imgbbService';
import { UserProfile } from '../types';
import { compressImageFile } from '../utils/imageCompress';
import { Avatar } from './Avatar';

interface ProfileSetupModalProps {
  member: UserProfile;
  isInitialSetup?: boolean;
  onSaved: (updated: UserProfile) => void;
  onClose: () => void;
  onOpenSettings: () => void;
}

export const ProfileSetupModal: React.FC<ProfileSetupModalProps> = ({
  member,
  isInitialSetup = false,
  onSaved,
  onClose,
  onOpenSettings,
}) => {
  const [fullName, setFullName] = useState(member.fullName || member.userName);
  const [userName, setUserName] = useState(() => sanitizeUsernameInput(member.userName));
  const [bio, setBio] = useState(member.bio || '');
  const [previewDp, setPreviewDp] = useState<string>(member.dpUrl || '');
  const [pendingBase64, setPendingBase64] = useState<string | null>(null);
  const [dpRemoved, setDpRemoved] = useState(false);
  const [statusText, setStatusText] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [needsKeySetup, setNeedsKeySetup] = useState(false);
  const [inlineKeyInput, setInlineKeyInput] = useState('');
  const [saving, setSaving] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handlePickDp = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    setNeedsKeySetup(false);
    setStatusText('DP compress ho rahi hai...');
    try {
      const compressed = await compressImageFile(file);
      setPreviewDp(compressed.previewDataUrl);
      setPendingBase64(compressed.base64Payload);
      setDpRemoved(false);
      setStatusText(null);
    } catch (err) {
      setStatusText(null);
      setError(err instanceof Error ? err.message : 'Photo select nahi ho paayi.');
    }
  };

  const handleRemoveDp = () => {
    setPreviewDp('');
    setPendingBase64(null);
    setDpRemoved(true);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSave = async (skipPendingDp = false) => {
    setError(null);
    setNeedsKeySetup(false);

    const trimmedName = fullName.trim();
    const cleanedHandle = sanitizeUsernameInput(userName);

    if (trimmedName.length < 2 || trimmedName.length > 50) {
      setError('Naam 2 se 50 characters ke beech rakho.');
      return;
    }

    if (!USERNAME_PATTERN.test(cleanedHandle)) {
      setError('Username me kam se kam 2 small letters (a-z) ya numbers (0-9) likho.');
      return;
    }

    setSaving(true);
    try {
      let finalDpUrl = dpRemoved ? '' : member.dpUrl || '';

      if (pendingBase64 && !skipPendingDp) {
        setStatusText('DP ImgBB par upload ho rahi hai...');
        finalDpUrl = await uploadImageWithFallback(pendingBase64, member.uid);
      }

      setStatusText('Profile save ho raha hai...');
      const updated = await updateMemberProfile({
        current: member,
        fullName: trimmedName,
        userName: cleanedHandle,
        bio,
        dpUrl: finalDpUrl,
      });

      setStatusText(null);
      onSaved(updated);
    } catch (err) {
      setStatusText(null);
      if (err instanceof ImgbbUploadError) {
        setError(err.message);
        if (err.kind === 'ALL_KEYS_FAILED') {
          setNeedsKeySetup(true);
        }
      } else {
        setError(err instanceof Error ? err.message : 'Profile save nahi ho paaya.');
      }
    } finally {
      setSaving(false);
    }
  };

  const handleInlineKeySaveAndRetry = async () => {
    const cleaned = cleanImgbbKey(inlineKeyInput);
    if (!cleaned) {
      setError('Sahi ImgBB API key paste karo (https://api.imgbb.com se copy karo).');
      setNeedsKeySetup(true);
      return;
    }

    setSaving(true);
    setStatusText('ImgBB key verify ho rahi hai...');
    try {
      const check = await verifyImgbbKey(cleaned);
      if (!check.valid) {
        setStatusText(null);
        setSaving(false);
        setError(check.message);
        setNeedsKeySetup(true);
        return;
      }
      await prependMemberImgbbKey(member.uid, cleaned);
      setInlineKeyInput('');
    } catch (err) {
      setStatusText(null);
      setSaving(false);
      setError(err instanceof Error ? err.message : 'Key save nahi ho paayi.');
      setNeedsKeySetup(true);
      return;
    }

    await handleSave(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#F4F6F9] flex justify-center overflow-y-auto">
      <div className="w-full max-w-[430px] min-h-dvh bg-white px-7 pt-5 pb-10 flex flex-col">
        {/* Top Row */}
        <div className="flex items-center justify-between">
          <button
            type="button"
            disabled={saving}
            onClick={onClose}
            aria-label="Back"
            className="min-h-[44px] min-w-[44px] -ml-2 rounded-full flex items-center justify-center text-[#0F172A] hover:bg-slate-100 disabled:opacity-50 transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {isInitialSetup && (
            <button
              type="button"
              disabled={saving}
              onClick={onClose}
              className="min-h-[44px] px-3 text-sm font-semibold text-slate-500 hover:text-[#0F172A]"
            >
              Skip
            </button>
          )}
        </div>

        {/* Header */}
        <div className="text-center mt-2 mb-6">
          <h2 className="text-[28px] font-extrabold text-[#0F172A] tracking-tight">
            {isInitialSetup ? 'Aapki profile' : 'Profile edit karo'}
          </h2>
          <p className="mt-1.5 text-sm text-slate-500">
            Apni DP image, naam, username aur bio update karo
          </p>
        </div>

        {/* Centered Circular DP + Camera Badge */}
        <div className="flex flex-col items-center mb-7">
          <div className="relative">
            <Avatar
              src={previewDp}
              name={fullName || userName || member.userName}
              sizeClass="w-28 h-28"
              textSizeClass="text-3xl"
              ringClass="ring-4 ring-slate-100 shadow-md"
            />
            <button
              type="button"
              disabled={saving}
              onClick={() => fileInputRef.current?.click()}
              aria-label="Choose profile photo"
              className="absolute bottom-0 right-0 w-10 h-10 rounded-full bg-white text-[#0F172A] shadow-md border border-slate-200 flex items-center justify-center hover:bg-slate-50 transition-colors"
            >
              <Camera className="w-5 h-5" />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={(e) => void handlePickDp(e)}
              className="hidden"
            />
          </div>

          <div className="mt-3 flex items-center gap-3">
            <button
              type="button"
              disabled={saving}
              onClick={() => fileInputRef.current?.click()}
              className="text-xs font-bold text-[#0F172A] hover:underline"
            >
              DP photo badlo
            </button>
            {previewDp && (
              <>
                <span className="text-slate-300" aria-hidden="true">
                  &middot;
                </span>
                <button
                  type="button"
                  disabled={saving}
                  onClick={handleRemoveDp}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-rose-600 hover:underline"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>DP hatao</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Rounded Inputs: Name, Username (a-z0-9), Bio */}
        <div className="space-y-4">
          {/* Name */}
          <div>
            <label className="flex items-center gap-3.5 bg-[#F3F4F6] rounded-full h-14 px-5 focus-within:ring-2 focus-within:ring-[#0F172A]/20 transition-shadow">
              <User className="w-5 h-5 text-slate-400 shrink-0" />
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Aapka naam"
                maxLength={50}
                className="w-full bg-transparent text-[15px] text-[#0F172A] placeholder:text-slate-400 outline-none"
              />
            </label>
          </div>

          {/* Username (small letters & numbers only) */}
          <div>
            <label className="flex items-center gap-3 bg-[#F3F4F6] rounded-full h-14 px-5 focus-within:ring-2 focus-within:ring-[#0F172A]/20 transition-shadow">
              <AtSign className="w-5 h-5 text-slate-400 shrink-0" />
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(sanitizeUsernameInput(e.target.value))}
                placeholder="username (a-z aur 0-9)"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                maxLength={30}
                className="w-full bg-transparent text-[15px] font-semibold text-[#0F172A] placeholder:font-normal placeholder:text-slate-400 outline-none"
              />
            </label>
            <p className="mt-1.5 px-3 text-xs text-slate-500">
              Username me sirf small letters (<span className="font-semibold">a-z</span>) aur
              numbers (<span className="font-semibold">0-9</span>) ho sakte hain
            </p>
          </div>

          {/* Bio */}
          <label className="flex items-start gap-3.5 bg-[#F3F4F6] rounded-[24px] py-4 px-5 focus-within:ring-2 focus-within:ring-[#0F172A]/20 transition-shadow">
            <FileText className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Chhota sa bio likho (optional)"
              rows={3}
              maxLength={160}
              className="w-full bg-transparent text-[15px] text-[#0F172A] placeholder:text-slate-400 outline-none resize-none"
            />
          </label>
          <p className="text-right text-xs text-slate-400 tabular-nums">{bio.length}/160</p>
        </div>

        {statusText && (
          <div className="mt-3 rounded-[20px] bg-slate-100 px-4 py-3 text-sm text-slate-700 font-medium text-center">
            {statusText}
          </div>
        )}

        {error && (
          <div className="mt-3 rounded-[20px] bg-rose-50 border border-rose-100 px-4 py-3.5 text-xs text-rose-800 font-semibold space-y-2.5">
            <p className="leading-relaxed">{error}</p>

            {needsKeySetup && (
              <div className="space-y-2 pt-1">
                <div className="flex items-center gap-2 bg-white rounded-full h-11 px-4 border border-rose-200">
                  <KeyRound className="w-4 h-4 text-slate-400 shrink-0" />
                  <input
                    type="text"
                    autoComplete="off"
                    autoCapitalize="none"
                    autoCorrect="off"
                    spellCheck={false}
                    disabled={saving}
                    value={inlineKeyInput}
                    onChange={(e) => setInlineKeyInput(e.target.value)}
                    placeholder="Yahan ImgBB API key paste karo..."
                    className="w-full bg-transparent text-xs font-medium text-[#0F172A] placeholder:text-slate-400 outline-none"
                  />
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    disabled={saving || !inlineKeyInput.trim()}
                    onClick={() => void handleInlineKeySaveAndRetry()}
                    className="px-4 h-9 rounded-full bg-[#0F172A] disabled:opacity-50 text-white text-xs font-bold"
                  >
                    Key Save & DP Upload Karo
                  </button>
                  <button
                    type="button"
                    disabled={saving}
                    onClick={onOpenSettings}
                    className="px-4 h-9 rounded-full bg-white border border-rose-200 text-rose-900 text-xs font-bold"
                  >
                    Settings kholo
                  </button>
                </div>
              </div>
            )}

            {pendingBase64 && (
              <div>
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void handleSave(true)}
                  className="px-4 h-9 rounded-full bg-white border border-rose-200 text-rose-800 text-xs font-bold"
                >
                  Bina nayi DP ke save karo
                </button>
              </div>
            )}
          </div>
        )}

        <div className="mt-7">
          <button
            type="button"
            disabled={saving}
            onClick={() => void handleSave(false)}
            className="w-full h-14 rounded-full bg-[#0F172A] hover:bg-slate-800 disabled:opacity-60 text-white text-[15px] font-bold shadow-[0_10px_25px_rgba(15,23,42,0.14)] transition-all"
          >
            {saving ? 'Save ho raha hai...' : 'Save Profile'}
          </button>
        </div>
      </div>
    </div>
  );
};
