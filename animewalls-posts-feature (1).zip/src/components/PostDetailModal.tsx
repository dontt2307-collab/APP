import React, { useState } from 'react';
import { CheckCircle2, ChevronLeft, Flag, Trash2, X } from 'lucide-react';
import { deletePostAtomic, reportPost } from '../services/postService';
import { deleteAnyPostAtomic } from '../services/adminService';
import { getUserFromMemory } from '../services/userCache';
import { PostItem, UserProfile } from '../types';
import { formatISTTimestamp } from '../utils/istDate';
import { Avatar } from './Avatar';
import { LikeButton } from './LikeButton';
import { ZoomableImage } from './ZoomableImage';

interface PostDetailModalProps {
  post: PostItem;
  currentMember: UserProfile | null;
  isAdmin: boolean;
  onClose: () => void;
  onOpenMemberProfile: (uid: string) => void;
  onPostDeleted: (postId: string) => void;
}

export const PostDetailModal: React.FC<PostDetailModalProps> = ({
  post,
  currentMember,
  isAdmin,
  onClose,
  onOpenMemberProfile,
  onPostDeleted,
}) => {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportReason, setReportReason] = useState('Spam');
  const [reportNote, setReportNote] = useState('');
  const [reportSent, setReportSent] = useState(false);
  const [reportSubmitting, setReportSubmitting] = useState(false);
  const [reportAlreadyDone, setReportAlreadyDone] = useState(false);

  const handleReportSubmit = async () => {
    if (!currentMember) return;
    setReportSubmitting(true);
    setReportAlreadyDone(false);
    try {
      await reportPost({
        post,
        postId: post.id,
        postOwnerUid: post.uid,
        postOwnerName: displayName,
        postImageUrl: post.imageUrl,
        postCaption: post.caption,
        reporter: currentMember,
        reporterUid: currentMember.uid,
        reporterName: currentMember.fullName || currentMember.userName,
        reason: reportReason,
        note: reportNote.trim().slice(0, 200),
      });
      setReportSent(true);
    } catch (err: any) {
      if (err?.message === 'ALREADY_REPORTED') {
        setReportAlreadyDone(true);
      } else {
        setError('Report nahi bhej paayi. Dobara try karo.');
      }
    } finally {
      setReportSubmitting(false);
    }
  };

  const cachedAuthor = getUserFromMemory(post.uid);
  const displayName =
    cachedAuthor?.fullName || post.userFullName || cachedAuthor?.userName || post.userName;
  const displayHandle = cachedAuthor?.userName || post.userName;
  const displayDp = cachedAuthor?.dpUrl || post.userDpUrl;
  const isOwner = Boolean(currentMember && currentMember.uid === post.uid);
  const canDelete = isOwner || isAdmin;

  const handleDelete = async () => {
    if (!currentMember && !isAdmin) return;
    setError(null);
    setDeleting(true);
    try {
      if (isAdmin && (!currentMember || !isOwner)) {
        await deleteAnyPostAtomic(post.id, post.uid);
      } else if (currentMember) {
        await deletePostAtomic(post.id, currentMember);
      }
      onPostDeleted(post.id);
    } catch {
      setError('Post delete nahi ho paayi. Dobara try karo.');
      setDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#F4F6F9] flex justify-center overflow-y-auto">
      <div className="w-full max-w-[430px] min-h-dvh bg-white flex flex-col relative">
        {/* Top Full Uncropped Photo */}
        <div className="relative w-full min-h-[220px] bg-[#0F172A] flex items-center justify-center pt-12 pb-6 px-2">
          <ZoomableImage
            src={post.imageUrl}
            alt={post.caption || `${displayName} ki post`}
            className="w-full bg-transparent"
            imgClassName="max-h-[360px] mx-auto rounded-xl"
            onExpand={() => setIsFullScreen(true)}
          />

          <button
            type="button"
            onClick={onClose}
            aria-label="Back"
            className="absolute top-3 left-3 min-h-[44px] min-w-[44px] rounded-full bg-white/95 backdrop-blur-md text-[#0F172A] shadow-md flex items-center justify-center hover:bg-white transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        </div>

        {/* Rounded Bottom Sheet Card (Step 8 style) */}
        <div className="-mt-6 relative z-10 flex-1 rounded-t-[28px] bg-white px-6 pt-6 pb-10 flex flex-col justify-between shadow-[0_-8px_30px_rgba(15,23,42,0.08)]">
          <div>
            <div className="flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenMemberProfile(post.uid);
                }}
                className="flex items-center gap-3 text-left group min-h-[44px]"
              >
                <Avatar src={displayDp} name={displayName} sizeClass="w-11 h-11" />
                <div>
                  <p className="text-base font-extrabold text-[#0F172A] group-hover:underline leading-snug">
                    {displayName}
                  </p>
                  <p className="text-xs text-slate-400">
                    @{displayHandle} &middot; {formatISTTimestamp(post.createdAt)} &middot;{' '}
                    {post.category === 'sarkari_naukri' ? 'Sarkari Naukri' : 'Business Post'}
                  </p>
                </div>
              </button>

              <div className="flex items-center gap-2 shrink-0">
                <LikeButton
                  post={post}
                  currentMember={currentMember}
                  variant="detail"
                />
                {!isOwner && !isAdmin && currentMember && (
                  <button
                    type="button"
                    onClick={() => setReportModalOpen(true)}
                    aria-label="Report post"
                    className="min-h-[40px] px-3.5 rounded-full bg-slate-100 hover:bg-slate-200/80 text-slate-600 text-xs font-bold flex items-center gap-1.5 transition-colors"
                  >
                    <Flag className="w-3.5 h-3.5" />
                    <span>Report</span>
                  </button>
                )}
                {canDelete && !confirmDelete && (
                  <button
                    type="button"
                    onClick={() => setConfirmDelete(true)}
                    aria-label="Delete post"
                    className="min-h-[40px] min-w-[40px] rounded-full bg-rose-50 text-rose-600 hover:bg-rose-100 flex items-center justify-center transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {post.caption ? (
              <p className="mt-5 text-[15px] text-slate-700 leading-relaxed whitespace-pre-wrap break-words">
                {post.caption}
              </p>
            ) : (
              <p className="mt-5 text-sm text-slate-400 italic">Bina caption ki photo</p>
            )}

            {error && (
              <div className="mt-4 rounded-2xl bg-rose-50 px-4 py-3 text-xs font-medium text-rose-700">
                {error}
              </div>
            )}

            {canDelete && confirmDelete && (
              <div className="mt-6 rounded-[22px] bg-rose-50 p-4 space-y-3">
                <p className="text-sm font-bold text-rose-900">
                  Kya aap sach me yeh post delete karna chahte ho?
                </p>
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    disabled={deleting}
                    onClick={() => void handleDelete()}
                    className="flex-1 h-11 rounded-full bg-rose-600 text-white text-xs font-bold disabled:opacity-60"
                  >
                    {deleting ? 'Delete ho raha hai...' : 'Haan, Delete Karo'}
                  </button>
                  <button
                    type="button"
                    disabled={deleting}
                    onClick={() => setConfirmDelete(false)}
                    className="flex-1 h-11 rounded-full bg-white text-slate-700 text-xs font-bold border border-rose-200"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="mt-8 w-full h-13 rounded-full bg-[#0F172A] text-white text-sm font-bold"
          >
            Band Karo
          </button>
        </div>
      </div>

      {isFullScreen && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col justify-between select-none">
          {/* Top Header Bar */}
          <div className="p-4 flex items-center justify-between z-20 bg-gradient-to-b from-black/80 via-black/40 to-transparent">
            <button
              type="button"
              onClick={() => setIsFullScreen(false)}
              aria-label="Close full view"
              className="min-h-[44px] min-w-[44px] rounded-full bg-white/20 text-white backdrop-blur-md flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <span className="text-xs font-bold text-white/90">Full Screen Photo</span>
            <div className="w-11" />
          </div>

          {/* Full Screen Interactive Zoom Area */}
          <div className="flex-1 flex items-center justify-center p-2 relative">
            <ZoomableImage
              src={post.imageUrl}
              alt={post.caption || displayName}
              className="w-full h-full max-h-[85vh]"
              imgClassName="max-h-[85vh] mx-auto rounded-lg"
            />
          </div>

          {/* Bottom Caption & Author Info */}
          <div className="p-5 bg-gradient-to-t from-black/90 via-black/50 to-transparent text-white z-20">
            <p className="text-sm font-extrabold text-white">{displayName}</p>
            {post.caption && (
              <p className="mt-1 text-xs text-slate-200 leading-relaxed max-h-16 overflow-y-auto">
                {post.caption}
              </p>
            )}
          </div>
        </div>
      )}

      {/* Flag / Moderation Report Modal Sheet */}
      {reportModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-4">
          <div className="w-full max-w-[400px] bg-white rounded-[28px] p-6 shadow-2xl space-y-5 animate-in fade-in slide-in-from-bottom-4 duration-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-rose-600">
                <Flag className="w-5 h-5" />
                <h3 className="text-lg font-extrabold text-[#0F172A]">Post Report Karo</h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setReportModalOpen(false);
                  setReportSent(false);
                }}
                className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {reportAlreadyDone ? (
              <div className="py-6 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto">
                  <Flag className="w-6 h-6" />
                </div>
                <h4 className="text-base font-extrabold text-[#0F172A]">Aap pehle hi report kar chuke ho</h4>
                <p className="text-xs text-slate-500 leading-relaxed px-2">
                  Aapne is post ke baare me pehle hi report bhej di hai. Hum iski janch kar rahe hain.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setReportModalOpen(false);
                    setReportAlreadyDone(false);
                  }}
                  className="mt-2 w-full h-12 rounded-full bg-[#0F172A] text-white text-xs font-bold"
                >
                  Theek Hai
                </button>
              </div>
            ) : reportSent ? (
              <div className="py-6 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="text-base font-extrabold text-[#0F172A]">Report Bhej Di Gayi Hai</h4>
                <p className="text-xs text-slate-500 leading-relaxed px-2">
                  Dhanyawad! Hum is post ki janch karenge aur zaroori action lenge.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setReportModalOpen(false);
                    setReportSent(false);
                  }}
                  className="mt-2 w-full h-12 rounded-full bg-[#0F172A] text-white text-xs font-bold"
                >
                  Theek Hai
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-xs text-slate-500 font-medium">
                  Aap yeh post kyu report karna chahte ho?
                </p>

                <div className="space-y-2">
                  {[
                    'Spam',
                    'Galat/aapatti-jank content',
                    'Nakli/fake',
                    'Kuch aur',
                  ].map((reason) => (
                    <label
                      key={reason}
                      className={`flex items-center gap-3 p-3.5 rounded-2xl border text-xs font-bold cursor-pointer transition-colors ${
                        reportReason === reason
                          ? 'border-[#0F172A] bg-slate-50 text-[#0F172A]'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50/60'
                      }`}
                    >
                      <input
                        type="radio"
                        name="reportReason"
                        value={reason}
                        checked={reportReason === reason}
                        onChange={() => setReportReason(reason)}
                        className="accent-[#0F172A] w-4 h-4"
                      />
                      <span>{reason}</span>
                    </label>
                  ))}
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    Details / Note (Optional, max 200 chars):
                  </label>
                  <textarea
                    value={reportNote}
                    onChange={(e) => setReportNote(e.target.value.slice(0, 200))}
                    placeholder="Koi khaas wajah batana chahein..."
                    rows={2}
                    className="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-[#0F172A] outline-none resize-none focus:border-[#0F172A]"
                  />
                  <span className="text-[10px] text-slate-400 block text-right">
                    {reportNote.length}/200
                  </span>
                </div>

                <button
                  type="button"
                  disabled={reportSubmitting}
                  onClick={handleReportSubmit}
                  className="w-full h-12 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md transition-colors disabled:opacity-50"
                >
                  {reportSubmitting ? 'Bhej rahe hain...' : 'Report Bhejo'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
