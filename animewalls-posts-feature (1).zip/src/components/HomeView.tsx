import React, { useCallback, useEffect, useRef, useState } from 'react';
import type { DocumentData, QueryDocumentSnapshot } from 'firebase/firestore';
import { Bell, ImagePlus, LayoutDashboard, RefreshCw, WifiOff, X } from 'lucide-react';
import { isQuotaExceededError } from '../firebase';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import {
  fetchMemberNotifications,
  fetchNewestNotificationForMember,
  fetchPostsPage,
} from '../services/postService';
import { fetchAllMembersOnce } from '../services/userCache';
import { AuthModalMode, NotificationItem, PostItem, UserProfile } from '../types';
import { formatISTTimestamp } from '../utils/istDate';
import { Avatar } from './Avatar';
import { LimitExceededCard } from './LimitExceededCard';
import { PostCard } from './PostCard';
import { PullToRefresh } from './PullToRefresh';
import { PWAInstallButton } from './PWAInstallButton';
import { FeedSkeleton } from './Skeletons';

interface HomeViewProps {
  currentMember: UserProfile | null;
  viewerName?: string | null;
  refreshSignal: number;
  isAdmin: boolean;
  onGoToProfile: () => void;
  onOpenAuth: (mode: AuthModalMode) => void;
  onOpenMemberProfile: (uid: string) => void;
  onSelectPost: (post: PostItem) => void;
  onGoToUpload: () => void;
  onOpenAdmin?: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  currentMember,
  viewerName,
  refreshSignal,
  isAdmin,
  onGoToProfile,
  onOpenAuth,
  onOpenMemberProfile,
  onSelectPost,
  onGoToUpload,
  onOpenAdmin,
}) => {
  const isOnline = useOnlineStatus();
  const [members, setMembers] = useState<UserProfile[]>([]);
  const [posts, setPosts] = useState<PostItem[]>([]);
  const [lastDoc, setLastDoc] = useState<QueryDocumentSnapshot<DocumentData> | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [limitExceeded, setLimitExceeded] = useState(false);

  // Notification states
  const [hasUnreadNotif, setHasUnreadNotif] = useState(false);
  const [notifModalOpen, setNotifModalOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loadingNotifs, setLoadingNotifs] = useState(false);
  const [lastSeenMs, setLastSeenMs] = useState<number>(0);

  const sentinelRef = useRef<HTMLDivElement | null>(null);

  // 1-read query for member bell red dot (shown only to logged-in non-admin members)
  useEffect(() => {
    if (!currentMember || isAdmin) return;
    let active = true;
    (async () => {
      try {
        const stored = localStorage.getItem(`bm_last_seen_notif_${currentMember.uid}`);
        const seenTime = stored ? Number(stored) : 0;
        setLastSeenMs(seenTime);

        const newest = await fetchNewestNotificationForMember(currentMember.uid);
        if (!active || !newest || !newest.createdAt) return;
        const notifTime = newest.createdAt.toMillis?.() ?? 0;
        if (notifTime > seenTime) {
          setHasUnreadNotif(true);
        }
      } catch {
        // Silent fail
      }
    })();
    return () => {
      active = false;
    };
  }, [currentMember, isAdmin, refreshSignal]);

  const handleOpenNotifications = async () => {
    if (!currentMember) return;
    setNotifModalOpen(true);
    setHasUnreadNotif(false);
    const now = Date.now();
    try {
      localStorage.setItem(`bm_last_seen_notif_${currentMember.uid}`, String(now));
    } catch {}

    setLoadingNotifs(true);
    try {
      const res = await fetchMemberNotifications(currentMember.uid);
      setNotifications(res.notifications);
    } catch {
      // Handled in modal
    } finally {
      setLoadingNotifs(false);
    }
  };

  const loadInitial = useCallback(async () => {
    setError(null);
    setInitialLoading(true);
    try {
      const isMemberOrAdmin = Boolean(currentMember || isAdmin);
      const [page, memberList] = await Promise.all([
        fetchPostsPage(null, isMemberOrAdmin), // Home shows ALL posts within last 2 days
        fetchAllMembersOnce().catch(() => [] as UserProfile[]),
      ]);

      if (page.limitExceeded) {
        setLimitExceeded(true);
        setPosts([]); // Do NOT show posts if allowance is used up on open
      } else {
        setLimitExceeded(false);
        setPosts(page.posts);
      }

      setLastDoc(page.lastDoc);
      setHasMore(page.hasMore);
      setMembers(memberList);
    } catch (err) {
      if (isQuotaExceededError(err)) {
        setError('Aaj ka Firebase free Spark read quota poora ho gaya hai. Kal subah reset hoga.');
      } else if (!navigator.onLine) {
        setError('Internet band hai. Online aate hi posts dikhengi.');
      } else {
        setError('Feed load nahi ho paayi. Dobara try karo.');
      }
    } finally {
      setInitialLoading(false);
    }
  }, [currentMember, isAdmin]);

  useEffect(() => {
    void loadInitial();
  }, [loadInitial, refreshSignal]);

  const loadMore = useCallback(async () => {
    if (loadingMore || !hasMore || !lastDoc || limitExceeded) return;
    setLoadingMore(true);
    try {
      const isMemberOrAdmin = Boolean(currentMember || isAdmin);
      const next = await fetchPostsPage(lastDoc, isMemberOrAdmin);

      if (next.limitExceeded) {
        setLimitExceeded(true);
        setHasMore(false);
        return;
      }

      setPosts((prev) => {
        const existingIds = new Set(prev.map((p) => p.id));
        const uniqueNew = next.posts.filter((p) => !existingIds.has(p.id));
        return [...prev, ...uniqueNew];
      });
      setLastDoc(next.lastDoc);
      setHasMore(next.hasMore);
    } catch {
      // Allow retry on next scroll
    } finally {
      setLoadingMore(false);
    }
  }, [currentMember, hasMore, isAdmin, lastDoc, limitExceeded, loadingMore]);

  useEffect(() => {
    const node = sentinelRef.current;
    if (!node || !hasMore || initialLoading || limitExceeded) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          void loadMore();
        }
      },
      { rootMargin: '250px' }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [hasMore, initialLoading, limitExceeded, loadMore]);

  const isNameOnlyViewer = Boolean(viewerName && !currentMember);

  const handleRefresh = useCallback(async () => {
    setError(null);
    try {
      const isMemberOrAdmin = Boolean(currentMember || isAdmin);
      const [page, memberList] = await Promise.all([
        fetchPostsPage(null, isMemberOrAdmin),
        fetchAllMembersOnce().catch(() => [] as UserProfile[]),
      ]);

      if (page.limitExceeded) {
        setLimitExceeded(true);
        setPosts([]);
      } else {
        setLimitExceeded(false);
        setPosts(page.posts);
      }

      setLastDoc(page.lastDoc);
      setHasMore(page.hasMore);
      setMembers(memberList);
    } catch (err) {
      if (isQuotaExceededError(err)) {
        setError('Aaj ka Firebase free Spark read quota poora ho gaya hai. Kal subah reset hoga.');
      } else if (!navigator.onLine) {
        setError('Internet band hai. Online aate hi posts dikhengi.');
      }
    }
  }, [currentMember, isAdmin]);

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div className="pb-24 min-h-dvh bg-white">
        {/* Sticky App Header */}
        <header className="sticky top-0 z-20 bg-white/95 backdrop-blur-md px-5 h-16 flex items-center justify-between gap-3 border-b border-slate-100/80">
          <div className="flex items-center gap-2.5 min-w-0">
            <h1 className="text-[21px] font-extrabold text-[#0F172A] tracking-tight truncate">
              Business Media
            </h1>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton compact />

            {/* Notification Bell (Shown ONLY to logged-in members, NEVER to admin, viewer, or guest) */}
            {currentMember && !isAdmin && (
              <button
                type="button"
                onClick={() => void handleOpenNotifications()}
                aria-label="Notifications"
                className="relative min-h-[40px] min-w-[40px] rounded-full text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors"
              >
                <Bell className="w-5 h-5" />
                {hasUnreadNotif && (
                  <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white" />
                )}
              </button>
            )}

            {/* Admin Dashboard shortcut button */}
            {isAdmin && onOpenAdmin && (
              <button
                type="button"
                onClick={onOpenAdmin}
                aria-label="Open Admin Dashboard"
                className="min-h-[40px] px-3 rounded-full bg-[#0F172A] text-white text-xs font-bold flex items-center gap-1.5 shadow-sm hover:bg-slate-800 transition-colors"
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                <span>Admin</span>
              </button>
            )}

            {/* Header Right Avatar / Login button */}
            {currentMember ? (
              <button
                type="button"
                onClick={onGoToProfile}
                aria-label="Open my profile"
                className="rounded-full ring-2 ring-slate-100 hover:ring-slate-300 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F172A]"
              >
                <Avatar
                  src={currentMember.dpUrl}
                  name={currentMember.fullName || currentMember.userName}
                  sizeClass="w-9 h-9"
                  textSizeClass="text-xs"
                />
              </button>
            ) : isNameOnlyViewer ? (
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-700 truncate max-w-[120px]">
                  Hi, {viewerName}
                </span>
                <button
                  type="button"
                  onClick={() => onOpenAuth('login')}
                  className="px-3 py-1.5 rounded-full bg-[#0F172A] text-white text-xs font-bold shadow-xs hover:bg-slate-800 transition-colors"
                >
                  Member Bano
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => onOpenAuth('login')}
                className="px-4 py-2 rounded-full bg-[#0F172A] text-white text-xs font-bold shadow-xs hover:bg-slate-800 transition-colors"
              >
                Sign In
              </button>
            )}
          </div>
        </header>

        {/* Offline Banner */}
        {!isOnline && (
          <div className="bg-amber-500 text-white text-xs font-bold py-2 px-4 flex items-center justify-center gap-2">
            <WifiOff className="w-4 h-4 shrink-0" />
            <span>Internet band hai. Offline mode me cached data dikh raha hai.</span>
          </div>
        )}

        {/* Top Members Avatar Horizontal Scroll Strip */}
        {members.length > 0 && (
          <section
            aria-label="Registered members"
            className="pt-3 pb-3 border-b border-slate-100 overflow-x-auto no-scrollbar"
          >
            <div className="flex items-center gap-3.5 px-4 min-w-max">
              {members.map((m) => (
                <button
                  key={m.uid}
                  type="button"
                  onClick={() => onOpenMemberProfile(m.uid)}
                  className="flex flex-col items-center gap-1 group text-center w-16"
                >
                  <Avatar
                    src={m.dpUrl}
                    name={m.fullName || m.userName}
                    sizeClass="w-13 h-13"
                    textSizeClass="text-sm"
                    ringClass="ring-2 ring-slate-100 group-hover:ring-[#0F172A] transition-all"
                  />
                  <span className="text-[11px] font-medium text-slate-700 truncate w-full leading-tight">
                    {m.fullName || m.userName}
                  </span>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Main Feed Content */}
        <div className="px-4 pt-4">
          {initialLoading ? (
            <FeedSkeleton />
          ) : limitExceeded && posts.length === 0 ? (
            <LimitExceededCard isInline={false} />
          ) : error ? (
            <div className="rounded-[24px] bg-slate-50 p-6 text-center space-y-3 my-4">
              <p className="text-sm font-semibold text-slate-600">{error}</p>
              <button
                type="button"
                onClick={() => void loadInitial()}
                className="px-5 h-11 rounded-full bg-[#0F172A] text-white text-xs font-bold flex items-center gap-2 mx-auto"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Dobara Try Karo</span>
              </button>
            </div>
          ) : posts.length === 0 ? (
            <div className="rounded-[28px] bg-[#F8FAFC] border border-slate-100 p-8 text-center my-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-white shadow-sm flex items-center justify-center mx-auto text-[#0F172A]">
                <ImagePlus className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-lg font-black text-[#0F172A]">Abhi koi nayi post nahi hai</h3>
                <p className="mt-1 text-xs text-slate-500 leading-relaxed max-w-[280px] mx-auto">
                  Posts 2 din tak feed me dikhti hain. Pehli nayi post upload karne ke liye neeche button dabao.
                </p>
              </div>
              {!isNameOnlyViewer && (
                <button
                  type="button"
                  onClick={onGoToUpload}
                  className="px-6 h-12 rounded-full bg-[#0F172A] text-white text-xs font-bold shadow-md shadow-slate-200"
                >
                  Nayi Post Upload Karo
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {posts.map((post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  currentMember={currentMember}
                  isAdmin={isAdmin}
                  onSelectPost={onSelectPost}
                  onOpenMemberProfile={onOpenMemberProfile}
                  onOpenAuth={() => onOpenAuth('login')}
                />
              ))}

              {limitExceeded ? (
                <LimitExceededCard isInline={true} />
              ) : (
                <div ref={sentinelRef} className="h-10 flex items-center justify-center">
                  {loadingMore && (
                    <span className="text-xs font-semibold text-slate-400">
                      Aur posts load ho rahi hain...
                    </span>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Member Notifications Modal */}
      {notifModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-[28px] bg-white p-6 shadow-2xl max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-[#0F172A]" />
                <h2 className="text-base font-black text-[#0F172A]">Notifications</h2>
              </div>
              <button
                type="button"
                onClick={() => setNotifModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-y-auto py-3 space-y-3 flex-1 no-scrollbar">
              {loadingNotifs ? (
                <div className="py-8 text-center text-xs text-slate-400">Load ho raha hai...</div>
              ) : notifications.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">Koi notification nahi hai.</div>
              ) : (
                notifications.map((n) => (
                  <div key={n.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 space-y-1">
                    <h4 className="text-xs font-black text-[#0F172A]">{n.title}</h4>
                    <p className="text-xs text-slate-600 leading-relaxed">{n.body}</p>
                    <span className="text-[10px] text-slate-400 block pt-0.5">
                      {formatISTTimestamp(n.createdAt)}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </PullToRefresh>
  );
};
