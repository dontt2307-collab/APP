import React from 'react';
import splashBgImg from '../assets/images/splash_bg_1792942840143.jpg';

interface SplashScreenProps {
  fadingOut: boolean;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ fadingOut }) => {
  return (
    <div
      className={`fixed inset-0 z-50 flex justify-center bg-[#0F172A] transition-opacity duration-300 ${
        fadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      <div className="relative w-full max-w-[430px] h-dvh overflow-hidden flex flex-col items-center justify-between py-10 px-6 select-none bg-slate-900">
        {/* High quality sunset wallpaper background image */}
        <img
          src={splashBgImg}
          alt="Loading background"
          className="absolute inset-0 w-full h-full object-cover object-center scale-105 filter brightness-[0.92] contrast-[1.05]"
        />

        {/* Ambient Dark Overlay for crystal clear typography contrast */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-black/10 to-black/65 pointer-events-none" />

        {/* Top Spacer */}
        <div className="w-full pt-2 z-10" />

        {/* Center Wordmark & Tagline */}
        <div className="flex flex-col items-center text-center -mt-10 z-10">
          <h1 className="font-script text-[56px] leading-none text-white drop-shadow-[0_4px_20px_rgba(0,0,0,0.85)] tracking-tight select-none">
            Business Media
          </h1>
          <p className="mt-4 text-[11px] font-bold tracking-[0.28em] text-white/95 uppercase drop-shadow-[0_2px_10px_rgba(0,0,0,0.9)]">
            SIRF APNE LOG &middot; SIRF APNI POST
          </p>
        </div>

        {/* Bottom home bar indicator with loading spinner */}
        <div className="w-full flex flex-col items-center gap-6 z-10">
          <div className="flex flex-col items-center gap-2">
            <div className="w-8 h-8 rounded-full border-2 border-white/20 border-t-white animate-spin" />
            <p className="text-[10px] font-bold text-white/50 uppercase tracking-widest">Checking Account...</p>
          </div>
          <div className="w-32 h-1.5 rounded-full bg-white/85 shadow-lg" />
        </div>
      </div>
    </div>
  );
};
