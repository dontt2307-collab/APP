import React, { useCallback, useEffect, useRef, useState } from 'react';
import type { DocumentData, QueryDocumentSnapshot } from 'firebase/firestore';
import {
  ChevronLeft,
  Grid,
  Info,
  Menu,
  RefreshCw,
  Trash2,
} from 'lucide-react';
import { PROFILE_INFO_TEXT } from '../config';
import {
  deletePostAtomic,
  fetchMemberPostsPage,
} from '../services/postService';
import { fetchUserCached } from '../services/userCache';
import { AuthModalMode, AdminTabId, PostItem, UserProfile } from '../types';
import { Avatar } from './Avatar';
import { LikeButton } from './LikeButton';
import { ProfileMenuPage } from './ProfileMenuPage';
import { SafeImage } from './SafeImage';
import { GridSkeleton, ProfileHeaderSkeleton } from './Skeletons';


interface ProfileViewProps {
  /** If provided, renders that member's profile (read-only unless targetUid === currentMember.uid) */
  targetUid?: string;
  currentMember: UserProfile | null;
  viewerName?: string | null;
  refreshSignal: number;
  isAdmin: boolean;
  onBack?: () => void;
  onOpenAuth: (mode: AuthModalMode) => void;
  onExitViewer?: () => void;
  onEditProfile: () => void;
  onOpenSettings: () => void;
  onLogout: () => void;
  onOpenAdmin: (tab: AdminTabId) => void;
  onSelectPost: (post: PostItem) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  targetUid,
  currentMember,
  viewerName = null,
  refreshSignal,
  isAdmin,
  onBack,
  onOpenAuth,
  onExitViewer = () => {},
  onEditProfile,
  onOpenSettings,
  onLogout,
  onOpenAdmin,
  onSelectPost,
}) => {
  const effectiveUid = targetUid || currentMember?.uid || null;
  const isOwnProfile = Boolean(currentMember && effectiveUid === currentMember.uid);

  const [menuOpen, setMenuOpen] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(
    isOwnProfile ? currentMember : null
  );
  const [loadingProfile, setLoadingProfile] = useState<boolean>(
    Boolean(effectiveUid && !isOwnProfile)
  );
  const [posts, setPosts] = useState<PostItem[]>([]);
  const [lastDoc, setLastDoc] = useState<QueryDocumentSnapshot<DocumentData> | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [loadingPosts, setLoadingPosts] = useState(Boolean(effectiveUid));
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Single post delete state with confirm dialog
  const [deletingPost, setDeletingPost] = useState<PostItem | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteSuccessMsg, setDeleteSuccessMsg] = useState<string | null>(null);

  const sentinelRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (isOwnProfile && currentMember) {
      setProfile(currentMember);
    }
  }, [currentMember, isOwnProfile]);

  const loadData = useCallback(async () => {
    if (!effectiveUid) return;
    setError(null);
    setLoadingPosts(true);
    if (!isOwnProfile) setLoadingProfile(true);

    try {
      const isPrivileged = isOwnProfile || isAdmin;
      const [fetchedUser, firstPage] = await Promise.all([
        isOwnProfile && currentMember
          ? Promise.resolve(currentMember)
          : fetchUserCached(effectiveUid),
        fetchMemberPostsPage(effectiveUid, null, isPrivileged),
      ]);

      setProfile(fetchedUser);
      setPosts(firstPage.posts);
      setLastDoc(firstPage.lastDoc);
      setHasMore(firstPage.hasMore);
    } catch {
      setError('Profile load karne me dikkat aayi. Dobara try karo.');
    } finally {
      setLoadingProfile(false);
      setLoadingPosts(false);
    }
  }, [currentMember, effectiveUid, isAdmin, isOwnProfile]);

  useEffect(() => {
    void loadData();
  }, [loadData, refreshSignal]);

  const loadMorePosts = useCallback(async () => {
    if (!effectiveUid || loadingMore || !hasMore || !lastDoc) return;
    setLoadingMore(true);
    try {
      const isPrivileged = isOwnProfile || isAdmin;
      const next = await fetchMemberPostsPage(effectiveUid, lastDoc, isPrivileged);
      setPosts((prev) => {
        const seen = new Set(prev.map((p) => p.id));
        return [...prev, ...next.posts.filter((p) => !seen.has(p.id))];
      });
      setLastDoc(next.lastDoc);
      setHasMore(next.hasMore);
    } catch {
      // Retry on scroll
    } finally {
      setLoadingMore(false);
    }
  }, [effectiveUid, hasMore, isAdmin, isOwnProfile, lastDoc, loadingMore]);

  useEffect(() => {
    const node = sentinelRef.current;
    if (!node || !hasMore || loadingPosts) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          void loadMorePosts();
        }
      },
      { rootMargin: '240px' }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [hasMore, loadMorePosts, loadingPosts]);

  const handleConfirmDeletePost = async () => {
    if (!deletingPost || !currentMember) return;
    setDeleting(true);
    try {
      await deletePostAtomic(deletingPost.id, currentMember);
      setPosts((prev) => prev.filter((p) => p.id !== deletingPost.id));
      if (profile) {
        setProfile({
          ...profile,
          postCount: Math.max(0, profile.postCount - 1),
        });
      }
      setDeletingPost(null);
      setDeleteSuccessMsg('Post safalta se delete ho gayi.');
      setTimeout(() => setDeleteSuccessMsg(null), 3000);
    } catch {
      setError('Post delete nahi ho paayi. Dobara try karo.');
    } finally {
      setDeleting(false);
    }
  };


  // Name-only Viewer or Guest Profile
  if (!effectiveUid) {
    const displayName = viewerName || 'Guest User';

    return (
      <>
        <div className="min-h-dvh pb-24 bg-white flex flex-col">
          <header className="sticky top-0 z-20 bg-white/95 backdrop-blur-md px-5 h-15 flex items-center justify-between border-b border-slate-100/80">
            <h1 className="text-lg font-extrabold text-[#0F172A] truncate">
              {viewerName || 'Profile'}
            </h1>
            <button
              type="button"
              onClick={() => setMenuOpen(true)}
              aria-label="Open menu options"
              className="min-h-[40px] min-w-[40px] -mr-1 rounded-full hover:bg-slate-100 text-[#0F172A] flex items-center justify-center transition-colors"
            >
              <Menu className="w-6 h-6" strokeWidth={2.3} />
            </button>
          </header>

          <div className="px-6 pt-10 pb-8 flex flex-col items-center text-center">
            <Avatar
              src=""
              name={displayName}
              sizeClass="w-24 h-24"
              textSizeClass="text-3xl"
              ringClass="ring-4 ring-slate-100 shadow-sm"
            />
            <h2 className="mt-4 text-2xl font-extrabold text-[#0F172A] tracking-tight">
              {displayName}
            </h2>
            <p className="mt-1.5 text-xs text-slate-400 font-medium">
              {viewerName ? 'Business Media Viewer (Google Sheet)' : 'Guest Profile'}
            </p>
          </div>
        </div>

        {menuOpen && (
          <ProfileMenuPage
            currentMember={null}
            viewerName={viewerName}
            onClose={() => setMenuOpen(false)}
            onOpenAuth={onOpenAuth}
            onEditProfile={onEditProfile}
            onOpenSettings={onOpenSettings}
            onOpenAdmin={() => {}}
            onExit={onExitViewer}
          />
        )}
      </>
    );
  }

  return (
    <>
      <div
        className={`${
          onBack ? 'fixed inset-0 z-40 overflow-y-auto bg-[#F4F6F9] flex justify-center' : ''
        }`}
      >
        <div
          className={`w-full max-w-[430px] min-h-dvh bg-white ${
            onBack ? 'pb-12' : 'pb-28'
          }`}
        >
          {/* Top Bar */}
          <header className="sticky top-0 z-20 bg-white/95 backdrop-blur-md px-5 h-15 flex items-center justify-between border-b border-slate-100/80">
            <div className="flex items-center gap-2 min-w-0">
              {onBack && (
                <button
                  type="button"
                  onClick={onBack}
                  aria-label="Back"
                  className="min-h-[40px] min-w-[40px] -ml-2 rounded-full flex items-center justify-center text-[#0F172A] hover:bg-slate-100"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
              )}
              <h1 className="text-lg font-extrabold text-[#0F172A] truncate">
                {profile ? `@${profile.userName}` : 'Profile'}
              </h1>
            </div>

            {isOwnProfile && (
              <button
                type="button"
                onClick={() => setMenuOpen(true)}
                aria-label="Open menu options"
                className="min-h-[40px] min-w-[40px] -mr-1 rounded-full hover:bg-slate-100 text-[#0F172A] flex items-center justify-center transition-colors"
              >
                <Menu className="w-6 h-6" strokeWidth={2.3} />
              </button>
            )}
          </header>

          {/* Non-dismissible calm info strip on Member's OWN profile only (not admin, not viewers, not other members' profiles) */}
          {isOwnProfile && !isAdmin && (
            <div className="bg-slate-50 border-b border-slate-200/90 text-slate-700 px-4 py-3 shadow-xs">
              <div className="flex items-start gap-2.5">
                <Info className="w-4 h-4 shrink-0 mt-0.5 text-slate-500" />
                <p className="text-xs font-semibold leading-relaxed text-slate-700">
                  {PROFILE_INFO_TEXT}
                </p>
              </div>
            </div>
          )}

          {deleteSuccessMsg && (
            <div className="mx-4 mt-3 rounded-2xl bg-emerald-50 border border-emerald-200 p-3 text-xs font-bold text-emerald-800">
              {deleteSuccessMsg}
            </div>
          )}

          {loadingProfile ? (
            <ProfileHeaderSkeleton />
          ) : !profile ? (
            <div className="px-6 py-12 text-center">
              <p className="text-sm font-semibold text-slate-500">Yeh member profile nahi mila.</p>
            </div>
          ) : (
            <>
              {/* Profile Info */}
              <div className="px-6 pt-6 pb-5 flex flex-col items-center text-center">
                {isOwnProfile ? (
                  <button
                    type="button"
                    onClick={onEditProfile}
                    aria-label="Edit profile photo, name and username"
                    className="rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F172A]"
                  >
                    <Avatar
                      src={profile.dpUrl}
                      name={profile.fullName || profile.userName}
                      sizeClass="w-24 h-24"
                      textSizeClass="text-3xl"
                      ringClass="ring-4 ring-slate-100 shadow-sm hover:ring-slate-200 transition-all"
                    />
                  </button>
                ) : (
                  <Avatar
                    src={profile.dpUrl}
                    name={profile.fullName || profile.userName}
                    sizeClass="w-24 h-24"
                    textSizeClass="text-3xl"
                    ringClass="ring-4 ring-slate-100 shadow-sm"
                  />
                )}

                <h2 className="mt-4 text-2xl font-extrabold text-[#0F172A] tracking-tight">
                  {profile.fullName || profile.userName}
                </h2>
                <p className="mt-0.5 text-sm font-semibold text-slate-500">
                  @{profile.userName}
                </p>

                {profile.bio ? (
                  <p className="mt-2 text-sm text-slate-600 max-w-[300px] leading-relaxed">
                    {profile.bio}
                  </p>
                ) : (
                  <p className="mt-1.5 text-xs text-slate-400">Business Media Member</p>
                )}

                <div className="mt-4 flex items-center gap-2 text-sm text-slate-600">
                  <span className="font-extrabold text-[#0F172A] tabular-nums">
                    {profile.postCount}
                  </span>
                  <span className="text-slate-400">Posts</span>
                </div>
              </div>

              {/* Grid / Posts Header */}
              <div className="border-t border-slate-100 pt-4">
                <div className="px-5 mb-3 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                    <Grid className="w-3.5 h-3.5" />
                    <span>Posts</span>
                  </div>
                </div>

                {loadingPosts ? (
                  <GridSkeleton />
                ) : error ? (
                  <div className="mx-5 my-4 rounded-[22px] bg-slate-50 p-6 text-center space-y-3">
                    <p className="text-xs font-semibold text-slate-600">{error}</p>
                    <button
                      type="button"
                      onClick={() => void loadData()}
                      className="px-5 h-10 rounded-full bg-[#0F172A] text-white text-xs font-bold"
                    >
                      Dobara Try Karo
                    </button>
                  </div>
                ) : posts.length === 0 ? (
                  <div className="mx-5 my-6 rounded-[24px] bg-[#F8FAFC] border border-slate-100 p-8 text-center">
                    <p className="text-sm font-bold text-[#0F172A]">Abhi koi post nahi hai</p>
                    <p className="mt-1 text-xs text-slate-500">
                      {isOwnProfile
                        ? 'Neeche + button dabakar apni pehli photo upload karo.'
                        : 'Is member ne pichle 2 din me koi photo upload nahi ki hai.'}
                    </p>
                  </div>
                ) : (
                  <div className="px-5">
                    <div className="grid grid-cols-2 gap-3.5">
                      {posts.map((post) => (
                        <div
                          key={post.id}
                          className="relative aspect-[4/5] rounded-[22px] overflow-hidden bg-slate-100 border border-slate-100 shadow-xs group"
                        >
                          <button
                            type="button"
                            onClick={() => onSelectPost(post)}
                            className="w-full h-full block text-left"
                          >
                            <SafeImage
                              src={post.imageUrl}
                              alt={post.caption || profile.userName}
                              className="w-full h-full group-hover:scale-[1.02] transition-transform duration-200"
                            />
                          </button>

                          {/* Top-right action: Owner gets individual Delete button, non-owner gets Like */}
                          <div className="absolute top-2.5 right-2.5 z-10 flex flex-col gap-1.5">
                            {isOwnProfile ? (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setDeletingPost(post);
                                }}
                                aria-label="Delete post"
                                className="w-8 h-8 rounded-full bg-black/60 hover:bg-rose-600 text-white flex items-center justify-center shadow-md backdrop-blur-xs transition-colors"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            ) : (
                              <LikeButton
                                post={post}
                                currentMember={currentMember}
                                variant="compact"
                              />
                            )}
                          </div>

                          {post.caption && (
                            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent pt-8 pb-2.5 px-3 pointer-events-none">
                              <p className="text-[11.5px] text-white/95 line-clamp-1 font-medium">
                                {post.caption}
                              </p>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    <div ref={sentinelRef} className="h-8 flex items-center justify-center mt-3">
                      {loadingMore && (
                        <span className="text-xs font-semibold text-slate-400">
                          Aur posts load ho rahi hain...
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Confirmation Modal for Owner Single Post Deletion */}
      {deletingPost && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-[28px] bg-white p-6 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center">
              <h3 className="text-lg font-black text-[#0F172A]">Post Delete Karein?</h3>
              <p className="mt-1.5 text-xs text-slate-500 leading-relaxed">
                Kya aap sach me is photo post ko permanent delete karna chahte hain? Yeh database se hat jayegi.
              </p>
            </div>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                disabled={deleting}
                onClick={() => setDeletingPost(null)}
                className="flex-1 h-11 rounded-full bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-700"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={deleting}
                onClick={() => void handleConfirmDeletePost()}
                className="flex-1 h-11 rounded-full bg-rose-600 hover:bg-rose-700 text-xs font-bold text-white shadow-md shadow-rose-200 flex items-center justify-center gap-1.5"
              >
                {deleting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Delete ho rahi hai...</span>
                  </>
                ) : (
                  <span>Haan, Delete Karo</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}


      {menuOpen && isOwnProfile && (
        <ProfileMenuPage
          currentMember={currentMember}
          viewerName={viewerName}
          isAdmin={isAdmin}
          onClose={() => setMenuOpen(false)}
          onOpenAuth={onOpenAuth}
          onEditProfile={onEditProfile}
          onOpenSettings={onOpenSettings}
          onOpenAdmin={onOpenAdmin}
          onExit={onLogout}
        />
      )}
    </>
  );
};
