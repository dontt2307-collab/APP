import React, { useEffect, useState } from 'react';
import { CheckCircle2, ChevronLeft, Eye, EyeOff, KeyRound, Plus, Trash2 } from 'lucide-react';
import { auth } from '../firebase';
import { IMGBB_KEY } from '../config';
import {
  cleanImgbbKey,
  getMemberImgbbKeys,
  maskImgbbKey,
  saveMemberImgbbKeys,
  verifyImgbbKey,
} from '../services/imgbbService';
import { PWAInstallButton } from './PWAInstallButton';

interface SettingsModalProps {
  uid: string;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ uid, onClose }) => {
  const [keys, setKeys] = useState<string[]>([]);
  const [newKeyInput, setNewKeyInput] = useState('');
  const [showTypedKey, setShowTypedKey] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const fetched = await getMemberImgbbKeys(uid);
        if (active) {
          setKeys(fetched);
        }
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [uid]);

  const handleBack = async () => {
    const pendingClean = cleanImgbbKey(newKeyInput);
    if (pendingClean && !keys.includes(pendingClean)) {
      setSaving(true);
      try {
        await saveMemberImgbbKeys(uid, [pendingClean, ...keys.filter((k) => k !== pendingClean)].slice(0, 10));
      } catch {} finally {
        setSaving(false);
      }
    }
    onClose();
  };

  const handleAddKey = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setFeedback(null);
    const check = await verifyImgbbKey(newKeyInput);
    if (!check.valid) { setError(check.message); return; }
    const cleaned = cleanImgbbKey(newKeyInput);
    setSaving(true);
    try {
      const updated = [cleaned, ...keys.filter((k) => k !== cleaned)].slice(0, 10);
      const saved = await saveMemberImgbbKeys(uid, updated);
      setKeys(saved);
      setNewKeyInput('');
      setShowTypedKey(false);
      setFeedback('ImgBB API key save ho gayi!');
    } catch {
      const fallbackList = [cleaned, ...keys.filter((k) => k !== cleaned)].slice(0, 10);
      setKeys(fallbackList);
      setNewKeyInput('');
      setShowTypedKey(false);
      setFeedback('ImgBB API key save ho gayi!');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteKey = async (idx: number) => {
    setError(null);
    setFeedback(null);
    const updated = keys.filter((_, i) => i !== idx);
    setSaving(true);
    try {
      const saved = await saveMemberImgbbKeys(uid, updated);
      setKeys(saved);
    } catch {
      setKeys(updated);
    } finally {
      setSaving(false);
    }
  };

  const maskKey = (idx: number, len: number) => {
    if (idx === 0) return 'Active: ' + maskImgbbKey(idx, len);
    return maskImgbbKey(idx, len);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#F4F6F9] flex justify-center overflow-y-auto">
      <div className="w-full max-w-[430px] min-h-dvh bg-white flex flex-col shadow-xl">
        <header className="sticky top-0 z-10 bg-white/95 backdrop-blur-md px-5 h-15 flex items-center gap-3 border-b border-slate-100">
          <button
            type="button"
            disabled={saving}
            onClick={() => void handleBack()}
            aria-label="Back"
            className="min-h-[44px] min-w-[44px] -ml-2 rounded-full flex items-center justify-center text-[#0F172A] hover:bg-slate-100 disabled:opacity-50 transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h2 className="text-xl font-extrabold text-[#0F172A]">Settings</h2>
        </header>

        <div className="px-5 py-8 space-y-8 flex-1">
          <section className="rounded-[24px] bg-[#F8FAFC] border border-slate-100 p-6 space-y-4">
            <div>
              <h3 className="text-base font-bold text-[#0F172A]">Apni ImgBB API key add karo</h3>
              <p className="mt-1 text-xs text-slate-500 leading-relaxed">
                <span className="font-semibold">api.imgbb.com</span> se apni v1 API key paste karo.
              </p>
            </div>
            <form onSubmit={(e) => void handleAddKey(e)} className="space-y-3">
              <div className="flex items-center gap-2.5 bg-white rounded-full h-12 px-4 border border-slate-200">
                <KeyRound className="w-4 h-4 text-slate-400 shrink-0" />
                <input
                  type={showTypedKey ? 'text' : 'password'}
                  value={newKeyInput}
                  onChange={(e) => setNewKeyInput(e.target.value)}
                  placeholder="Paste ImgBB API key..."
                  className="w-full bg-transparent text-sm text-[#0F172A] placeholder:text-slate-400 outline-none"
                />
                {newKeyInput && (
                   <button type="button" onClick={() => setShowTypedKey(!showTypedKey)} className="text-slate-400 px-1">
                      {showTypedKey ? <EyeOff size={16}/> : <Eye size={16}/>}
                   </button>
                )}
              </div>
              <button
                type="submit"
                disabled={saving || !newKeyInput.trim()}
                className="w-full h-12 rounded-full bg-[#0F172A] text-white text-sm font-bold flex items-center justify-center gap-2 transition-colors active:scale-95"
              >
                <Plus className="w-4 h-4" />
                {saving ? 'Saving...' : 'Key Add Karo'}
              </button>
            </form>

            {feedback && <p className="text-xs font-bold text-emerald-600 bg-emerald-50 p-3 rounded-xl">{feedback}</p>}
            {error && <p className="text-xs font-bold text-rose-600 bg-rose-50 p-3 rounded-xl">{error}</p>}

            <div className="pt-2 space-y-2">
               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Saved Keys</p>
               {loading ? (
                  <div className="h-10 bg-slate-100 rounded-xl animate-pulse" />
               ) : keys.length === 0 ? (
                  <p className="text-[10px] text-slate-400 px-1 italic">No personal keys added yet</p>
               ) : (
                  keys.map((k, idx) => (
                    <div key={k} className="flex items-center justify-between bg-white border border-slate-100 p-3 rounded-xl">
                       <span className="text-xs font-bold text-slate-600 tabular-nums">{maskKey(idx, k.length)}</span>
                       <button onClick={() => handleDeleteKey(idx)} className="text-rose-500 p-1"><Trash2 size={14}/></button>
                    </div>
                  ))
               )}
            </div>
          </section>

          <PWAInstallButton />
        </div>
      </div>
    </div>
  );
};
