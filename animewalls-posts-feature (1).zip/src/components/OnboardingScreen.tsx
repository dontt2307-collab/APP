import React, { useEffect, useState } from 'react';
import {
  Briefcase,
  Camera,
  HeartHandshake,
  Image as ImageIcon,
  LucideIcon,
  Sparkles,
  Users,
} from 'lucide-react';

import bizCenterImg from '../assets/images/biz_center_team_1792934154690.jpg';
import bizLeftImg from '../assets/images/biz_left_shop_1792934156385.jpg';
import bizRightImg from '../assets/images/biz_right_craft_1792934156805.jpg';
import sarkariCenterImg from '../assets/images/sarkari_center_aspirants_1792934158542.jpg';
import sarkariLeftImg from '../assets/images/sarkari_left_study_1792934159810.jpg';
import sarkariRightImg from '../assets/images/sarkari_right_laptop_1792934161327.jpg';
import memberCenterImg from '../assets/images/member_center_upload_1792934163310.jpg';
import memberLeftImg from '../assets/images/member_left_circle_1792934164837.jpg';
import memberRightImg from '../assets/images/member_right_milestone_1792934165212.jpg';

interface OnboardingScreenProps {
  onComplete: () => void;
}

interface OnboardingPageItem {
  title: string;
  subtitle: string;
  leftImage: string;
  leftAlt: string;
  centerImage: string;
  centerAlt: string;
  rightImage: string;
  rightAlt: string;
  leftGradient: string;
  centerGradient: string;
  rightGradient: string;
  CenterIcon: LucideIcon;
  LeftIcon: LucideIcon;
  RightIcon: LucideIcon;
  caption: string;
}

const PAGES: OnboardingPageItem[] = [
  {
    title: 'Apne logo ki Business Post dekho',
    subtitle: 'Sirf pehchan ke log, bina kisi bheed ya shor ke.',
    leftImage: bizLeftImg,
    leftAlt: 'Local boutique business storefront',
    centerImage: bizCenterImg,
    centerAlt: 'Indian entrepreneurs reviewing business products together',
    rightImage: bizRightImg,
    rightAlt: 'Small business workspace and parcels ready for dispatch',
    leftGradient: 'from-sky-400 via-blue-500 to-indigo-600',
    centerGradient: 'from-sky-500 via-amber-300 to-orange-500',
    rightGradient: 'from-amber-300 via-orange-400 to-rose-500',
    CenterIcon: Users,
    LeftIcon: HeartHandshake,
    RightIcon: ImageIcon,
    caption: 'Business Post updates',
  },
  {
    title: 'Sarkari Naukri ki har nayi post dekho',
    subtitle: 'Alag Sarkari Naukri section me bharti aur form ki sabhi updates dekho.',
    leftImage: sarkariLeftImg,
    leftAlt: 'Student preparing for competitive government exam',
    centerImage: sarkariCenterImg,
    centerAlt: 'Confident Indian aspirants with document folders',
    rightImage: sarkariRightImg,
    rightAlt: 'Online exam form and study notes on desk',
    leftGradient: 'from-violet-500 via-purple-500 to-indigo-600',
    centerGradient: 'from-indigo-600 via-rose-500 to-amber-400',
    rightGradient: 'from-teal-400 via-cyan-500 to-sky-600',
    CenterIcon: Briefcase,
    LeftIcon: Sparkles,
    RightIcon: Camera,
    caption: 'Sarkari Naukri updates',
  },
  {
    title: 'Members banke apni post upload karo',
    subtitle: 'Member banke moments share karo ya sirf naam daalke dekho.',
    leftImage: memberLeftImg,
    leftAlt: 'Close circle of friends sharing a moment at sunset',
    centerImage: memberCenterImg,
    centerAlt: 'Member capturing a photo on smartphone to upload',
    rightImage: memberRightImg,
    rightAlt: 'Team celebrating a business milestone with chai',
    leftGradient: 'from-emerald-400 via-teal-500 to-cyan-700',
    centerGradient: 'from-amber-400 via-orange-500 to-slate-800',
    rightGradient: 'from-sky-400 via-indigo-400 to-slate-700',
    CenterIcon: Camera,
    LeftIcon: ImageIcon,
    RightIcon: Users,
    caption: 'Chota aur khaas circle',
  },
];

interface FramePhotoProps {
  src: string;
  alt: string;
  fallbackGradient: string;
  FallbackIcon: LucideIcon;
}

const FramePhoto: React.FC<FramePhotoProps> = ({
  src,
  alt,
  fallbackGradient,
  FallbackIcon,
}) => {
  const [failed, setFailed] = useState(false);

  if (failed || !src) {
    return (
      <div
        className={`absolute inset-0 bg-gradient-to-br ${fallbackGradient} flex items-center justify-center text-white/90`}
      >
        <FallbackIcon className="w-8 h-8 opacity-90" />
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className="absolute inset-0 w-full h-full object-cover"
    />
  );
};

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onComplete }) => {
  const [step, setStep] = useState(0);
  const current = PAGES[step];
  const isLast = step === PAGES.length - 1;
  const { CenterIcon, LeftIcon, RightIcon } = current;

  // Preload all 9 frame images so stepping through slides is instant
  useEffect(() => {
    for (const page of PAGES) {
      for (const url of [page.leftImage, page.centerImage, page.rightImage]) {
        const img = new window.Image();
        img.src = url;
      }
    }
  }, []);

  const handleFinish = () => {
    try {
      localStorage.setItem('onboarding_done', 'true');
    } catch {
      // Ignore storage failure
    }
    onComplete();
  };

  const handleNext = () => {
    if (isLast) {
      handleFinish();
    } else {
      setStep((s) => s + 1);
    }
  };

  return (
    <div className="min-h-dvh w-full bg-[#F4F6F9] flex justify-center">
      <div className="w-full max-w-[430px] min-h-dvh bg-white flex flex-col justify-between px-7 pt-6 pb-8 shadow-[0_0_50px_rgba(15,23,42,0.06)]">
        {/* Top Row: Skip button on the right (Step 2 style) */}
        <div className="flex items-center justify-end">
          <button
            type="button"
            onClick={handleFinish}
            className="min-h-[44px] px-3 text-sm font-semibold text-slate-600 hover:text-[#0F172A] transition-colors"
          >
            Skip
          </button>
        </div>

        {/* Title + Subtitle */}
        <div className="text-center px-2 mt-1">
          <h1
            className="text-[28px] font-extrabold text-[#0F172A] tracking-tight leading-tight"
            style={{ textWrap: 'balance' }}
          >
            {current.title}
          </h1>
          <p className="mt-2.5 text-sm text-slate-500 leading-relaxed max-w-[290px] mx-auto">
            {current.subtitle}
          </p>
        </div>

        {/* Center Graphic: 3 overlapping rounded photo cards (left tilted, center prominent, right tilted) */}
        <div className="relative h-[304px] flex items-center justify-center my-4 select-none">
          {/* Left tilted photo card */}
          <div className="relative w-[134px] h-[214px] rounded-[24px] -rotate-8 -translate-x-[82px] translate-y-3 shadow-[0_14px_30px_rgba(15,23,42,0.16)] border-[3px] border-white overflow-hidden bg-slate-200 transition-transform duration-200">
            <FramePhoto
              key={current.leftImage}
              src={current.leftImage}
              alt={current.leftAlt}
              fallbackGradient={current.leftGradient}
              FallbackIcon={LeftIcon}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/10 pointer-events-none" />
          </div>

          {/* Right tilted photo card */}
          <div className="absolute w-[134px] h-[214px] rounded-[24px] rotate-8 translate-x-[82px] translate-y-3 shadow-[0_14px_30px_rgba(15,23,42,0.16)] border-[3px] border-white overflow-hidden bg-slate-200 transition-transform duration-200">
            <FramePhoto
              key={current.rightImage}
              src={current.rightImage}
              alt={current.rightAlt}
              fallbackGradient={current.rightGradient}
              FallbackIcon={RightIcon}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/10 pointer-events-none" />
          </div>

          {/* Center prominent photo card */}
          <div className="absolute z-10 w-[178px] h-[264px] rounded-[28px] shadow-[0_22px_45px_rgba(15,23,42,0.24)] border-[3.5px] border-white overflow-hidden bg-slate-200 flex flex-col justify-between">
            <FramePhoto
              key={current.centerImage}
              src={current.centerImage}
              alt={current.centerAlt}
              fallbackGradient={current.centerGradient}
              FallbackIcon={CenterIcon}
            />

            {/* Top-right subtle icon badge */}
            <div className="relative z-10 p-3.5 flex justify-end">
              <div className="w-9 h-9 rounded-2xl bg-black/30 backdrop-blur-md border border-white/25 flex items-center justify-center text-white shadow-xs">
                <CenterIcon className="w-4 h-4" />
              </div>
            </div>

            {/* Bottom dark gradient scrim + white typography */}
            <div className="relative z-10 bg-gradient-to-t from-black/85 via-black/45 to-transparent pt-12 pb-3.5 px-4 text-left">
              <p className="font-script text-[20px] text-white leading-none drop-shadow-xs">
                Business Media
              </p>
              <p className="text-[11.5px] text-white/90 font-semibold mt-1 leading-snug">
                {current.caption}
              </p>
            </div>
          </div>
        </div>

        {/* Pagination Dots + Full-Width Dark Navy Button */}
        <div className="space-y-6">
          <div className="flex items-center justify-center gap-2.5">
            {PAGES.map((_, idx) => (
              <button
                key={idx}
                type="button"
                aria-label={`Page ${idx + 1}`}
                onClick={() => setStep(idx)}
                className={`h-2 rounded-full transition-all duration-200 ${
                  idx === step ? 'w-5 bg-[#0F172A]' : 'w-2 bg-slate-200 hover:bg-slate-300'
                }`}
              />
            ))}
          </div>

          <button
            type="button"
            onClick={handleNext}
            className="w-full h-14 rounded-full bg-[#0F172A] hover:bg-slate-800 active:scale-[0.99] text-white text-[15px] font-bold shadow-[0_10px_25px_rgba(15,23,42,0.16)] transition-all whitespace-nowrap"
          >
            {isLast ? 'Shuru Karo' : 'Next'}
          </button>
        </div>
      </div>
    </div>
  );
};
