/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { AuthModal } from './components/AuthModal';
import { BottomNav } from './components/BottomNav';
import { HomeView } from './components/HomeView';
import { OnboardingScreen } from './components/OnboardingScreen';
import { PostDetailModal } from './components/PostDetailModal';
import { ProfileSetupModal } from './components/ProfileSetupModal';
import { ProfileView } from './components/ProfileView';
import { SarkariNaukriView } from './components/SarkariNaukriView';
import { SearchView } from './components/SearchView';
import { SettingsModal } from './components/SettingsModal';
import { SplashScreen } from './components/SplashScreen';
import { UploadView } from './components/UploadView';
import { AdminDashboard } from './components/AdminDashboard';
import { auth, db } from './firebase';
import { doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { checkIsAdmin } from './services/adminService';
// ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
import { syncProfileToBackend } from './services/postService';
// ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====
import {
  isPendingGoogleOnboarding,
  logoutMember,
  updateMemberLastActiveAt,
  waitForPendingSignup,
} from './services/authService';
import { helloMeter, reportMeter } from './services/budgetService';
import { fetchUserCached, setCachedUser } from './services/userCache';
import {
  exitViewerSession,
  getSavedViewerName,
  sendViewerNameOnceIfNeeded,
} from './services/viewerService';
import { AuthModalMode, AdminTabId, PostCategory, PostItem, TabId, UserProfile } from './types';

const ONBOARDING_FLOW_VERSION_KEY = 'bm_onboarding_images_v4';

function initOnboardingState(): boolean {
  try {
    if (localStorage.getItem(ONBOARDING_FLOW_VERSION_KEY) !== 'true') {
      localStorage.removeItem('onboarding_done');
      localStorage.setItem(ONBOARDING_FLOW_VERSION_KEY, 'true');
      return false;
    }
    return localStorage.getItem('onboarding_done') === 'true';
  } catch {
    return false;
  }
}

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [splashFading, setSplashFading] = useState(false);
  const [onboardingDone, setOnboardingDone] = useState<boolean>(initOnboardingState);
  const [forceLoginAfterOnboarding, setForceLoginAfterOnboarding] = useState(false);

  const [currentMember, setCurrentMember] = useState<UserProfile | null>(null);
  const [viewerName, setViewerName] = useState<string | null>(() => getSavedViewerName());

  const [activeTab, setActiveTab] = useState<TabId>('home');
  const [uploadDefaultCategory, setUploadDefaultCategory] = useState<PostCategory>('general');
  const [authModalMode, setAuthModalMode] = useState<AuthModalMode | null>(null);
  const [profileModalState, setProfileModalState] = useState<{
    open: boolean;
    isInitial: boolean;
  }>({ open: false, isInitial: false });
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [viewingMemberUid, setViewingMemberUid] = useState<string | null>(null);
  const [selectedPost, setSelectedPost] = useState<PostItem | null>(null);
  const [refreshSignal, setRefreshSignal] = useState(0);
  const [isAuthReady, setIsAuthReady] = useState(false);
  
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminDashboardActive, setAdminDashboardActive] = useState(false);

  // ===== ADDED: HOME FEED VIA PYTHON BACKEND START =====
  // Keep name / @username / DP shown on the Python-powered feed in sync with the profile.
  useEffect(() => {
    if (currentMember) void syncProfileToBackend(currentMember);
  }, [currentMember?.uid, currentMember?.fullName, currentMember?.userName, currentMember?.dpUrl]);
  // ===== ADDED: HOME FEED VIA PYTHON BACKEND END =====

  useEffect(() => {
    void sendViewerNameOnceIfNeeded();
    const handleOnline = () => {
      void sendViewerNameOnceIfNeeded();
    };
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        void reportMeter();
      }
    };
    window.addEventListener('online', handleOnline);
    window.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  // Update active member timestamp or call helloMeter for viewers/guests
  useEffect(() => {
    const isMemberOrAdmin = Boolean(currentMember || isAdmin);
    if (currentMember && !isAdmin) {
      void updateMemberLastActiveAt(currentMember.uid);
    } else if (!isMemberOrAdmin) {
      void helloMeter(viewerName || undefined, false);
    }
  }, [currentMember, isAdmin, viewerName]);

  useEffect(() => {
    let authChecked = false;
    let minTimerDone = false;
    let unmounted = false;

    const finishSplashIfReady = () => {
      if (unmounted || !authChecked || !minTimerDone) return;
      if (!unmounted) setIsAuthReady(true);
      setSplashFading(true);
      window.setTimeout(() => {
        if (!unmounted) setShowSplash(false);
      }, 280);
    };

    const minSplashTimer = window.setTimeout(() => {
      minTimerDone = true;
      finishSplashIfReady();
    }, 1650);

    const maxFallbackTimer = window.setTimeout(() => {
      authChecked = true;
      minTimerDone = true;
      if (!unmounted) setIsAuthReady(true);
      finishSplashIfReady();
    }, 2600);

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      await waitForPendingSignup();

      if (!fbUser) {
        if (!unmounted) {
          setCurrentMember(null);
          setIsAdmin(false);
          setAdminDashboardActive(false);
          setIsAuthReady(true);
        }
        authChecked = true;
        finishSplashIfReady();
        return;
      }

      try {
        const adminStatus = checkIsAdmin(fbUser.email);
        let memberDoc = await fetchUserCached(fbUser.uid, true);

        if (adminStatus && !memberDoc) {
          const adminProfile: UserProfile = {
            uid: fbUser.uid,
            fullName: fbUser.displayName || 'Admin',
            userName: 'admin',
            userNameLower: 'admin',
            bio: 'Business Media Admin',
            dpUrl: fbUser.photoURL || '',
            postCount: 0,
            createdAt: null,
            updatedAt: null,
          };
          try {
            await setDoc(doc(db, 'users', fbUser.uid), {
              ...adminProfile,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            }, { merge: true });
            memberDoc = adminProfile;
            setCachedUser(adminProfile);
          } catch {
            memberDoc = adminProfile;
          }
        }

        if (!unmounted) {
          setIsAdmin(adminStatus);
          if (adminStatus) {
            setAdminDashboardActive(true);
          }
        }

        if (!memberDoc) {
          if (isPendingGoogleOnboarding(fbUser.uid) || adminStatus) {
            if (!unmounted) setCurrentMember(null);
          } else {
            await signOut(auth);
            if (!unmounted) {
              setCurrentMember(null);
              setIsAdmin(false);
              setAdminDashboardActive(false);
            }
          }
        } else if (!unmounted) {
          setCurrentMember(memberDoc);
          setOnboardingDone(true);
        }
      } catch {
        // Offline
      } finally {
        authChecked = true;
        if (getSavedViewerName()) {
          if (!unmounted) setOnboardingDone(true);
        }
        if (!unmounted) setIsAuthReady(true);
        finishSplashIfReady();
      }
    });

    return () => {
      unmounted = true;
      window.clearTimeout(minSplashTimer);
      window.clearTimeout(maxFallbackTimer);
      unsubscribe();
    };
  }, []);

  const handleOnboardingFinished = () => {
    setOnboardingDone(true);
    if (!auth.currentUser) {
      setForceLoginAfterOnboarding(true);
    }
  };

  const handleBackToOnboarding = () => {
    try {
      localStorage.removeItem('onboarding_done');
    } catch {}
    setForceLoginAfterOnboarding(false);
    setOnboardingDone(false);
  };

  const handleOpenMemberProfile = (uid: string) => {
    if (currentMember && currentMember.uid === uid) {
      setViewingMemberUid(null);
      setActiveTab('profile');
      return;
    }
    setViewingMemberUid(uid);
  };

  const handleExitViewer = () => {
    exitViewerSession();
    setViewerName(null);
    setViewingMemberUid(null);
    setActiveTab('home');
  };

  const handleLogoutMember = async () => {
    await logoutMember();
    setCurrentMember(null);
    setIsAdmin(false);
    setAdminDashboardActive(false);
    setSettingsOpen(false);
    setProfileModalState({ open: false, isInitial: false });
    setActiveTab('home');
  };

  const handleSelectBottomTab = (tab: TabId) => {
    if (tab === 'upload') {
      setUploadDefaultCategory(activeTab === 'sarkari' ? 'sarkari_naukri' : 'general');
    }
    setActiveTab(tab);
  };

  const isNameOnlyViewer = Boolean(viewerName && !currentMember);
  const shouldShowLoginPage = !currentMember && !viewerName;

  return (
    <>
      {showSplash && <SplashScreen fadingOut={splashFading} />}

      {!isAuthReady ? (
        null
      ) : shouldShowLoginPage ? (
        <AuthModal
          initialMode="login"
          isEntryGate
          onClose={() => {}}
          onSignedUp={(profile) => {
            setCurrentMember(profile);
            setViewerName(null);
            setRefreshSignal((s) => s + 1);
          }}
          onLoggedIn={(profile) => {
            setCurrentMember(profile);
            setViewerName(null);
          }}
          onViewerJoined={(name) => {
            setViewerName(name);
            if (activeTab === 'upload') setActiveTab('home');
          }}
        />
      ) : (
        <div className="min-h-dvh w-full bg-[#F4F6F9] flex justify-center">

          <main className="w-full max-w-[430px] min-h-dvh bg-white shadow-[0_0_50px_rgba(15,23,42,0.08)] relative">
            {activeTab === 'home' && (
              <HomeView
                currentMember={currentMember}
                viewerName={viewerName}
                refreshSignal={refreshSignal}
                isAdmin={isAdmin}
                onGoToProfile={() => setActiveTab('profile')}
                onOpenAuth={(mode) => setAuthModalMode(mode)}
                onOpenMemberProfile={handleOpenMemberProfile}
                onSelectPost={(p) => setSelectedPost(p)}
                onGoToUpload={() => {
                  setUploadDefaultCategory('general');
                  setActiveTab('upload');
                }}
                onOpenAdmin={() => setAdminDashboardActive(true)}
              />
            )}

            {activeTab === 'search' && (
              <SearchView
                currentMember={currentMember}
                refreshSignal={refreshSignal}
                isAdmin={isAdmin}
                onSelectPost={(p) => setSelectedPost(p)}
                onOpenMemberProfile={handleOpenMemberProfile}
              />
            )}

            {activeTab === 'upload' && !isNameOnlyViewer && (
              <UploadView
                currentMember={currentMember}
                viewerName={viewerName}
                isAdmin={isAdmin}
                defaultCategory={uploadDefaultCategory}
                onOpenAuth={(mode) => setAuthModalMode(mode)}
                onOpenSettings={() => setSettingsOpen(true)}
                onPostCreated={(newPost, updatedMember) => {
                  setCurrentMember(updatedMember);
                  setRefreshSignal((s) => s + 1);
                  setActiveTab(newPost.category === 'sarkari_naukri' ? 'sarkari' : 'home');
                }}
              />
            )}

            {activeTab === 'sarkari' && (
              <SarkariNaukriView
                currentMember={currentMember}
                viewerName={viewerName}
                refreshSignal={refreshSignal}
                isAdmin={isAdmin}
                onOpenAuth={(mode) => setAuthModalMode(mode)}
                onOpenMemberProfile={handleOpenMemberProfile}
                onSelectPost={(p) => setSelectedPost(p)}
                onGoToProfile={() => setActiveTab('profile')}
                onGoToUploadSarkari={() => {
                  setUploadDefaultCategory('sarkari_naukri');
                  setActiveTab('upload');
                }}
              />
            )}

            {activeTab === 'profile' && (
              <ProfileView
                currentMember={currentMember}
                viewerName={viewerName}
                refreshSignal={refreshSignal}
                isAdmin={isAdmin}
                onOpenAuth={(mode) => setAuthModalMode(mode)}
                onExitViewer={handleExitViewer}
                onEditProfile={() =>
                  setProfileModalState({ open: true, isInitial: false })
                }
                onOpenSettings={() => setSettingsOpen(true)}
                onOpenAdmin={() => setAdminDashboardActive(true)}
                onLogout={() => void handleLogoutMember()}
                onSelectPost={(p) => setSelectedPost(p)}
              />
            )}

            <BottomNav
              activeTab={activeTab}
              onSelectTab={handleSelectBottomTab}
              hideUpload={isNameOnlyViewer}
            />
          </main>
        </div>
      )}

      {viewingMemberUid && (
        <ProfileView
          targetUid={viewingMemberUid}
          currentMember={currentMember}
          viewerName={viewerName}
          refreshSignal={refreshSignal}
          isAdmin={isAdmin}
          onBack={() => setViewingMemberUid(null)}
          onOpenAuth={(mode) => {
            setViewingMemberUid(null);
            setAuthModalMode(mode);
          }}
          onExitViewer={handleExitViewer}
          onEditProfile={() => {
            setViewingMemberUid(null);
            setProfileModalState({ open: true, isInitial: false });
          }}
          onOpenSettings={() => {
            setViewingMemberUid(null);
            setSettingsOpen(true);
          }}
          onOpenAdmin={() => setAdminDashboardActive(true)}
          onLogout={() => void handleLogoutMember()}
          onSelectPost={(p) => setSelectedPost(p)}
        />
      )}

      {selectedPost && (
        <PostDetailModal
          post={selectedPost}
          currentMember={currentMember}
          isAdmin={isAdmin}
          onClose={() => setSelectedPost(null)}
          onOpenMemberProfile={handleOpenMemberProfile}
          onPostDeleted={() => {
            setSelectedPost(null);
            if (currentMember) {
              setCurrentMember({
                ...currentMember,
                postCount: Math.max(0, currentMember.postCount - 1),
              });
            }
            setRefreshSignal((s) => s + 1);
          }}
        />
      )}

      {!shouldShowLoginPage && authModalMode && (
        <AuthModal
          initialMode={authModalMode}
          onClose={() => setAuthModalMode(null)}
          onSignedUp={(profile) => {
            setCurrentMember(profile);
            setViewerName(null);
            setAuthModalMode(null);
            setRefreshSignal((s) => s + 1);
          }}
          onLoggedIn={(profile) => {
            setCurrentMember(profile);
            setViewerName(null);
            setAuthModalMode(null);
          }}
          onViewerJoined={(name) => {
            setViewerName(name);
            setAuthModalMode(null);
            if (activeTab === 'upload') setActiveTab('home');
          }}
        />
      )}

      {profileModalState.open && currentMember && (
        <ProfileSetupModal
          member={currentMember}
          isInitialSetup={profileModalState.isInitial}
          onSaved={(updated) => {
            setCurrentMember(updated);
            setProfileModalState({ open: false, isInitial: false });
            setRefreshSignal((s) => s + 1);
          }}
          onClose={() => setProfileModalState({ open: false, isInitial: false })}
          onOpenSettings={() => setSettingsOpen(true)}
        />
      )}

      {settingsOpen && currentMember && (
        <SettingsModal
          uid={currentMember.uid}
          onClose={() => setSettingsOpen(false)}
        />
      )}

      {adminDashboardActive && isAdmin && (
        <AdminDashboard
          onClose={() => setAdminDashboardActive(false)}
          onLogout={() => void handleLogoutMember()}
        />
      )}
    </>
  );
}
