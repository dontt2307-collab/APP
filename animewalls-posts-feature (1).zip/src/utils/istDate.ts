import type { Timestamp } from 'firebase/firestore/lite';

const IST_OFFSET_MS = 330 * 60 * 1000; // +5 hours 30 minutes (Asia/Kolkata, UTC+5:30)

/**
 * Computes yyyyMMdd in India Standard Time (Asia/Kolkata, UTC+5:30)
 * regardless of the user's local browser timezone.
 * Matches istDateKey() in firestore.rules (request.time + duration.value(330, 'm')).
 */
export function getISTDateKey(nowMs: number = Date.now()): string {
  const ist = new Date(nowMs + IST_OFFSET_MS);
  const yyyy = String(ist.getUTCFullYear());
  const mm = String(ist.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(ist.getUTCDate()).padStart(2, '0');
  return `${yyyy}${mm}${dd}`;
}

/**
 * Extracts up to 40 unique lowercase whole-word search tokens (1..50 chars each)
 * from both userName and caption so array-contains search works cleanly.
 */
export function buildKeywords(userName: string, caption: string): string[] {
  const combined = `${userName} ${caption}`.toLowerCase();
  // Split on whitespace and punctuation, preserving letters, numbers, and Devanagari/Roman words
  const rawTokens = combined
    .replace(/[#@.,!?;:()"'`~[\]{}<>/\\|+*=]+/g, ' ')
    .split(/\s+/)
    .map((w) => w.trim())
    .filter((w) => w.length >= 1 && w.length <= 50);

  const unique: string[] = [];
  const seen = new Set<string>();

  // Always ensure normalized full userNameLower (up to 50 chars) or first word is present so keywords.size() >= 1
  const fallbackToken = userName.trim().toLowerCase().slice(0, 50) || 'post';

  for (const token of rawTokens) {
    if (!seen.has(token)) {
      seen.add(token);
      unique.push(token);
      if (unique.length >= 40) break;
    }
  }

  if (unique.length === 0) {
    unique.push(fallbackToken);
  }

  return unique;
}

/**
 * Formats a Firestore Timestamp in friendly Hinglish / India time.
 */
export function formatISTTimestamp(ts: Timestamp | null | undefined): string {
  if (!ts || typeof ts.toMillis !== 'function') {
    return 'Abhi';
  }
  const ms = ts.toMillis();
  const diffSec = Math.max(0, Math.floor((Date.now() - ms) / 1000));

  if (diffSec < 60) return 'Abhi';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m pehle`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h pehle`;
  const diffDays = Math.floor(diffHr / 24);
  if (diffDays < 7) return `${diffDays}d pehle`;

  try {
    return new Intl.DateTimeFormat('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      timeZone: 'Asia/Kolkata',
    }).format(new Date(ms));
  } catch {
    return new Date(ms).toLocaleDateString();
  }
}
