export interface CompressedImageResult {
  base64Payload: string;
  previewDataUrl: string;
  width: number;
  height: number;
}

const MAX_IMAGE_WIDTH = 1080;
const JPEG_QUALITY = 0.8;

/**
 * Loads an image File into an HTMLImageElement, resizes proportionally if width > 1080,
 * draws onto an HTML5 Canvas with white background, and encodes as JPEG (quality 0.8).
 */
export function compressImageFile(file: File): Promise<CompressedImageResult> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('Sirf photo file select karo (JPG, PNG, WebP).'));
      return;
    }

    const objectUrl = URL.createObjectURL(file);
    const img = new Image();

    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      try {
        let targetWidth = img.naturalWidth || img.width;
        let targetHeight = img.naturalHeight || img.height;

        if (targetWidth <= 0 || targetHeight <= 0) {
          reject(new Error('Photo read nahi ho paayi. Doosri photo try karo.'));
          return;
        }

        if (targetWidth > MAX_IMAGE_WIDTH) {
          const ratio = MAX_IMAGE_WIDTH / targetWidth;
          targetWidth = MAX_IMAGE_WIDTH;
          targetHeight = Math.max(1, Math.round(targetHeight * ratio));
        }

        const canvas = document.createElement('canvas');
        canvas.width = targetWidth;
        canvas.height = targetHeight;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Browser image compression support nahi kar raha.'));
          return;
        }

        // Fill white background so transparent PNGs convert cleanly to JPEG
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, targetWidth, targetHeight);
        ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

        const dataUrl = canvas.toDataURL('image/jpeg', JPEG_QUALITY);
        const commaIndex = dataUrl.indexOf(',');
        const base64Payload = commaIndex >= 0 ? dataUrl.slice(commaIndex + 1) : dataUrl;

        resolve({
          base64Payload,
          previewDataUrl: dataUrl,
          width: targetWidth,
          height: targetHeight,
        });
      } catch {
        reject(new Error('Photo compress karne me dikkat aayi.'));
      }
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Yeh photo file kharab ya unsupported hai.'));
    };

    img.src = objectUrl;
  });
}
