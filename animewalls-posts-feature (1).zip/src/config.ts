import appletFirebaseConfig from '../firebase-applet-config.json';

/**
 * Business Media — Central Configuration
 */

export const firebaseConfig = {
  apiKey: appletFirebaseConfig.apiKey,
  authDomain: appletFirebaseConfig.authDomain,
  projectId: appletFirebaseConfig.projectId,
  storageBucket: appletFirebaseConfig.storageBucket,
  messagingSenderId: appletFirebaseConfig.messagingSenderId,
  appId: appletFirebaseConfig.appId,
  firestoreDatabaseId: appletFirebaseConfig.firestoreDatabaseId || '(default)',
};

export const IMGBB_KEY: string =
  (import.meta.env.VITE_IMGBB_KEY as string | undefined) ||
  (import.meta.env.VITE_IMGBB_API_KEY as string | undefined) ||
  '2b6fd19d7400ea00ad678227895f6727';

/** Posts older than this (in days) are hidden from public feeds */
export const postVisibleDays = 2;

/** When true, only admin can select Sarkari Naukri category */
export const onlyAdminCanPostJobs = false;

/** Tab and header label for Sarkari Naukri */
export const NAV_JOB_LABEL = 'Sarkari Naukri';

/** Calm informational strip text shown at top of member's own profile */
export const PROFILE_INFO_TEXT =
  'Aapki post 2 din tak hi rahegi, uske baad delete ho jayegi. Agar delete nahi hoti hai to aap khud delete kar do aur nayi post upload karo.';

/** Calm informational hint shown on Upload screen */
export const UPLOAD_INFO_HINT =
  'Post 2 din tak hi rahegi, uske baad delete ho jayegi.';

/** Maximum total members allowed */
export const MEMBER_LIMIT = 20;

/** Google Apps Script Web App URL for Name-only viewers and Daily Read Meter */
export const viewerSheetUrl =
  (import.meta.env.VITE_VIEWER_SHEET_URL as string | undefined) ||
  'https://script.google.com/macros/s/AKfycbz_YOUR_APPS_SCRIPT_ID/exec';

/** Shared secret token for Apps Script authorization */
export const viewerSheetToken =
  (import.meta.env.VITE_VIEWER_SHEET_TOKEN as string | undefined) ||
  'bm_viewer_secret_token_2026';

/** Admin token for fetching activity stats from Apps Script */
export const ADMIN_TOKEN =
  (import.meta.env.VITE_ADMIN_TOKEN as string | undefined) ||
  'bm_admin_secret_token_2026';

/** Legacy alias */
export const APPS_SCRIPT_URL = viewerSheetUrl;

// ============================================================================
// DAILY READ BUDGET CONSTANTS (GUESTS & NAME-ONLY VIEWERS)
// ============================================================================

/** Expected number of unique name-only viewers and guests per day */
export const expectedViewersPerDay = 1000;

/** Total daily Firestore free tier read operations quota */
export const totalDailyReads = 50000;

/** Quota reserved for 20 active members and admin operations */
export const reservedForMembersAndAdmin = 8000;

/** Safety margin buffer to avoid hitting Firestore daily quota limit */
export const safetyMargin = 6000;

/** Pool of reads allocated for viewers & guests (36,000) */
export const viewerPoolReads = totalDailyReads - reservedForMembersAndAdmin - safetyMargin;

/** Guaranteed base reads allowance per viewer per day (floor(36000 / 1000) = 36) */
export const baseAllowance = Math.floor(viewerPoolReads / expectedViewersPerDay);

/** Maximum extra bonus reads allowed per viewer per day */
export const maxBonusPerViewer = 200;

/** Posts loaded per page for guests and name-only viewers */
export const viewerPageSize = 10;

/**
 * Budget day reset hour in IST (0 to 23).
 * Note: Firestore daily quota resets at midnight Pacific time (about 12:30 PM or 1:30 PM IST).
 * You can change this constant to 13 to line the local budget day up with Pacific reset.
 */
export const budgetDayStartHourIST = 0;

/** Inline message card titles shown when viewer daily allowance is completed */
export const LIMIT_EXCEEDED_TITLE = 'Aaj ke liye itna hi, kal milte hain.';
export const LIMIT_EXCEEDED_SUBTITLE = 'Aaj ka free limit poora ho gaya hai. Kal phir aana.';
