# Business Media — Complete Setup, Security & Deployment Guide

## 1. Project Structure Overview

```text
/
├── apps-script/
│   └── Code.gs                     # Google Apps Script (doPost only) for Google Sheet viewer logging
├── firestore.rules                 # Production Firestore Security Rules (20-member & 20-post/IST-day caps)
├── firebase-blueprint.json         # Entity & Firestore path schema blueprint
├── security_spec.md                # Security invariants & adversarial payload specification
├── firestore.rules.test.ts         # Adversarial test cases for Firestore Emulator
├── public/
│   ├── icon.svg                    # Brand vector icon
│   ├── apple-touch-icon.png        # 180x180 iOS home screen icon
│   ├── pwa-192x192.png             # 192x192 PWA icon
│   ├── pwa-512x512.png             # 512x512 PWA icon
│   └── pwa-maskable-512x512.png    # 512x512 Android maskable PWA icon
├── src/
│   ├── config.ts                   # ONLY file with constants: firebaseConfig, IMGBB_KEY, APPS_SCRIPT_URL, MEMBER_LIMIT = 20
│   ├── firebase.ts                 # Modular Firebase v9+ Auth + Firestore initialization & error handling
│   ├── types.ts                    # TypeScript interfaces
│   ├── utils/
│   │   ├── istDate.ts              # Asia/Kolkata (UTC+5:30) date key & keyword tokenizer
│   │   └── imageCompress.ts        # HTML5 Canvas resize (max 1080px) & JPEG 0.8 compression
│   ├── services/
│   │   ├── authService.ts          # Signup writeBatch + Auth rollback, Login member check, Profile edit
│   │   ├── postService.ts          # Paginated feed/Shots/Profile queries, dual Search, atomic post batch
│   │   ├── imgbbService.ts         # Common + private ImgBB key fallback uploader & key masking
│   │   ├── userCache.ts            # Session-wide memory cache (max 1 read per user per session)
│   │   └── viewerService.ts        # Zero-Firebase localStorage + single-shot Apps Script no-cors logger
│   ├── hooks/
│   │   ├── usePWAInstall.ts        # Installable PWA prompt hook
│   │   └── useOnlineStatus.ts      # Live connectivity listener
│   └── components/                 # Splash, Onboarding, Home, Shots, Search, Upload, Profile, Settings, Auth, PostDetail
└── vite.config.ts                  # Vite + Tailwind v4 + VitePWA configuration
```

---

## 2. Step-by-Step Setup Instructions

### Step 1: Create Firebase Project (Free Spark Plan) & Copy `firebaseConfig`
1. Open [Firebase Console](https://console.firebase.google.com/) and click **Create a project** (stay on the default free **Spark** plan — do **not** enable Cloud Storage or Cloud Functions).
2. Inside Project Overview, click the **Web (`</>`)** icon to add a Web App named `Business Media` (you can leave Firebase Hosting unchecked for now or check it if deploying there).
3. Copy the `firebaseConfig` keys (`apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId`) into `src/config.ts` (for standard Firebase projects, set `firestoreDatabaseId: '(default)'`).
   *(Note: Inside Google AI Studio preview, `firebase-applet-config.json` has already been provisioned and wired automatically into `src/config.ts`.)*

### Step 2: Enable Google Sign-In
1. In Firebase Console, go to **Build > Authentication > Get started**.
2. Open the **Sign-in method** tab.
3. Click **Google**, toggle **Enable** ON, select your project support email, and click **Save**.
4. Make sure **Anonymous** and unused providers remain **Disabled**. *(Note: Inside Google AI Studio preview, Google Sign-In is pre-configured automatically via `ProvisionFirebase`.)*

### Step 3: Create Cloud Firestore & Seed `meta/stats` (`userCount = 0`)
1. Go to **Build > Firestore Database > Create database**, choose a nearby region (e.g., `asia-south1` Mumbai), and start in **Production mode**.
2. In the **Data** tab, click **+ Start collection**:
   - Collection ID: `meta`
   - Document ID: `stats`
   - Field: `userCount` | Type: `number` | Value: `0`
3. Click **Save**. *(Note: Our rules also safely support bootstrapping `meta/stats` to `1` on the very first signup if `meta/stats` has not been manually created yet.)*

### Step 4: Publish `firestore.rules`
1. In Firestore Database, open the **Rules** tab.
2. Copy the entire contents of `/firestore.rules` from this project, paste it into the editor, and click **Publish**.
   *(If changing `MEMBER_LIMIT` later, update both `MEMBER_LIMIT` in `src/config.ts` and `memberLimit()` at the top of `firestore.rules`.)*

### Step 5: Indexes (Zero Composite Indexes Needed!)
Every query in Business Media has been engineered to run on Firestore's **built-in automatic single-field indexes** to save index overhead and setup friction:
- **Home (`Business Post`) & `Sarkari Naukri`**: Posts are written with reverse-timestamp IDs (`{9999999999999 - epochMs}_{random}`), so `where('category', '==', 'business')` and `where('category', '==', 'sarkari_naukri')` with `limit(20)` naturally return newest posts first via Firestore's default `(category, __name__)` single-field index — **zero composite index required!**
- **Search Explore**: `posts` ordered by `createdAt DESC` with `limit(20)` (uses automatic single-field `createdAt` index).
- **Search (Username Prefix)**: `posts` ordered by `userNameLower ASC` with `startAt` / `endAt('\uf8ff')` and `limit(20)` (uses automatic single-field `userNameLower` index).
- **Search (Caption / Name Whole Word)**: `posts` filtered by `where('keywords', 'array-contains', word)` with `limit(20)` (uses automatic single-field `keywords` array index).
- **Member Profile Grid**: `where('uid', '==', uid)` with `limit(20)` naturally returns newest posts first via reverse-timestamp IDs — **zero composite index required!**

### Step 6: Get Your Free ImgBB API Key
1. Go to [https://imgbb.com/](https://imgbb.com/) and create a free account / sign in.
2. Visit [https://api.imgbb.com/](https://api.imgbb.com/) and click **Get API key** (or copy your existing v1 API key).
3. Paste the key into `IMGBB_KEY` inside `src/config.ts`.
4. Individual members can also add up to 10 personal fallback ImgBB keys inside **Profile > Settings** (`users/{uid}/private/imgbb`).

### Step 7: Set Up Google Sheet & Google Apps Script (`APPS_SCRIPT_URL`)
1. Open [https://sheets.new](https://sheets.new) and rename the spreadsheet to **`Business Media Viewers`**.
2. In Row 1 of the active tab, enter headers:
   - **A1**: `Time`
   - **B1**: `Name`
3. Click **Extensions > Apps Script**.
4. Clear `Code.gs`, paste the entire code from `/apps-script/Code.gs`, and press **Ctrl+S / Cmd+S** to save.
5. Click **Deploy > New deployment**:
   - Click the gear icon next to "Select type" and choose **Web app**.
   - **Description**: `Business Media Viewer Logger`
   - **Execute as**: `Me`
   - **Who has access**: `Anyone`
6. Click **Deploy**, click **Authorize access**, choose your Google account (`Advanced > Go to project (unsafe) > Allow` if Google shows the unverified personal script prompt), and copy the **Web app URL** (ending in `/exec`).
7. Paste that URL into `APPS_SCRIPT_URL` inside `src/config.ts`.
8. **Monthly Sheet Maintenance**: Download monthly via `File > Download > CSV / Excel`, then highlight and delete **only** old data rows (`Row 2` downwards) — never delete Row 1 (`Time, Name`) or the sheet tab.

### Step 8: Run Locally & Deploy
- **Run Locally**:
  ```bash
  npm install
  npm run dev
  ```
  Open `http://localhost:3000`.
- **Build for Production**:
  ```bash
  npm run build
  ```
- **Deploy Option A — Netlify / Vercel**:
  - Import the repository, set Build Command to `npm run build` and Output Directory to `dist`. (Add SPA rewrite `/* -> /index.html 200` if using deep routes.)
- **Deploy Option B — Firebase Hosting**:
  ```bash
  npm install -g firebase-tools
  firebase login
  firebase init hosting   # public directory: dist, single-page app: Yes
  npm run build
  firebase deploy --only hosting,firestore:rules
  ```

---

## 3. How the India Time (`Asia/Kolkata`, UTC+5:30) Daily Post Limit Works

India Standard Time (`Asia/Kolkata`) has a fixed year-round offset of **UTC + 5 hours 30 minutes (+330 minutes)** with no Daylight Saving Time:
1. **In the App (`src/utils/istDate.ts`)**: `new Date(Date.now() + 330 * 60 * 1000)` shifts the current UTC epoch forward by 330 minutes, then reads `.getUTCFullYear()`, `.getUTCMonth() + 1`, and `.getUTCDate()` to form `yyyyMMdd` (e.g., `20261025`). This produces the exact IST date even if a member's phone is set to another timezone.
2. **In Firestore Security Rules (`firestore.rules`)**: `let ist = request.time + duration.value(330, 'm');` shifts the trusted Google server timestamp forward by 330 minutes and formats `string(ist.year()) + pad2(ist.month()) + pad2(ist.day())`.
3. **Atomic Batch Enforcement**: Every post upload writes `posts/{postId}`, `postCounts/{uid}_{yyyyMMdd}`, and `users/{uid}.postCount` in one `writeBatch`. The rule on `posts/{postId}` uses `getAfter` on `postCounts/{uid}_{istDateKey()}` to verify `count == prevCount + 1 && count <= 20` and `lastPostId == postId`. A 21st post on the same IST day is rejected by Firestore rules.

---

## 4. Verification & Test Checklist

- [ ] **Onboarding + Login Page Flow**: Clear `localStorage` & `sessionStorage` and open the app -> Splash fades after ~1.6s into the 3-page Hinglish Onboarding -> tap `Skip` or `Shuru Karo` -> opens the dedicated **Login Page** (with Member Login, Sign Up, `"Bina account ke, sirf naam se aao"`, and `"Guest user banke app kholo"`). Reload after onboarding -> `onboarding_done = 'true'` skips Onboarding and goes straight to Login (or directly into Home if already logged in / viewer / active guest session).
- [ ] **Guest View**: On the Login Page, tap `"Guest user banke app kholo"` (or top-right `Skip · Guest`) -> opens Home feed, Shots, Search, and read-only member Profiles. Open `+` (Upload) and `Profile` tabs -> verify `"Login karo"` prompt appears.
- [ ] **Name-Only Viewer & Google Sheet**: Tap `Login / Naam` -> `Bina account ke, sirf naam se aao` -> enter a name -> verify `"Hi, <name>"` and `Exit` appear in Home top bar, and `[Timestamp, Name]` appears in the Google Sheet.
- [ ] **Viewer Name Not Sent Twice**: Reload the app multiple times while `"Hi, <name>"` is active -> verify `viewer_name_sent` stays `'true'` and **no duplicate row** is appended in the Google Sheet.
- [ ] **Viewer Offline Retry**: Turn off network (DevTools > Network > Offline), click `Exit`, join again with a new viewer name -> viewer enters Home immediately (`viewer_name_sent` stays `'false'`). Turn network back Online (or reload online) -> row appears once in the Google Sheet and `viewer_name_sent` flips to `'true'`.
- [ ] **Nothing About Viewers in Firebase**: Check Firebase Console > Authentication and Firestore Database -> confirm **zero** anonymous Auth users and **no** `viewers` collection exist.
- [ ] **20-Member Limit**: Temporarily set `meta/stats.userCount` to `20` in Firestore Console and attempt Sign Up -> verify `"Members ki limit poori ho chuki hai. Aap sirf naam daalke aa sakte ho"` appears before any Auth account is created, and Firestore rules reject any batch exceeding `20`.
- [ ] **Daily 20-Post Limit (IST)**: Set `postCounts/{uid}_{yyyyMMdd}.count` to `20` in Firestore Console -> open `+` Upload -> verify the IST daily limit banner blocks upload and Firestore rules reject a 21st post batch.
- [ ] **Search (Prefix + Whole Word)**: Search the first 2–3 letters of a member's name (matches via `userNameLower` `\uf8ff` range) and search a whole word from a caption (matches via `keywords` `array-contains`) -> verify deduplicated grid results.
- [ ] **Shots**: Open `Shots` tab -> swipe vertically -> verify smooth full-screen `scroll-snap` and verify DP + username + caption sit cleanly above the bottom navigation bar with zero overlap.
- [ ] **ImgBB Key Fallback**: Put an invalid string in `IMGBB_KEY` -> try uploading -> verify `"Settings kholo"` prompt -> add a valid personal ImgBB key in Settings (verify it displays masked) -> retry upload -> succeeds using the personal fallback key.
