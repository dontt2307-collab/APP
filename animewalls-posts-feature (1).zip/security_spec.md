# Business Media — Firestore Security Specification (`security_spec.md`)

## 1. Data Invariants

1. **Default-Deny Catch-All & Zero Viewers Collection**: All unspecified collections (including any `/viewers/*` path) are unconditionally denied for both reads and writes.
2. **Atomic 20-Member Cap (`/meta/stats` <-> `/users/{uid}`)**:
   - `meta/stats.userCount` can only increase by `+1` per batch and never exceed `MEMBER_LIMIT` (`20`).
   - Only a signed-in non-member (`!exists(/users/$(auth.uid))`) who is atomically creating `/users/$(auth.uid)` (`existsAfter(/users/$(auth.uid))`) in the same batch can increment `meta/stats`.
   - `/users/{uid}` can only be created with `postCount == 0` when `meta/stats.userCount` increases by `+1` and stays `<= 20` in the same batch.
3. **PII Isolation & Private Keys (`/users/{uid}/private/imgbb`)**:
   - `/users/{uid}` contains zero PII (no email/phone).
   - `/users/{uid}/private/{docId}` (`docId == 'imgbb'`) is strictly readable and writable only by `request.auth.uid == uid` when `/users/$(uid)` exists (Master Gate).
4. **Action-Partitioned User Updates**:
   - Profile edits (`userName`, `userNameLower`, `bio`, `dpUrl`, `updatedAt`) preserve `postCount`, `uid`, and `createdAt`.
   - `postCount` can only increment by `+1` when `/postCounts/$(uid + '_' + istDateKey())` increments by `+1` in the same batch, and can only decrement by `-1` (`>= 0`) when an existing post owned by `uid` is deleted in the same batch.
5. **Member-Only & IST Daily-Limited Posts (`/posts/{postId}` <-> `/postCounts/{uid}_{yyyyMMdd}`)**:
   - Only an existing member (`exists(/users/$(auth.uid))`) with `incoming().uid == auth.uid` can create a post.
   - The batch must atomically increment `/postCounts/$(auth.uid + '_' + istDateKey())` by `+1` (`<= 20`, where `istDateKey()` shifts `request.time` by `+330` minutes for `Asia/Kolkata` UTC+5:30), record `lastPostId == postId`, and increment `/users/$(auth.uid).postCount` by `+1`.
   - Posts are immutable after creation (`allow update: if false;`) and can only be deleted by their owner when decrementing `postCount` by `1`.
6. **Denial-of-Wallet List Guard**:
   - Public `list` queries on `/posts` and `/users` must specify `request.query.limit <= 20`. Unbounded collection scrapes are rejected.

## 2. The "Dirty Dozen" Adversarial Payloads

1. **Orphan Member Creation**: Creating `/users/u1` without incrementing `/meta/stats` in the same batch.
2. **21st Member Overflow**: Incrementing `/meta/stats.userCount` from `20` to `21` alongside `/users/u21`.
3. **Counter Hijack (+5 Jump)**: Updating `/meta/stats.userCount` from `3` to `8` in one write.
4. **Shadow Ghost Field Injection**: Updating `/users/u1` with `{ bio: "hi", isAdmin: true, updatedAt: request.time }`.
5. **Manual `postCount` Forgery**: Owner updating `/users/u1` with `{ postCount: 999, updatedAt: request.time }` outside a post batch.
6. **Private ImgBB Key Theft**: Authenticated member `u2` attempting `get` on `/users/u1/private/imgbb`.
7. **Non-Member Post Upload**: Signed-in Firebase Auth user `ghostUid` (who has no `/users/ghostUid` doc) attempting to create `/posts/p1`.
8. **Identity Spoofing on Post**: Member `u1` creating `/posts/p1` with `uid: "u2"`.
9. **21st Post Same IST Day**: Member `u1` attempting a batch where `/postCounts/u1_20261025.count` goes from `20` to `21`.
10. **Yesterday DateKey Bypass**: Member `u1` attempting to write `/postCounts/u1_19990101` to bypass today's IST counter.
11. **Viewer Collection Write**: Client attempting to create `/viewers/v1` with `{ name: "Rohan" }`.
12. **Unbounded Scrape (`list` without limit)**: Client calling `getDocs(collection(db, 'posts'))` with `limit(500)` or no limit.
