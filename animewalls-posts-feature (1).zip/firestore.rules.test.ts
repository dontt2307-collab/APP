/**
 * Adversarial Security Rule Test Suite — Business Media
 * Verifies all 12 "Dirty Dozen" payloads from security_spec.md return PERMISSION_DENIED
 * when run against @firebase/rules-unit-testing & the Firebase Firestore Emulator.
 *
 * Usage with Firebase Emulator:
 *   npx firebase emulators:exec --only firestore "npx vitest run firestore.rules.test.ts"
 */

export interface DirtyPayloadCase {
  id: number;
  name: string;
  collectionPath: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  authUid: string | null;
  payload?: Record<string, unknown>;
  expectedResult: 'PERMISSION_DENIED';
}

export const DIRTY_DOZEN_CASES: DirtyPayloadCase[] = [
  {
    id: 1,
    name: 'Orphan Member Creation without meta/stats batch increment',
    collectionPath: 'users/u1',
    operation: 'create',
    authUid: 'u1',
    payload: {
      uid: 'u1',
      userName: 'Aarav',
      userNameLower: 'aarav',
      bio: '',
      dpUrl: '',
      postCount: 0,
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 2,
    name: '21st Member Overflow beyond MEMBER_LIMIT = 20',
    collectionPath: 'meta/stats',
    operation: 'update',
    authUid: 'u21',
    payload: { userCount: 21 },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 3,
    name: 'Counter Hijack (+5 jump)',
    collectionPath: 'meta/stats',
    operation: 'update',
    authUid: 'u4',
    payload: { userCount: 8 },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 4,
    name: 'Shadow Ghost Field Injection on users/{uid}',
    collectionPath: 'users/u1',
    operation: 'update',
    authUid: 'u1',
    payload: { bio: 'Hello', isAdmin: true },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 5,
    name: 'Manual postCount Forgery outside post creation batch',
    collectionPath: 'users/u1',
    operation: 'update',
    authUid: 'u1',
    payload: { postCount: 999 },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 6,
    name: 'Private ImgBB Key Theft by non-owner member',
    collectionPath: 'users/u1/private/imgbb',
    operation: 'get',
    authUid: 'u2',
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 7,
    name: 'Non-Member Post Upload (signed in without users/{uid} doc)',
    collectionPath: 'posts/p1',
    operation: 'create',
    authUid: 'ghostUid',
    payload: {
      uid: 'ghostUid',
      userName: 'Ghost',
      userNameLower: 'ghost',
      userDpUrl: '',
      category: 'business',
      caption: 'Sneaky post',
      keywords: ['ghost', 'sneaky'],
      imageUrl: 'https://i.ibb.co/example/pic.jpg',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 8,
    name: 'Identity Spoofing on Post creation (uid != auth.uid)',
    collectionPath: 'posts/p2',
    operation: 'create',
    authUid: 'u1',
    payload: {
      uid: 'u2',
      userName: 'Priya',
      userNameLower: 'priya',
      userDpUrl: '',
      category: 'sarkari_naukri',
      caption: 'Spoofed',
      keywords: ['priya'],
      imageUrl: 'https://i.ibb.co/example/pic.jpg',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 9,
    name: '21st Post on the same IST day',
    collectionPath: 'postCounts/u1_20261025',
    operation: 'update',
    authUid: 'u1',
    payload: {
      uid: 'u1',
      dateKey: '20261025',
      count: 21,
      lastPostId: 'p21',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 10,
    name: 'Yesterday DateKey Bypass on postCounts',
    collectionPath: 'postCounts/u1_19990101',
    operation: 'create',
    authUid: 'u1',
    payload: {
      uid: 'u1',
      dateKey: '19990101',
      count: 1,
      lastPostId: 'p1',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 11,
    name: 'Forbidden viewers collection write',
    collectionPath: 'viewers/v1',
    operation: 'create',
    authUid: null,
    payload: { name: 'Rohan' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 12,
    name: 'Unbounded list scrape on posts without limit <= 20',
    collectionPath: 'posts',
    operation: 'list',
    authUid: null,
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 13,
    name: 'Unauthenticated / Name-only viewer attempting to like a post',
    collectionPath: 'posts/p1',
    operation: 'update',
    authUid: null,
    payload: { likedBy: ['viewer_fake'] },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 14,
    name: 'Member attempting to inject two likes or spoof another member UID in likedBy',
    collectionPath: 'posts/p1',
    operation: 'update',
    authUid: 'u1',
    payload: { likedBy: ['u1', 'u1'] },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 15,
    name: 'Member attempting uppercase or special characters in userName',
    collectionPath: 'users/u1',
    operation: 'update',
    authUid: 'u1',
    payload: {
      fullName: 'Aarav Verma',
      userName: 'Aarav_99!',
      userNameLower: 'aarav_99!',
    },
    expectedResult: 'PERMISSION_DENIED',
  },
];
