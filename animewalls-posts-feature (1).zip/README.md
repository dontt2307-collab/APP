# Business Media — Flask + Firebase Auth Migration

This version of Business Media uses **Firebase Authentication** for user identity (signup, login, Google sign-in) and a robust **Python Flask backend** paired with **SQLite** and **ImgBB** for all data storage, posts management, edit/delete permissions, and the admin dashboard.

---

## Deliverables Included
1. `backend/app.py` — Flask REST API backend
2. `backend/requirements.txt` — Python dependencies (`flask`, `flask-cors`, `firebase-admin`, `requests`, `gunicorn`)
3. `backend/Procfile` — Gunicorn process file for deployment (`web: gunicorn app:app`)
4. `backend/.env.example` — Environment variables template
5. `index.html` — Mobile-first frontend app (feed, upload, my posts, auth)
6. `admin.html` — Admin moderation panel (stats, user management, ban/unban, posts moderation)
7. `README.md` — Deployment guide & instructions
8. Test Checklist

---

## Step-by-Step Deployment Guide

### Part A: Deploying the Flask Backend (Render / Heroku / Railway)
1. Push your repository to GitHub.
2. Create a new **Web Service** on [Render](https://render.com) and connect your repository.
3. Set the **Root Directory** to `backend`.
4. Set the **Build Command** to `pip install -r requirements.txt`.
5. Set the **Start Command** to `gunicorn app:app`.
6. Add the following **Environment Variables** in Render:
   - `IMGBB_API_KEY`: Your ImgBB API key (`2b6fd19d7400ea00ad678227895f6727` or your own).
   - `ADMIN_EMAIL`: `dxobad000@gmail.com` (the only admin; no UID needed).
   - `FIREBASE_SERVICE_ACCOUNT`: The complete JSON contents of your Firebase Service Account private key as a single-line string.
   - `ALLOWED_ORIGINS`: Your Netlify frontend URL (e.g. `https://your-app.netlify.app`, or `*` for testing).

---

### Part B: Admin
Admin is decided by email: only a verified Google login as `dxobad000@gmail.com` is admin. Nothing else to configure.

---

### Part C: Deploying the Frontend (Netlify / Vercel / Static Hosting)
1. Open `index.html` and `admin.html`.
2. Update `const API_BASE = "http://localhost:5000";` to your deployed Flask backend URL (e.g. `https://business-media-api.onrender.com`).
3. Deploy `index.html` and `admin.html` to [Netlify](https://netlify.com) by dragging and dropping or connecting your repository.
