import os, json, re, base64, sqlite3, requests
from datetime import datetime, timezone
from urllib.parse import urlparse
from functools import wraps
from flask import Flask, request, jsonify, g
from flask_cors import CORS
import firebase_admin
from firebase_admin import credentials, auth

app = Flask(__name__)
CORS(app, origins=os.environ.get("ALLOWED_ORIGINS", "*").split(","))
app.config["MAX_CONTENT_LENGTH"] = 6 * 1024 * 1024

sa = os.environ.get("FIREBASE_SERVICE_ACCOUNT")
cred = credentials.Certificate(json.loads(sa)) if sa else credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred)

IMGBB_KEY = os.environ["IMGBB_API_KEY"]
# Only this email is admin (same as the frontend). Can be overridden via ADMIN_EMAIL env.
ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "dxobad000@gmail.com").strip().lower()
DB_PATH = os.environ.get("DB_PATH", "app.db")
ALLOWED = {"image/jpeg", "image/png", "image/webp", "image/gif"}

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    d = g.pop("db", None)
    if d: d.close()

def init_db():
    c = sqlite3.connect(DB_PATH)
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(
        uid TEXT PRIMARY KEY, name TEXT, email TEXT, photo TEXT,
        banned INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        last_login TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS posts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        uid TEXT NOT NULL, url TEXT NOT NULL, delete_url TEXT,
        caption TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE INDEX IF NOT EXISTS idx_posts_uid ON posts(uid);
    """)
    # ===== ADDED: HOME FEED / LIKES (migrations, safe to run repeatedly) =====
    def add_col(table, col, ddl):
        cols = [r[1] for r in c.execute(f"PRAGMA table_info({table})")]
        if col not in cols:
            c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")
    add_col("users", "user_name", "TEXT DEFAULT ''")   # app @username
    add_col("users", "full_name", "TEXT DEFAULT ''")
    add_col("users", "dp_url", "TEXT DEFAULT ''")
    add_col("posts", "fid", "TEXT")                     # Firestore post id (upload happens in Firebase)
    add_col("posts", "category", "TEXT DEFAULT 'general'")
    c.executescript("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_posts_fid ON posts(fid) WHERE fid IS NOT NULL;
    CREATE INDEX IF NOT EXISTS idx_posts_cat ON posts(category, id);
    CREATE TABLE IF NOT EXISTS likes(
        post_id INTEGER NOT NULL, uid TEXT NOT NULL,
        PRIMARY KEY(post_id, uid));
    """)
    c.commit(); c.close()
init_db()

def verify():
    h = request.headers.get("Authorization", "")
    if not h.startswith("Bearer "): return None
    try: return auth.verify_id_token(h[7:])
    except Exception: return None

def login_required(f):
    @wraps(f)
    def wrap(*a, **kw):
        t = verify()
        if not t: return jsonify({"error": "Login required"}), 401
        db().execute("""INSERT INTO users(uid,name,email,photo) VALUES(?,?,?,?)
            ON CONFLICT(uid) DO UPDATE SET name=excluded.name, email=excluded.email,
            photo=excluded.photo, last_login=CURRENT_TIMESTAMP""",
            (t["uid"], t.get("name", ""), t.get("email", ""), t.get("picture", "")))
        db().commit()
        row = db().execute("SELECT banned FROM users WHERE uid=?", (t["uid"],)).fetchone()
        if row and row["banned"]:
            return jsonify({"error": "Account banned"}), 403
        g.uid = t["uid"]
        g.is_admin = (t.get("email", "").strip().lower() == ADMIN_EMAIL and bool(t.get("email_verified")))
        return f(*a, **kw)
    return wrap

def admin_required(f):
    @wraps(f)
    @login_required
    def wrap(*a, **kw):
        if not g.is_admin: return jsonify({"error": "Admin only"}), 403
        return f(*a, **kw)
    return wrap

POST_SQL = """SELECT p.id, p.uid, p.url, p.caption, p.created_at,
              u.name AS user_name, u.photo AS user_photo,
              p.category, COALESCE(p.fid, 'b' || p.id) AS ref,
              u.user_name AS username, u.full_name AS full_name, u.dp_url AS dp_url,
              (SELECT group_concat(l.uid) FROM likes l WHERE l.post_id = p.id) AS liked_csv
              FROM posts p LEFT JOIN users u ON u.uid = p.uid"""

def row_to_post(r):
    d = dict(r)
    csv = d.pop("liked_csv", None)
    d["liked_by"] = csv.split(",") if csv else []
    return d

@app.get("/api/posts")
def list_posts():
    # FIX: invalid ?limit= / ?before_id= used to crash with HTTP 500
    try:
        limit = max(1, min(int(request.args.get("limit", 20)), 50))
        before = request.args.get("before_id")
        before = int(before) if before else None
        days = request.args.get("days")
        days = int(days) if days else None
    except ValueError:
        return jsonify({"error": "Invalid limit, before_id or days"}), 400
    where, args = [], []
    if before is not None:
        where.append("p.id < ?"); args.append(before)
    cat = request.args.get("category")        # ADDED: Sarkari Naukri tab
    if cat in ("general", "sarkari_naukri"):
        where.append("p.category = ?"); args.append(cat)
    uid = request.args.get("uid")             # ADDED: profile page
    if uid:
        where.append("p.uid = ?"); args.append(uid)
    if days and days > 0:                     # ADDED: "posts visible for N days"
        where.append("p.created_at >= datetime('now', ?)"); args.append(f"-{days} days")
    q = POST_SQL + (" WHERE " + " AND ".join(where) if where else "")
    q += " ORDER BY p.id DESC LIMIT ?"; args.append(limit)
    return jsonify([row_to_post(r) for r in db().execute(q, args).fetchall()])

@app.get("/api/search")
def search_posts():
    """ADDED: search by @username, name or caption (each word must match somewhere)."""
    raw = (request.args.get("q") or "").strip().lower()
    tokens = [t for t in re.split(r"\s+", re.sub(r"[#@.,!?;:()\"'`~\[\]{}<>/\\|+*=]+", " ", raw)) if t][:5]
    if not tokens: return jsonify([])
    try:
        limit = max(1, min(int(request.args.get("limit", 20)), 50))
        before = request.args.get("before_id"); before = int(before) if before else None
        days = request.args.get("days"); days = int(days) if days else None
    except ValueError:
        return jsonify({"error": "Invalid limit, before_id or days"}), 400
    where, args = [], []
    for t in tokens:
        like = "%" + t.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        where.append("(lower(COALESCE(u.user_name,'')) LIKE ? ESCAPE '\\' OR lower(COALESCE(u.full_name,'')) LIKE ? ESCAPE '\\'"
                     " OR lower(COALESCE(u.name,'')) LIKE ? ESCAPE '\\' OR lower(COALESCE(p.caption,'')) LIKE ? ESCAPE '\\')")
        args += [like] * 4
    if before is not None:
        where.append("p.id < ?"); args.append(before)
    if days and days > 0:
        where.append("p.created_at >= datetime('now', ?)"); args.append(f"-{days} days")
    q = POST_SQL + " WHERE " + " AND ".join(where) + " ORDER BY p.id DESC LIMIT ?"
    args.append(limit)
    return jsonify([row_to_post(r) for r in db().execute(q, args).fetchall()])

@app.get("/api/me")
@login_required
def me():
    return jsonify({"uid": g.uid, "isAdmin": g.is_admin})

@app.get("/api/my-posts")
@login_required
def my_posts():
    rows = db().execute(POST_SQL + " WHERE p.uid=? ORDER BY p.id DESC", (g.uid,)).fetchall()
    return jsonify([row_to_post(r) for r in rows])

@app.post("/api/posts")
@login_required
def create_post():
    f = request.files.get("image")
    if not f: return jsonify({"error": "image missing"}), 400
    if f.mimetype not in ALLOWED: return jsonify({"error": "Sirf jpg/png/webp/gif"}), 400
    # FIX: network error / non-JSON reply from ImgBB used to crash with HTTP 500
    try:
        r = requests.post("https://api.imgbb.com/1/upload",
            data={"key": IMGBB_KEY, "image": base64.b64encode(f.read()).decode()},
            timeout=40).json()
    except (requests.RequestException, ValueError):
        return jsonify({"error": "ImgBB upload failed"}), 502
    if not r.get("success"):
        return jsonify({"error": "ImgBB upload failed"}), 502
    d = r["data"]
    cur = db().execute("INSERT INTO posts(uid,url,delete_url,caption) VALUES(?,?,?,?)",
        (g.uid, d["url"], d.get("delete_url"), request.form.get("caption", "")[:500]))
    db().commit()
    return jsonify({"id": cur.lastrowid, "url": d["url"]}), 201

def owner_or_admin(post_id):
    p = db().execute("SELECT * FROM posts WHERE id=?", (post_id,)).fetchone()
    if not p: return None, (jsonify({"error": "Post nahi mila"}), 404)
    if p["uid"] != g.uid and not g.is_admin:
        return None, (jsonify({"error": "Permission nahi hai"}), 403)
    return p, None

@app.put("/api/posts/<int:pid>")
@login_required
def edit_post(pid):
    p, err = owner_or_admin(pid)
    if err: return err
    # FIX: bad/missing JSON or non-string caption used to crash with HTTP 500
    body = request.get_json(silent=True) or {}
    cap = body.get("caption", "")
    cap = cap[:500] if isinstance(cap, str) else ""
    db().execute("UPDATE posts SET caption=? WHERE id=?", (cap, pid)); db().commit()
    return jsonify({"ok": True})

@app.delete("/api/posts/<int:pid>")
@login_required
def delete_post(pid):
    p, err = owner_or_admin(pid)
    if err: return err
    db().execute("DELETE FROM likes WHERE post_id=?", (pid,))
    db().execute("DELETE FROM posts WHERE id=?", (pid,)); db().commit()
    return jsonify({"deleted": pid})

@app.get("/api/admin/users")
@admin_required
def admin_users():
    rows = db().execute("""SELECT u.uid,u.name,u.email,u.photo,u.banned,u.created_at,u.last_login,
        (SELECT COUNT(*) FROM posts WHERE uid=u.uid) AS post_count
        FROM users u ORDER BY u.last_login DESC""").fetchall()
    return jsonify([dict(r) for r in rows])

@app.post("/api/admin/users/<uid>/ban")
@admin_required
def ban(uid):
    flag = 1 if (request.get_json(silent=True) or {}).get("banned", True) else 0
    db().execute("UPDATE users SET banned=? WHERE uid=?", (flag, uid)); db().commit()
    return jsonify({"uid": uid, "banned": flag})

@app.get("/api/admin/stats")
@admin_required
def stats():
    return jsonify({
        "users": db().execute("SELECT COUNT(*) c FROM users").fetchone()["c"],
        "posts": db().execute("SELECT COUNT(*) c FROM posts").fetchone()["c"]})

# ===== ADDED: HOME FEED / LIKES / SYNC ENDPOINTS =====
CATEGORIES = {"general", "sarkari_naukri"}

def find_post(ref):
    """ref is either 'b<id>' (created here) or a Firestore post id (synced)."""
    m = re.fullmatch(r"b(\d+)", ref)
    if m:
        return db().execute("SELECT * FROM posts WHERE id=?", (int(m.group(1)),)).fetchone()
    return db().execute("SELECT * FROM posts WHERE fid=?", (ref,)).fetchone()

def clean_str(v, n):
    return v.strip()[:n] if isinstance(v, str) else ""

def valid_image_url(u):
    try:
        p = urlparse(u)
        return p.scheme == "https" and (p.hostname or "").endswith("ibb.co")
    except Exception:
        return False

def save_profile(uid, body):
    # only overwrite fields that were actually sent (never wipe with empty values)
    for col, key, n in (("user_name", "userName", 60), ("full_name", "fullName", 100), ("dp_url", "dpUrl", 500)):
        v = clean_str(body.get(key), n)
        if v:
            db().execute(f"UPDATE users SET {col}=? WHERE uid=?", (v, uid))

@app.post("/api/me/profile")
@login_required
def sync_profile():
    save_profile(g.uid, request.get_json(silent=True) or {}); db().commit()
    return jsonify({"ok": True})

@app.post("/api/posts/sync")
@login_required
def sync_post():
    """Upload itself happens in Firebase. The app then calls this so the post is
    stored here and shows up for ALL users in the Python-powered feed."""
    b = request.get_json(silent=True) or {}
    fid = clean_str(b.get("fid"), 200)
    url = clean_str(b.get("imageUrl"), 1000)
    cat = b.get("category") if b.get("category") in CATEGORIES else "general"
    if not fid or not valid_image_url(url):
        return jsonify({"error": "Invalid post data"}), 400
    save_profile(g.uid, b)
    db().execute("INSERT OR IGNORE INTO posts(uid,url,caption,category,fid) VALUES(?,?,?,?,?)",
        (g.uid, url, clean_str(b.get("caption"), 500), cat, fid))
    db().commit()
    return jsonify({"ref": fid}), 201

@app.post("/api/posts/ref/<ref>/like")
@login_required
def toggle_like(ref):
    p = find_post(ref)
    if not p: return jsonify({"error": "Post nahi mila"}), 404
    cur = db().execute("DELETE FROM likes WHERE post_id=? AND uid=?", (p["id"], g.uid))
    liked = cur.rowcount == 0
    if liked:
        db().execute("INSERT OR IGNORE INTO likes(post_id,uid) VALUES(?,?)", (p["id"], g.uid))
    db().commit()
    rows = db().execute("SELECT uid FROM likes WHERE post_id=?", (p["id"],)).fetchall()
    return jsonify({"liked": liked, "liked_by": [r["uid"] for r in rows]})

@app.delete("/api/posts/ref/<ref>")
@login_required
def delete_by_ref(ref):
    p = find_post(ref)
    if not p: return jsonify({"error": "Post nahi mila"}), 404
    if p["uid"] != g.uid and not g.is_admin:
        return jsonify({"error": "Permission nahi hai"}), 403
    db().execute("DELETE FROM likes WHERE post_id=?", (p["id"],))
    db().execute("DELETE FROM posts WHERE id=?", (p["id"],)); db().commit()
    return jsonify({"deleted": ref})

@app.delete("/api/me/posts/overdue")
@login_required
def delete_my_overdue():
    try: days = max(1, int(request.args.get("days", 2)))
    except ValueError: return jsonify({"error": "Invalid days"}), 400
    ids = [r["id"] for r in db().execute(
        "SELECT id FROM posts WHERE uid=? AND created_at < datetime('now', ?)",
        (g.uid, f"-{days} days")).fetchall()]
    for i in ids:
        db().execute("DELETE FROM likes WHERE post_id=?", (i,))
        db().execute("DELETE FROM posts WHERE id=?", (i,))
    db().commit()
    return jsonify({"deleted": len(ids)})

@app.delete("/api/admin/users/<uid>/posts")
@admin_required
def admin_delete_user_posts(uid):
    ids = [r["id"] for r in db().execute("SELECT id FROM posts WHERE uid=?", (uid,)).fetchall()]
    for i in ids:
        db().execute("DELETE FROM likes WHERE post_id=?", (i,))
        db().execute("DELETE FROM posts WHERE id=?", (i,))
    db().commit()
    return jsonify({"deleted": len(ids)})

@app.post("/api/admin/import")
@admin_required
def admin_import():
    """One-time: copy existing Firestore posts into this backend."""
    items = (request.get_json(silent=True) or {}).get("posts")
    if not isinstance(items, list): return jsonify({"error": "posts list missing"}), 400
    added = 0
    for b in items[:1000]:
        if not isinstance(b, dict): continue
        fid = clean_str(b.get("fid"), 200); uid = clean_str(b.get("uid"), 128)
        url = clean_str(b.get("imageUrl"), 1000)
        if not fid or not uid or not valid_image_url(url): continue
        if db().execute("SELECT 1 FROM posts WHERE fid=?", (fid,)).fetchone(): continue
        try:
            ts = datetime.fromtimestamp(float(b.get("createdAtMs")) / 1000, timezone.utc)
            created = ts.strftime("%Y-%m-%d %H:%M:%S")
        except (TypeError, ValueError, OSError):
            created = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        cat = b.get("category") if b.get("category") in CATEGORIES else "general"
        db().execute("INSERT OR IGNORE INTO users(uid,name,email,photo) VALUES(?,?,?,?)", (uid, "", "", ""))
        db().execute("UPDATE users SET user_name=?, full_name=?, dp_url=? WHERE uid=?",
            (clean_str(b.get("userName"), 60), clean_str(b.get("fullName"), 100),
             clean_str(b.get("dpUrl"), 500), uid))
        cur = db().execute("INSERT INTO posts(uid,url,caption,category,fid,created_at) VALUES(?,?,?,?,?,?)",
            (uid, url, clean_str(b.get("caption"), 500), cat, fid, created))
        likes = b.get("likedBy") if isinstance(b.get("likedBy"), list) else []
        for lu in likes[:200]:
            if isinstance(lu, str):
                db().execute("INSERT OR IGNORE INTO likes(post_id,uid) VALUES(?,?)", (cur.lastrowid, lu))
        added += 1
    db().commit()
    return jsonify({"imported": added})
# ===== END ADDED =====

@app.get("/")
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(port=5000, debug=True)
